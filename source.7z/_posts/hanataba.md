---
title: 【罗马音+平假名歌词】「マリンスノーの花束を(献上海洋雪的花束)」/After the Rain
tags:
  - マリンスノーの花束を
  - まふまふ
  - そらる
  - After the Rain
  - 歌词翻译
  - 中文歌词
  - イザナワレトラバラー
id: '697'
date: 2019-07-08 19:13:26
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/07/e99f90f419ee013c8112279b927ca9bd975d3a88.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/07/e99f90f419ee013c8112279b927ca9bd975d3a88.jpg@1075w_602h.jpg
---

マリンスノーの花束を

作詞︰まふまふ  
作編曲︰まふまふ  
唄:そらる/まふまふ  
After the Rain

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

syoka no pare-do  
初夏(しょか)のパレード  
shio kaze no se  
潮風(しおかぜ)の背(せ)  
umi no kure-pu  
海(うみ)のクレープ  
haji keta yume  
はじけた夢(ゆめ)  
chotto dake tokui ge ni  
ちょっとだけ得意気(とくいげ)に  
kimi wo saso un dayo  
君(きみ)を誘(さそ)うんだよ

shi buki agete  
飛沫(しぶき)あげて  
nomi komu natsu ga  
飲(の)み込(こ)む夏(なつ)が  
ramu neni yoku nita kono aji ga  
ラムネによく似(に)たこの味(あじ)が  
koi da nan te yobu kotoni  
恋(こい)だなんて呼(よ)ぶことに  
hani ka n da wan shi-n  
はにかんだワンシーン

kaki kake no mirai  
描(か)きかけの未来(みらい)  
suna no shiro  
砂(すな)の城(しろ)  
zutto ii dasezu ita  
ずっと言(い)い出(だ)せずいた  
kou kai mo  
後悔(こうかい)も  
kokoro no michi hikini  
ココロの満(み)ち引(ひ)きに  
naga sarete kiete iku  
流(なが)されて消(き)えていく

hoshizora no kyan basu wo  
星空(ほしぞら)のキャンバスを  
tore-sushite  
トレースして  
kono yono ginga wo bake tsu de  
この世(よ)の銀河(ぎんが)をバケツで  
koboshite mitai  
零(こぼ)してみたい  
tsume tai shinkai no  
冷(つめ)たい深海(しんかい)の  
kimini mo mieru youni  
君(きみ)にも見(み)えるように

safaia yori  
サファイアより  
fukai kousai no  
深(ふか)い虹彩(こうさい)の  
hitotsu mo nai syou kei  
ひとつもない小景(しょうけい)  
atena mo nai mama  
宛名(あてな)もないまま  
shizun da mukou  
沈(しず)んだ向(む)こう  
kimini misetai  
君(きみ)に見(み)せたい  
hoshizora ni na ttan da  
星空(ほしぞら)になったんだ

mi hana da kara  
水縹(みはなだ)から  
ruri iro no shita  
瑠璃色(るりいろ)の下(した)  
marin suno-ni mitore teita  
マリンスノーに見惚(みと)れていた  
mou nidoto kimino koto  
もう二度(にど)と君(きみ)のこと  
tebanashi wa shi nai  
手放(てばな)しはしない

soshite suteppu ando sukippu  
そしてステップ＆(アンド)スキップ  
sui sa i no suihei sen  
水彩(すいさい)の水平線(すいへいせん)  
futari de arui te ikou  
ふたりで歩(ある)いていこう

kanawa na i nara yume yori  
叶(かな)わないなら夢(ゆめ)より  
ohanashi de ii  
御話(おはなし)でいい  
kie te shimau nara  
消(き)えてしまうなら  
koini mita naku tatte ii  
恋(こい)に満(み)たなくたっていい  
mi jyuku na kanjyou no  
未熟(みじゅく)な感情(かんじょう)の  
omosa de shizun deiku  
重(おも)さで沈(しず)んでいく

doredake fukai sekai kei no  
どれだけ深(ふか)いセカイ系(けい)の  
kura yami datte  
暗闇(くらやみ)だって  
utakata no nazoru  
泡沫(うたかた)のなぞる  
ten tai no sou  
天体(てんたい)の相(そう)  
kimini mise tai  
君(きみ)に見(み)せたい  
hoshizora ni na ttan da  
星空(ほしぞら)になったんだ

kimi no moto e  
君(きみ)のもとへ  
todo itara ii noni naa  
届(とど)いたらいいのになあ