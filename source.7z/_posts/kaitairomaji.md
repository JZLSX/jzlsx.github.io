---
title: 「携帯恋話」／まふまふ【罗马音+假名歌词】
tags:
  - 携帯恋話
  - 罗马音
  - まふまふ
  - 假名歌词
id: '3010'
date: 2020-05-23 13:59:40
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/05/hj5ci6ro.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/05/hj5ci6ro.jpg
---

「携帯恋話」  
作词作编曲：まふまふ

罗马音：JZLSX

歌词翻译：[https://mafuclub.com/translation/keitairenwa/](https://mafuclub.com/translation/keitairenwa/)

这次是按照自己的习惯，原文在上，罗马音在下，别看混了~

いつまでも　手放(てばな)せない感情(かんじょう)は  
i tsu ma de mo te ba na se na i kan jyou wa  
ひとさじの甘(あま)さで薄汚(うすよご)れている  
hi to sa ji no ama sa de usu yogo re te i ru  
憧(あこが)れの物語(ものがたり)と違(ちが)うのは  
akoga re no mono gatari to chiga u no wa  
どうしても不安(ふあん)になる以上(いじょう)の感触(かんしょく)が足(た)りない  
do u shi te mo fu an ni na ru i jyou no kan syoku ga ta ri na i

チクタク　チクタク　君(きみ)と交(か)わす  
chi ku ta ku chi ku ta ku kimi to ka wa su  
とりとめのない言葉(ことば)　結(ゆわ)いて  
to ri to me no na i koto ba yu wa i te  
チクタク　チクタク  
chi ku ta ku chi ku ta ku  
お別(わか)れの頃合(ころあ)いになっただけ  
o waka re no koro a i ni na tta da ke

口元(くちもと)に残(のこ)る甘(あま)さは どこへやろう  
kuchi moto ni no ko ru ama sa wa do ko e ya ro u

ねえ　愛(あい)してを繋(つな)いで　嘘(うそ)だって笑(わら)って  
ne e ai shi te wo tsuna i de uso da tte wara tte  
どこへいたって受話器(じゅわき)越(こ)し  
do ko e i ta tte jyu wa ki go shi  
手頃(てごろ)な恋話(れんわ)　決(き)まりの台詞(せりふ)  
te goro na ren wa ki ma ri no serifu  
息(いき)をひそめて　「愛(あい)してるよ」  
iki wo hi so me te ai shi te ru yo

口(くち)をつけずに冷(さ)めた紅茶(こうちゃ)を  
ku chi wo tsu ke zu ni sa me ta kou cya wo  
捨(す)てられないような恋(こい)でも  
su te ra re na i yo u na koi de mo  
心以上(こころいじょう)の言葉(ことば)で  
kokoro i jyou no koto ba de  
君(きみ)を聞(き)かせて　もしもし  
kimi wo ki ka se te mo shi mo shi

思(おも)い出(で)と今(いま)を繋(つな)ぐ回線(かいせん)が  
omo i de to ima wo tsuna gu kai sen ga  
いつからか解(ほず)れかけていたんでしょう  
i tsu ka ra ka hozu re ka ke te i ta n de syo u  
ひとりきり慣(な)れてしまう手違(てちが)いに  
hi to ri ki ri na re te shi ma u te chiga i ni  
いつまでもささくれ立(だ)つ心(こころ)が止(や)まない  
i tsu ma de mo sa sa ku re da tsu kokoro ga ya ma na i

どうせなら　もう君(きみ)が  
do u se na ra mo u kimi ga  
最低(さいてい)な言葉(ことば)で壊(こわ)して  
sai tei na koto ba de kowa shi te  
悪戯(いたずら)な優(やさ)しさに  
ita zura na yasa si sa ni  
胸(むね)がおかしくなるの  
mune ga o ka shi ku na ru no

苦(くる)しくなるの  
ku ru shi ku na ru no

チクタク　チクタク 君(きみ)を探(さが)す  
chi ku ta ku chi ku ta ku kimi wo saga su  
秒針握(びょうしんにぎ)ったまま　迷(まよ)って  
byou shin nigi tta ma ma mayo tte  
チクタク　チクタク  
chi ku ta ku chi ku ta ku  
どうせまた　おやすみになったフリ  
do u de ma ta o ya su mi ni na tta fu ri

もういいよ　それならばもういいよが今日(きょう)も言(い)えないや  
mo u i i yo so re na ra ba mo u i i yo ga kyou mo i e na i ya  
履歴(りれき)にないような囁(ささや)きはいらない  
ri reki ni na i yo u na sasaya ki wa i ra nai

ねえ　愛(あい)すなら愛(あい)して　厭(いや)ならば嫌(きら)って  
ne e ai su na ra ai shi te iya na ra ba kira tte  
白黒(しろくろ)つかないダージリン  
shiro kuro tsu ka na i da- ji ri n  
瞼(まぶた)のいらない　嘘(うそ)の言葉(ことば)に  
mabuta no i ra na i u so no koto ba ni  
愛(あい)をせがんでしまう　「いかないでよ」  
ai wo se ga n de shi ma u i ka na i de yo

口(くち)をつけずに冷(さ)めた紅茶(こうちゃ)を  
ku chi wo tsu ke zu ni sa me ta kou cya wo  
捨(す)てられないような恋(こい)でも  
su te ra re nai yo u na koi de mo  
心以上(こころいじょう)の言葉(ことば)で  
kokoro i jyou no koto ba de  
君(きみ)を聞(き)かせて　もしもし  
kimi wo ki ka se te mo shi mo shi

君(きみ)と繋(つな)げて　もしもし  
kimi to tsuna ge te mo shi mo shi