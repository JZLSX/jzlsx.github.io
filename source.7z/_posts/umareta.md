---
title: 「生まれた意味などなかった。」/まふまふ【罗马音+假名歌词】
tags:
  - 生まれた意味などなかった。
  - まふまふ
  - 歌词翻译
  - 中文歌词
  - 神楽色アーティファクト
id: '710'
date: 2019-08-29 19:32:01
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/379ac0e0710706357fa51138bc06fad09043a90b.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/379ac0e0710706357fa51138bc06fad09043a90b.jpg
---

「生まれた意味などなかった。」

——《神楽色アーティファクト》収録曲  
作詞/作編曲: まふまふ  
絵: まふてる  
歌: まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

a tsu gami no hako ni sute rare ta  
厚紙(あつがみ)の箱(はこ)に捨(す)てられた  
i no chi nara ba ne u chi wa nai ka  
命(いのち)ならば値打(ねう)ちはないか?  
basu tei machi a i ni u zu maku  
バス停(てい) 待(ま)ち合(あい)に渦巻(うずま)く  
mi te mi nu furi no za ttou  
見(み)て見(み)ぬふりの雑踏(ざっとう)

kaki son ji wa dou shi you mo nai ga  
書(か)き損(そん)じはどうしよもないが  
sore ni masaru hedo ga de nai ka  
それに勝(まさ)る反吐(へど)が出(で)ないか?  
sono yuku e wa kyou bi jya  
その行方(ゆくえ)は今日日(きょうび)じゃ  
dare mo shi ra nai  
誰(だれ)も 知(し)らない

haha no te wo ko bo re ta  
母(はは)の手(て)を零(こぼ)れた  
chii sa na i no chi wa  
小(ちい)さな命(いのち)は  
kou bu za seki ni ma saru kachi mo nai  
後部座席(こうぶざせき)に勝(まさ)る価値(かち)もない

nani mono nimo nare ru i no chi de  
何者(なにもの)にもなれる命(いのち)で  
suku e ru mono hito tsu mo nai no da  
救(すく)えるものひとつもないのだ  
kore hodo ni ki you na te saki de  
これほどに器用(きよう)な手先(てさき)で  
suku e ru mono hito tsu mo nai no da  
救(すく)えるものひとつもないのだ  
boku ta chi wa  
僕(ぼく)たちは

soko shi re ta gu don na se ka i da  
底知(そこし)れた愚鈍(ぐどん)な世界(せかい)だ  
kaki mono ni fude wo tore domo  
書(か)き物(もの)に筆(ふで)を取(と)れども  
buchi make ta in ku no sore ga  
ぶちまけたインクのそれが  
hidoku teki setsu de wa na i ka  
ひどく適切(てきせつ)ではないか?

shi ni tai ka to i wa re rya  
死(し)にたいかと言(い)われりゃ  
toku ni shi nu hodo no kodoku demo na i ga  
特(とく)に 死(し)ぬほどの孤独(こどく)でもないが  
i ki tai ka to ware tara  
生(い)きたいか問(と)われたら  
nani mo i e na i  
何(なに)も 言(い)えない

mu nashi sa ni teki shi ta hyou jyou wa dore da  
虚(むな)しさに適(てき)した表情(ひょうじょう)はどれだ  
kaki hajime no koto ba wa  
書(か)き始(はじ)めの言葉(ことば)は

「u mare ta imi nado na ka tta」  
「生(う)まれた意味(いみ)などなかった。」

saki mie nu shou se tsu wo yome ba  
先見(さきみ)えぬ小説(しょうせつ)を読(よ)めば  
mekuri o e nu se ka i ga aru no ka  
捲(めく)り終(お)えぬ世界(せかい)があるのか？  
furi muke ba kuzu reru a shi ba de  
振(ふ)り向(む)けば崩(くず)れる足場(あしば)で  
a shi ta kara doko e muka uno da rou  
明日(あした)から何処(どこ)へ向(む)かうのだろう  
boku ta chi wa  
僕(ぼく)たちは

an no un an no un  
——アンノウン(unknown)——  
「wa tashi wa dare da」  
「私(わたし)は誰(だれ)だ」  
「a nata wa dare da」  
「貴方(あなた)は誰(だれ)だ」

an no un an no un  
——アンノウン(unknown)——  
ke shi te wa ka i te  
消(け)しては書(か)いて  
maru me su tete wa  
丸(まる)め捨(す)てては

an no un an no un  
——アンノウン(unknown)——  
ji bun hitotsu ga ima da kake na i  
自分(じぶん)ひとつが未(いま)だ書(か)けない

u mare ta imi nado nai noka  
生(う)まれた意味(いみ)などないのか？  
u mare ta imi nado nai noka  
生(う)まれた意味(いみ)などないのか？

— u mare ta imi nado nai noda  
——生(う)まれた意味(いみ)などないのだ。

koto kire nu mono nan te nai noni  
事切(ことき)れぬものなんてないのに  
suku e ru mono hito tsu mo nai noni  
救(すく)えるものひとつもないのに  
kono i no chi ni i mi na do nai noni  
この命(いのち)に意味(いみ)などないのに  
yasa shii a shi ta na n te nai noni  
優(やさ)しい明日(あした)なんてないのに

i ka naku cha  
行(い)かなくちゃ  
tato e shi ni muka tte a ru ite ita tte  
たとえ死(し)に向(む)かって歩(ある)いていたって  
kaka naku cha  
書(か)かなくちゃ  
tou zen yo haku mo noko ccha i nai ga  
当然(とうぜん)余白(よはく)も残(のこ)っちゃいないが  
shi ra naku cha  
知(し)らなくちゃ  
a su wo kono to hou mo nai an kai wo  
明日(あす)をこの途方(とほう)もない暗晦(あんかい)を

i ki naku cha  
生(い)きなくちゃ  
i ki naku cha  
生(い)きなくちゃ  
i ki naku cha i ke nai  
生(い)きなくちゃいけない