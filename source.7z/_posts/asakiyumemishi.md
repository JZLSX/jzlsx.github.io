---
title: 「あさきゆめみし」/まふまふ 【罗马音+假名歌词】一「神楽色アーティファクト」
tags:
  - あさきゆめみし
  - 罗马音
  - まふまふ
  - 假名歌词
  - 神楽色アーティファクト
id: '736'
date: 2019-10-16 20:02:24
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026155010.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026155010.jpg
---

「あさきゆめみし」

一「神楽色アーティファクト」アルバム収録曲  
編曲：まふまふ  
作詞・作曲：まふまふ  
vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

gan ji tsu su gi te kara  
元旦(がんじつ)過(す)ぎてから　  
yu bi o ru to shi no se mo  
指折(ゆびお)る年(とし)の瀬(せ)も  
a ma sa zu ki se tsu wo kimi to tsu mu i de  
余(あま)さず季節(きせつ)を君(きみ)と紡(つむ)いで  
i ku to se su gi ta da rou  
幾年(いくとせ)過(す)ぎただろう  
kokoro wa zu tto a no hi demo  
心(こころ)はずっとあの日(ひ)でも  
o to na ni na tta yo  
大人(おとな)になったよ　  
kimi no bun made  
君(きみ)の分(ぶん)まで

naga dou no tai ko tata i te  
長胴(ながどう)の太鼓(たいこ)叩(たた)いて　  
chou chin wa i tsu ka to mo tta  
提灯(ちょうちん)は五日灯(いつかとも)った  
myou nen no mon wo kugu tte  
明年(みょうねん)の門(もん)を潜(くぐ)って　  
hya ku ya ttsu no kane wo ki i ta  
百八(ひゃくやっ)つの鐘(かね)を聞(き)いた  
yuku to shi no naka  
行(ゆ)く年(とし)の中(なか)　  
te wo fu tte i ru  
手(て)を振(ふ)っている

a sa ki yume mi shi kimi wo o mou  
あさきゆめみし 君(きみ)を想(おも)う  
kimi wo naku shi te  
君(きみ)を失(な)くして　  
kimi wo ne da ru  
君(きみ)を強請(ねだ)る  
a sa hi nobo ru wa a ku ru to shi  
朝日昇(あさひのぼ)るは明(あ)くる年(とし)  
kimi wo o ki za ri ni shi te  
君(きみ)を置(お)き去(ざ)りにして

kon na ka na wa na i koto wo u ta u  
こんな叶(かな)わないことを詠(うた)う  
boku wo wa ra tte ku re ru kana  
ボクを笑(わら)ってくれるかな  
a sa ku nemu re ru ma ku ra moto ni  
浅(あさ)く眠(ねむ)れる枕元(まくらもと)に  
kimi wo sa ga shi ni yu ki tai  
君(きみ)を探(さが)しに行(ゆ)きたい

yu ka ta ni me ka shi shi te  
浴衣(ゆかた)に粧(めか)しして　  
mi shi tta jin jya made  
見知(みし)った神社(じんじゃ)まで  
dai da i i ro no tsu ra naru to shi no se  
橙色(だいだいいろ)の連(つら)なる年(とし)の瀬(せ)  
i ku to se su gi you to  
幾年(いくとせ)過(す)ぎようと  
mi to re te shi ma tta a no hi kara  
見惚(みと)れてしまったあの日(ひ)から  
sa ga shi te shi ma u da rou  
探(さが)してしまうだろう　  
yume no naka made  
夢(ゆめ)の中(なか)まで

mou i ku tsu nete ma tou to  
もういくつ寝(ね)て待(ま)とうと　  
mou i ku tsu nete ma tou to  
もういくつ寝(ね)て待(ま)とうと  
kimi yuki no mi rai nara zen bu  
君(きみ)行(ゆ)きの未来(みらい)なら 全部(ぜんぶ)  
a no hi ni no ri ka e te i ta  
あの日(ひ)に乗(の)り換(か)えていた  
yuku to shi no naka  
行(ゆ)く年(とし)の中(なか)  
te wo fu tte i ru  
手(て)を振(ふ)っている

a sa ki yu me mi shi kimi wa ra u  
あさきゆめみし　君笑(きみわら)う  
to ki no to ma tta hana go o ri  
時(とき)の止(と)まった花氷(はなごおり)  
ma bu ta no u ra ni e i sha shi te  
瞼(まぶた)の裏(うら)に映写(えいしゃ)して  
i tsu i tsu i tsu made mo  
何時(いつ)何時(いつ)何時迄(いつまで)も

kon na kana wa na i koto wo u ta u  
こんな叶(かな)わないことを詠(うた)う  
boku wo wara tte ku re ru kana  
ボクを笑(わら)ってくれるかな  
a sa ku nemu re ru ma ku ra moto ni  
浅(あさ)く眠(ねむ)れる枕元(まくらもと)に  
kimi wo sa ga shi ni yu ki tai  
君(きみ)を探(さが)しに行(ゆ)きたい

a sa ki yume mi shi e hi mo se su  
あさきゆめみし　ゑひもせす  
kana wa nu kyou wo shi rou to mo  
叶(かな)わぬ今日(きょう)を知(し)ろうとも  
su ru ri to nu ke ru yubi saki ni  
するりと抜(ぬ)ける指先(ゆびさき)に  
hoo wo nu ra su ba ka ri  
頬(ほお)を濡(ぬ)らすばかり

kokoro hi to tsu ga ta chi do ma ri  
心(こころ)ひとつが立(た)ち止(ど)まり  
i ma da ko se zu ni i ru boku wo  
未(いま)だ越(こ)せずにいるボクを  
kimi ga shi ka tte kure ru hi made  
君(きみ)が叱(しか)ってくれる日(ひ)まで  
kimi wo sa ga shi ni yu ki tai  
君(きみ)を探(さが)しに行(ゆ)きたい

a sa ku nemu re ru ma ku ra moto ni  
浅(あさ)く眠(ねむ)れる枕元(まくらもと)に  
kimi wo sa ga shi ni yu ki tai  
君(きみ)を探(さが)しに行(ゆ)きたい