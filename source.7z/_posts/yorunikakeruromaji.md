---
title: 「夜に駆ける」/まふまふ(歌ってみた)Cover：YOASOBI【罗马音+假名歌词】
tags:
  - 夜に駆ける
  - 罗马音
  - まふまふ
  - 假名歌词
  - Ayase
id: '2898'
date: 2020-05-07 21:54:04
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/05/TaR8yHwj.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/05/TaR8yHwj.jpg
---

「夜に駆ける」

作詞：Ayase  
作曲：Ayase  
唄/Mix：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

shi zu mu you ni to ke te yuku you ni  
沈(しず)むように溶(と)けてゆくように  
fu ta ri dake no sora ga hi ro ga ru yoru ni  
二人(ふたり)だけの空(そら)が広(ひろ)がる夜(よる)に

「sa yo na ra」dake da tta  
「さよなら」だけだった  
sono hito koto de sube ga wa ka tta  
その一言(ひとこと)で全(すべ)てが分(わ)かった  
hi ga shi zu mi da shi ta sora to kimi no su ga ta  
日(ひ)が沈(しず)み出(だ)した空(そら)と君(きみ)の姿(すがた)  
fen su go shi ni kasa na ttei ta  
フェンス越(ご)しに重(かさ)なっていた

ha ji me te a tta hi ka ra  
初(はじ)めて会(あ)った日(ひ)から  
boku no kokoro no sube te wo u ba tta  
僕(ぼく)の心(こころ)の全(すべ)てを奪(うば)った  
doko ka ha ka na i kuu ki wo ma to u kimi wa  
どこか儚(はかな)い空気(くうき)を纏(まと)う君(きみ)は  
sa mi shi i me wo shi te tan da  
寂(さみ)しい目(め)をしてたんだ

i tsu da tte chi kku ta kku to  
いつだってチックタックと  
naru se kai de nan do da tte sa  
鳴(な)る世界(せかい)で何度(なんど)だってさ  
fu reru kokoro nai kotoba u ru sai ko e ni  
触(ふ)れる心(こころ)無(な)い言葉(ことば)うるさい声(こえ)に  
namida ga ko bo re sou demo  
涙(なみだ)が零(こぼ)れそうでも  
a ri ki ta ri na yoro kobi ki tto fu ta ri nara mi tsu ke rareru  
ありきたりな喜(よろこ)びきっと二人(ふたり)なら見(み)つけられる

sa wa ga shii hibi ni wara e nai kimi ni  
騒(さわ)がしい日々(ひび)に笑(わら)えない君(きみ)に  
o mo i tsu ku ka gi ri ma bu shii a su wo  
思(おも)い付(つ)く限(かぎ)り眩(まぶ)しい明日(あす)を  
a ke nai yoru ni o chi te yuku ma e ni  
明(あ)けない夜(よる)に落(お)ちてゆく前(まえ)に  
boku no te wo tsu kan de hora  
僕(ぼく)の手(て)を掴(つか)んでほら  
wa su re te shi ma i taku te to ji ko me ta hibi mo  
忘(わす)れてしまいたくて閉(と)じ込(こ)めた日々(ひび)も  
da ki shi me ta nuku mori de to ka su kara  
抱(だ)きしめた温(ぬく)もりで溶(と)かすから  
ko wa ku na i yo i tsu ka hi ga no bo ru made  
怖(こわ)くないよいつか日(ひ)が昇(のぼ)るまで  
fu tari de i you  
二人(ふたり)でいよう

kimi ni shi ka mi e nai  
君(きみ)にしか見(み)えない  
nani ka wo mi tsu meru kimi ga ki ra i da  
何(なに)かを見(み)つめる君(きみ)が嫌(きら)いだ  
mi tore te i ru ka no you na ko i suru you na  
見惚(みと)れているかのような恋(こい)するような  
son na ka o ga ki ra i da  
そんな顔(かお)が嫌(きら)いだ

shin ji tei tai kedo shin ji re nai koto  
信(しん)じていたいけど信(しん)じれないこと  
son nano dou shi ta tte ki tto  
そんなのどうしたってきっと  
kore kara da tte i ku tsu mo a tte  
これからだっていくつもあって  
sono tan bi o ko tte nai te i ku no  
そのたんび怒(おこ)って泣(な)いていくの  
sore demo ki tto i tsu kawa ki tto bokurawa ki tto  
それでもきっといつかはきっと僕(ぼく)らはきっと  
wa ka ri a e ru sa shi n ji teru yo  
分(わ)かり合(あ)えるさ信(しん)じてるよ

mou i ya da tte tsu ka re ta n da tte  
もう嫌(いや)だって疲(つか)れたんだって  
gamu sha rani sa shi nobe ta baku no te wo furi ha ra u kimi  
がむしゃらに差(さ)し伸(の)べた僕(ぼく)の手(て)を振(ふ)り払(はら)う君(きみ)  
mou i ya da tte tsu ka re ta yo nan te  
もう嫌(いや)だって疲(つか)れたよなんて  
hon tou wa boku mo i i ta i n da  
本当(ほんとう)は僕(ぼく)も言(い)いたいんだ

a  
あ  
hora mata chi kku ta kku to  
ほらまたチックタックと  
naru se kei de nan do da tte sa  
鳴(な)る世界(せかい)で何度(なんど)だってさ  
kimi no tameni you i shi ta kotoba dore mo todo ka nai  
君(きみ)の為(ため)に用意(ようい)した言葉(ことば)どれも届(とど)かない  
「o wa ri ni shi tai」da nan te sa  
「終(お)わりにしたい」だなんてさ  
tsu rare te kotoba ni shi ta toki  
釣(つ)られて言葉(ことば)にした時(とき)  
kimi wa ha ji me te wara tta  
君(きみ)は初(はじ)めて笑(わら)った

sa wa ga shii hibi ni wara e naku na tte i ta  
騒(さわ)がしい日々(ひび)に笑(わら)えなくなっていた  
boku no me ni u tsu ru kimi wa ki re i da  
僕(ぼく)の目(め)に映(うつ)る君(きみ)は綺麗(きれい)だ  
a ke nai yoru ni kobore ta na mi da mo  
明(あ)けない夜(よる)に溢(こぼ)れた涙(なみだ)も  
kimi no e ga o ni to ke te i ku  
君(きみ)の笑顔(えがお)に溶(と)けていく

ka wa ra nai hibi ni na i te i ta boku wo  
変(か)わらない日々(ひび)に泣(な)いていた僕(ぼく)を  
kimi wa yasa shi ku o wa ri e to sa so u  
君(きみ)は優(やさ)しく終(お)わりへと誘(さそ)う  
shi zumu you ni to ke te yuku you ni  
沈(しず)むように溶(と)けてゆくように  
shi mi tsu i ta ki ri ga ha re ru  
染(し)み付(つ)いた霧(きり)が晴(は)れる  
wa su re te shi ma i ta ku te to ji ko me ta hibi ni  
忘(わす)れてしまいたくて閉(と)じ込(こ)めた日々(ひび)に  
sa shi no be te ku re ta kimi no te wo to ru  
差(さ)し伸(の)べてくれた君(きみ)の手(て)を取(と)る  
suzu shii kazu ga sora wo o yo gu you ni i ma fu ki nu ke te i ku  
涼(すず)しい風(かぜ)が空(そら)を泳(およ)ぐように今(いま)吹(ふ)き抜(ぬ)けていく  
tsu na i da te wo ha na sa na i de yo  
繋(つな)いだ手(て)を離(はな)さないでよ  
fu ta ri i ma yoru ni kake da shi te i ku  
二人今(ふたりいま)、夜(よる)に駆(か)け出(だ)していく