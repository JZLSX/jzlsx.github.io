---
title: 「悔やむと書いてミライ」/ まふまふ (self cover)【罗马音+假名歌词】
tags:
  - 悔やむと書いてミライ
  - 罗马音
  - まふまふ
  - 假名歌词
id: '2766'
date: 2020-04-22 21:03:27
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/9XCZZuLY.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/9XCZZuLY.jpg
---

「悔やむと書いてミライ」

<a href="https://www.nicovideo.jp/watch/sm36566206">【MV】最終宣告／まふまふ</a>

作詞作編曲：まふまふ  
絵：456  
映像：Yuma Saito  
歌：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译：[https://mafuclub.com/translation/kuyamutokaitemirai/](https://mafuclub.com/translation/kuyamutokaitemirai/)

hito o mo i ni boku wo sa shi te kure tara  
一思(ひとおも)いにボクを刺(さ)してくれたら  
i i no ni na i i no ni na  
いいのにな いいのにな  
fu jyou ri na go taku de sa shi te kure tara  
不条理(ふじょうり)な御託(ごたく)で刺(さ)してくれたら  
i i no ni na i i no ni na  
いいのにな いいのにな

i tsu ka go mi ni da shi ta noni  
いつかゴミに出(だ)したのに  
sode gu chi ni kaku shi te i ta shou gai  
袖口(そでぐち)に隠(かく)していた生涯(しょうがい)  
mo ya senu mama hai ni nare zuni i tan da-  
燃(も)やせぬまま灰(はい)になれずにいたんだ

shi ni tai ki e tai i jyo u nai  
死(し)にたい 消(き)えたい以上(いじょう)ない  
kon na i no chi ni ki tai wa shi nai sa  
こんな命(いのち)に期待(きたい)はしないさ  
yu e ni yume ni u na sare  
故(ゆえ)に夢(ゆめ)に魘(うな)され  
fu sa i da kako ni sa i ta se kai  
塞(ふさ)いだ過去(かこ)に咲(さ)いた世界(せかい)

i e nai mi e nai ki zu ho do  
癒(い)えない 見(み)えない傷(きず)ほど  
ki tto ka sa bu ta da tte deki ya shi nai to  
きっと瘡蓋(かさぶた)だって出来(でき)やしないと  
boku wa shi te i ta  
ボクは知(し)っていた  
あぁー  
ku ya mu to ka i te mi ra i  
悔(く)やむと書(か)いて ミライ

i ki ru fu ri wo shi te shi n de i ku no ga  
生(い)きるふりをして死(し)んでいくのが  
jin sei ka jin sei da  
人生(じんせい)か 人生(じんせい)だ  
son jya bo ku ra wa dou shi te kono yoni  
それじゃボクらはどうしてこの世(よ)に  
kon na mi kan sei na ka ra da ni  
こんな未完成(みかんせい)な身体(からだ)に  
i ma da ko ko ro wo mo tte i run da  
未(いま)だ 心(こころ)を持(も)っているんだ

ki tto hi sha ge ta jyou ro de  
きっと拉(ひしゃ)げた如雨露(じょうろ)で  
hana wo sa ka se you to shi ta sou sa  
花(はな)を咲(さ)かせようとした そうさ  
tane hito tsu nai tsu chi ni mai cha i nai ka  
種(たね)一(ひと)つない土(つち)に撒(ま)いちゃいないか

da kara i chi nu ke shi ta su te ta  
だから一抜(いちぬ)けした 捨(す)てた  
kono yo no ha ya ri ya ma i no you na ai mo  
この世(よ)の流行(はや)り病(やまい)のような愛(あい)も  
tsu me no saki yo ri mo ho so i  
爪(つめ)の先(さき)よりも細(ほそ)い  
so ko a sa i yuu no jyou a i mo  
底浅(そこあさ)い友(ゆう)の情愛(じょうあい)も

shi ra nai shi ri tai ko to mo nai  
知(し)らない 知(し)りたいこともない  
dou se koto ba i jyou no i mi na do nai to  
どうせ言葉以上(ことばいじょう)の意味(いみ)などないと  
boku wa shi tte i ta  
ボクは知(し)っていた  
あぁー  
ku ya mu to ka i te mi ra i  
悔(く)やむと書(か)いて ミライ

ka ta mi chi bun no rou wo mo tte  
片道分(かたみちぶん)の蝋(ろう)を持(も)って  
ke sa na i you ni hi sshi ni na tte  
消(け)さないように必死(ひっし)になって  
wa zu ka te ra shi ta i ssun saki no  
わずか照(て)らした一寸先(いっすんさき)の  
a na boko wa dare ga o chi ta a to？  
穴(あな)ぼこは誰(だれ)が落(お)ちた跡(あと)？

sore ga jin sei desu  
それが人生(じんせい)です  
boku ra te ni shi ta jin sei nan desu  
ボクら手(て)にした人生(じんせい)なんです  
あぁー  
u ma re ta ko to ji ta i ga  
生(う)まれたこと自体(じたい)が  
ma chi ga i da tta no？  
間違(まちが)いだったの？

shi ni tai ki e tai i jyo u na i  
死(し)にたい 消(き)えたい以上(いじょう)ない  
kon na i no chi ni ki tai wa shi nai sa  
こんな命(いのち)に期待(きたい)はしないさ  
yu e ni yume ni u na sare  
故(ゆえ)に夢(ゆめ)に魘(うな)され  
fu sa i da kako ni sa i ta se kai  
塞(ふさ)いだ過去(かこ)に咲(さ)いた世界(せかい)

i e nai mi e nai ki zu ho do  
癒(い)えない 見(み)えない傷(きず)ほど  
ki tto ka sa bu ta da tte deki ya shi nai to  
きっと瘡蓋(かさぶた)だって出来(でき)やしないと  
boku wa shi te i ta  
ボクは知(し)っていた  
あぁー  
ku ya mu to ka i te mi ra i  
悔(く)やむと書(か)いて ミライ  
ku ya mu to ka i te mi ra i  
悔(く)やむと書(か)いて ミライ

ki e tai no ki e tai no  
消(き)えたいの 消(き)えたいの  
nan kai da tte ii ki kase ta  
何回(なんかい)だって言(い)い聞(き)かせた  
yu me mo mi re nu you na  
夢(ゆめ)も見(み)れぬような  
kou kai wo chou dai  
後悔(こうかい)を頂戴(ちょうだい)