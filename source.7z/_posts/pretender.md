---
title: 「Pretender」/まふまふ 歌ってみた【罗马音+假名歌词】
tags:
  - Pretender
  - 罗马音
  - まふまふ
  - 假名歌词
id: '714'
date: 2019-09-27 19:34:31
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/35737767.21887043.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/35737767.21887043.jpg
---

「Pretender」

作詞・作曲：藤原聡  
絵：△〇□×  
Acoustic Guitar：三矢禅晃  
Mix・唄：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

kimi to no rabu su to-ri-  
君(きみ)とのラブストーリー  
sore wa yo sou doo ri  
それは予想(よそう)通(どお)り  
i za haji ma re ba hi to ri shi bai da  
いざ始(はじ)まればひとり芝居(しばい)だ  
zu tto so ba ni i ta tte  
ずっとそばにいたって  
ke kkyo ku tada no kan kya ku da  
結局(けっきょく)ただの観客(かんきゃく)だ

kan jyou no na i ai mu so-ri-  
感情(かんじょう)のないアイムソーリー  
sore wa i tsu mo doo ri  
それはいつも通(どお)り  
nare te shi ma e ba waru ku wa nai ke do  
慣(な)れてしまえば悪(わる)くはないけど  
kimi to no ro man su wa jin se i gara  
君(きみ)とのロマンスは人生柄(じんせいがら)  
tsu zu ki wa shi na i koto wo shi tta  
続(つづ)きはしないことを知(し)った

mo tto chi ga u se tte i de  
もっと違(ちが)う設定(せってい)で　  
mo tto chi ga u kan ke i de  
もっと違(ちが)う関係(かんけい)で  
de a e ru se kai sen  
出会(であ)える世界線(せかいせん)  
e ra be tara yo ka tta  
選(えら)べたらよかった

mo tto chi ga u sei kaku de  
もっと違(ちが)う性格(せいかく)で　  
mo tto chi ga u kachi kan de  
もっと違(ちが)う価値観(かちかん)で  
ai wo tsu ta e ra re tara ii na  
愛(あい)を伝(つた)えられたらいいな　  
sou nega tte mo muda da kara  
そう願(ねが)っても無駄(むだ)だから

gu bba i  
グッバイ(goodbye)

kimi no un mei no hito wa boku jya na i  
君(きみ)の運命(うんめい)のヒトは僕(ぼく)じゃない  
tsu rai ke do i na me na i  
辛(つら)いけど否(いな)めない　  
demo hana re ga ta i no sa  
でも離(はな)れ難(がた)いのさ  
sono kami ni fu re ta dake de  
その髪(かみ)に触(ふ)れただけで　  
i ta i ya i ya de mo  
痛(いた)いや いやでも  
a ma i na i ya i ya  
甘(あま)いな いやいや

gu bba i  
グッバイ(goodbye)

sore jya boku ni to tte kimi wa nani  
それじゃ僕(ぼく)にとって君(きみ)は何(なに)？  
ko ta e wa wa kara na i  
答(こた)えは分(わ)からない　  
wa ka ri taku mo na i no sa  
分(わ)かりたくもないのさ  
ta tta hi to tsu ta shi ka na koto ga a ru to suru no nara ba  
たったひとつ確(たし)かなことがあるとするのならば  
「kimi wa ki re i da」  
「君(きみ)は綺麗(きれい)だ」

dare ka ga e ra sou ni  
誰(だれ)かが偉(えら)そうに  
ka ta ru ren ai no ron ri  
語(かた)る恋愛(れんあい)の論理(ろんり)  
nani hito tsu to shi te pin to ko naku te  
何(なに)ひとつとしてピンとこなくて  
hi kou ki no mado kara mi o ro shi ta  
飛行機(ひこうき)の窓(まど)から見下(みお)ろした  
shi ra nai ma chi no ya ke i mi tai da  
知(し)らない街(まち)の夜景(やけい)みたいだ

mo tto chi ga u se tte i de  
もっと違(ちが)う設定(せってい)で　  
mo tto chi ga u kan ke i de  
もっと違(ちが)う関係(かんけい)で  
de a e ru se kai sen  
出会(であ)える世界線(せかいせん)  
e ra be tara yo ka tta  
選(えら)べたらよかった  
i ta tte jun na kokoro de  
いたって純(じゅん)な心(こころ)で　  
kana tta ko i wo daki shi me te  
叶(かな)った恋(こい)を抱(だ)きしめて  
「suki da」toka mu se ki nin ni i e tara ii na  
「好(す)きだ」とか無責任(むせきにん)に言(い)えたらいいな  
sou nega tte mo muna shii no sa  
そう願(ねが)っても虚(むな)しいのさ

gu bba i  
グッバイ(goodbye)

tsu na i da te no mu ko u ni en do ra in  
繋(つな)いだ手(て)の向(む)こうにエンドライン  
hi ki no ba su ta bi ni  
引(ひ)き伸(の)ばすたびに　  
u zu ki dasu mi ra i ni wa  
疼(うず)きだす未来(みらい)には  
kimi wa i nai  
君(きみ)はいない　  
so no ji ji tsu ni ku ra i…  
その事実(じじつ)にCry(くらい)…  
so rya kuru shii yo na  
そりゃ苦(くる)しいよな

gu bba i  
グッバイ(goodbye)

kimi no un mei no hito wa boku jya na i  
君(きみ)の運命(うんめい)のヒトは僕(ぼく)じゃない  
tsu rai ke do i na me nai  
辛(つら)いけど否(いな)めない　  
demo hana re ga ta i no sa  
でも離(はな)れ難(がた)いのさ  
sono kami ni fu re ta dake de  
その髪(かみ)に触(ふ)れただけで　  
i ta i ya i ya de mo  
痛(いた)いや いやでも　  
a ma i na i ya i ya  
甘(あま)いな いやいや

gu bba i  
グッバイ(goodbye)

sore jya boku ni to tte kimi wa nani  
それじゃ僕(ぼく)にとって君(きみ)は何(なに)？  
ko ta e wa wa kara nai  
答(こた)えは分(わ)からない　  
wa ka ri taku mo na i no sa  
分(わ)かりたくもないのさ  
ta tta hito tsu ta shi ka na koto ga a ru to suru no nara ba  
たったひとつ確(たし)かなことがあるとするのならば  
「kimi wa ki re i da」  
「君(きみ)は綺麗(きれい)だ」

sore mo kore mo ro man su no sa da me nara  
それもこれもロマンスの定(さだ)めなら　  
waru ku na i yo na  
悪(わる)くないよな  
ei en mo yaku soku mo nai kere do  
永遠(えいえん)も約束(やくそく)もないけれど  
「to te mo ki re i da」  
「とても綺麗(きれい)だ」