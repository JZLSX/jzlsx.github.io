---
title: 「7」「UNHAPPY CLUB 」/神様、僕は気づいてしまった【罗马音+假名歌词】
tags:
  - UNHAPPY CLUB
  - 神様、僕は気づいてしまった
  - 罗马音
  - 假名歌词
id: '725'
date: 2019-10-12 19:48:43
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
---

「UNHAPPY CLUB 」

神様、僕は気づいてしまった  
－「20XX」アルバム収録曲

作詞：東野へいと  
作曲：東野へいと  
vocal：どこのだれか

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

hai kyou no gyou re tsu wo  
配給(はいきゅう)の行列(ぎょうれつ)を　  
an tan ta ru ka o shi te a ru i ta  
暗澹(あんたん)たる顔(かお)して歩(ある)いた  
sai zen de wa tei do no shi re ta  
最前(さいぜん)では程度(ていど)の知(し)れた  
kuzu tachi ga yoko i ri wo shi teru  
屑達(くずたち)が横入(よこい)りをしてる

bu be tsu teki na i chi be tsu de  
侮蔑的(ぶべつてき)な一瞥(いちべつ)で　  
na ge ya ri ni te wata sare ta no wa  
投(な)げやりに手渡(てわた)されたのは  
dare kaga a ki ra me ta  
誰(だれ)かが諦(あきら)めた　  
yume no zan shi de mi chi ta su-pu  
夢(ゆめ)の残滓(ざんし)で満(み)ちたスープ

soko no a sa i bou ru de  
底(そこ)の浅(あさ)いボウルで　  
sore wo so za tsu ni kaki maze te mi re ba  
それを粗雑(そざつ)にかき混(ま)ぜてみれば  
u tsu wa kara i ki o i yoku  
器(うつわ)から勢(いきお)い良(よ)く　  
fu guu no namida ga do tto  
不遇(ふぐう)の涙(なみだ)がどっと  
to bi chi ru  
飛(と)び散(ち)る

aa～  
嗚呼(ああ)  
nan te ta nin no waza wa i wa  
なんて他人(たにん)の災(わざわ)いは  
kon na ni mo mizu mizu shii  
こんなにも瑞々(みずみず)しい  
re tsu wo mi da shi te sa e mo  
列(れつ)を乱(みだ)してさえも  
dare mo ga dare ka no fu kou wo  
誰(だれ)もが誰(だれ)かの不幸(ふこう)を  
yoko toru ji dai da  
横取(よこと)る時代(じだい)だ

na wo tsu ra ne ru (UNHAPPY CLUB)  
名(な)を連(つら)ねるUNHAPPY CLUB  
u gou no shuu ni  
烏合(うごう)の衆(しゅう)に  
so ma cha i na i ka  
染(そ)まっちゃいないか　  
shi n pa ni no ma re rya  
シンパに飲(の)まれりゃ  
bake mono ni naru  
化物(ばけもの)になる

mata kyou ri no kizu ga  
また胸裏(きょうり)の傷(きず)が  
tachi machi to i ta mi da shi te  
忽(たちま)ちと痛(いた)み出(だ)して　  
tada nou ri jya nan mo  
ただ脳裏(のうり)じゃ何(なん)も  
kan ga e ru yo chi ga na kute  
考(かんが)える余地(よち)が無(な)くて  
mou i kkai  
もう一回(いっかい)　  
sou ya tte mou nan kai  
そうやってもう何回(なんかい)　  
he ya no sumi ni kokoro wo  
部屋(へや)の隅(すみ)に心(こころ)を  
o i ya tten da  
追(お)いやってんだ

mada hon tou no ko e to dou shi demo  
まだ本当(ほんとう)の声(こえ)とどうしても  
mu ki a e naku te  
向(む)き合(あ)えなくて  
tada tai ro wo zu tto ha i zu tte  
ただ退路(たいろ)をずっと這(は)いずって  
kara ma wa ri shi te  
空回(からまわ)りして  
kuta baru ki kai wo ma tte i ru dake no  
くたばる機会(きかい)を待(ま)っているだけの  
a sai ji bun ni yu rai de iku  
浅(あさ)い自分(じぶん)に揺(ゆ)らいでいく

han ka i no dou ri wo dou ni ka ba kku ba kku ni  
半壊(はんかい)の道理(どうり)をどうにかバックパックに  
a ru dake tsu me kon de  
あるだけ詰(つ)め込(こ)んで  
boro i chi mi tai ni i ssai no kan jyou wo tata ki u tta  
ボロ市(いち)みたいに一切(いっさい)の感情(かんじょう)を叩(たた)き売(う)った  
sou ya tte ku i tsu na i da  
そうやって食(く)い繋(つな)いだ  
wazu kana te ma chin mo tte  
僅(わず)かな手間賃(てまちん)持(も)って  
do ya gai jyuu no dou jyou ni ka buri tsu i ta  
どや街中(がいじゅう)の同情(どうじょう)にかぶりついた

a i sa re ru da ke ga  
愛(あい)されるだけが　  
boku ra no su be te da  
僕等(ぼくら)の全(すべ)てだ  
mou hiki ka e se ya shi nai to o mo tta  
もう引(ひ)き返(かえ)せやしないと思(おも)った  
ya tsu ra no shi wa ku doo ri  
奴(やつ)らの思惑通(しわくどお)り  
i bu ku ro no naka  
胃袋(いぶくろ)の中(なか)

mata mai go no boku ga  
また迷子(まいご)の僕(ぼく)が  
tachi machi to wa me ki da shi te  
忽(たちま)ちと喚(わめ)き出(だ)して　  
kara kai no se ri fu wo  
揶揄(からか)いの台詞(せりふ)を  
nan do temo kuri ka e shi te  
何度(なんど)でも繰(く)り返(かえ)して  
mou i kka i  
もう一回(いっかい)　  
sou kou shi te nan man kai  
そうこうして何万回(なんまんかい)  
a to dore dake kou shi te rya  
後(あと)どれだけこうしてりゃ  
suku wa re masu ka  
救(すく)われますか

shi ra nai fu ri wo shite sai ge tsu ga  
知(し)らない振(ふ)りをして歳月(さいげつ)が  
su gi sa tte i ki  
過(す)ぎ去(さ)っていき  
a ra ga u koto sa e no i sshun mo  
抗(あらが)うことさえの一瞬(いっしゅん)も  
o ko ta tte ki te  
怠(おこた)ってきて  
i tsu ma de mon suta- no shi bai wo shi ten da  
いつまでモンスターの芝居(しばい)をしてんだ

mata kyou ri no kizu ga  
また胸裏(きょうり)の傷(きず)が  
tachi machi to i ta mi da shi te  
忽(たちま)ちと痛(いた)み出(だ)して　  
tada nou ri jya nan mo  
ただ脳裏(のうり)じゃ何(なん)も  
kan ga e ru yo chi ga na kute  
考(かんが)える余地(よち)が無(な)くて  
mou i kkai  
もう一回(いっかい)　  
sou ya tte mou nan kai  
そうやってもう何回(なんかい)　  
he ya no sumi ni kokoro wo  
部屋(へや)の隅(すみ)に心(こころ)を  
o i ya tten da  
追(お)いやってんだ

mada hon tou no ko e to dou shi demo  
まだ本当(ほんとう)の声(こえ)とどうしても  
mu ki a e naku te  
向(む)き合(あ)えなくて  
tada tai ro wo zu tto ha i zu tte  
ただ退路(たいろ)をずっと這(は)いずって  
kara ma wa ri shi te  
空回(からまわ)りして  
kuta baru ki kai wo ma tte i ru dake no  
くたばる機会(きかい)を待(ま)っているだけの  
a sai ji bun ni hi ta tte i ru  
浅(あさ)い自分(じぶん)に浸(ひた)っている