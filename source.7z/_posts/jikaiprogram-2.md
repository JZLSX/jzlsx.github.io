---
title: 「自壊プログラム」/ まふまふ 【罗马音+假名歌词】一「神楽色アーティファクト」
tags:
  - まふまふ
  - 罗马音
  - まふまふ
  - 假名歌词
  - 神楽色アーティファクト
id: '730'
date: 2019-10-16 19:54:39
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026112537.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026112537.jpg
---

「自壊プログラム」

一「神楽色アーティファクト」アルバム収録曲  
編曲：まふまふ  
作詞・作曲：まふまふ  
Vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

to ri ka kon de kyou no han ke tsu  
取(と)り囲(かこ)んで今日(きょう)の判決(はんけつ)  
yaku ta ta zu wa i ra nai  
役立(やくた)たずはいらない  
to na ri no i su made u ba i to re  
隣(となり)の椅子(いす)まで奪(うば)い取(と)れ

ke tsu wo to ccha re tsu wo na shi te  
決(けつ)を採(と)っちゃ列(れつ)を成(な)して  
mi gi ni na ra u da ke  
右(みぎ)に倣(なら)うだけ  
me de ta ku shi kei shi kkou no hi da  
めでたく死刑執行(しけいしっこう)の日(ひ)だ

fu you to sa re ta hi to tsu no jin ka ku wa  
不要(ふよう)とされたひとつの人格(じんかく)は  
e da ha ni wa ka re te i ku  
枝葉(えだは)に分(わ)かれていく  
son na no son na no  
そんなの　そんなの　  
boku ra ta ga i ni na ji tte  
ボクら互(たが)いに詰(なじ)って  
fun de ne ji ma ge rare ta shi na ri o  
踏(ふ)んでねじ曲(ま)げられたシナリオ

na ri hi bi ku kei shou  
鳴(な)り響(ひび)く警鐘(けいしょう)　  
e ra -suru no i zu  
エラーするノイズ  
ji kai se i no pu ro gu ra mu  
自壊性(じかいせい)のプログラム  
boku ga i nai boku ga i nai  
ボクがいない　ボクがいない  
ka ra da ga i ta mi ta ga ru no ni  
身体(からだ)が痛(いた)みたがるのに

kono ji son shin ga  
この自尊心(じそんしん)が  
kyo ei shin ga  
虚栄心(きょえいしん)が  
kokoro wo o ka shi te i ku  
ココロを侵(おか)していく  
zen bu o ma e no sei nan da  
全部(ぜんぶ)お前(まえ)のせいなんだ  
i sshou shi ta ri ga o de mi ku da shi te i ro  
一生(いっしょう)したり顔(がお)で見下(みくだ)していろ

「mou se ka i wo ki ra u koto mo nai。」  
「もう世界(せかい)を嫌(きら)うこともない。」  
ri fa ren su wa ga men go shi no ka o  
リファレンスは画面越(がめんご)しの顔(かお)  
ha ya ri ni so tta ka men i gai wa  
流行(はや)りに沿(そ)った仮面(かめん)以外(いがい)は  
hyou teki to naru  
標的(ひょうてき)となる

『te sa gu ri no kura yami  
『手(て)さぐりの暗闇(くらやみ)  
mu se ka e ru do yo me ki  
むせ返(かえ)るどよめき  
mu suu ni to bi ka u koto no ya i ba

無数(むすう)に飛(と)び交(か)う言(こと)の刃(やいば)  
chi ma nako ni na tte  
血眼(ちまなこ)になって  
sa shi ka e shi ta sono ka o wa  
刺(さ)し返(かえ)したその顔(かお)は  
boku ni yoku ni te i ma shi ta。』  
ボクによく似(に)ていました。』

se kai kei kuu sou  
セカイ系(けい)空想(くうそう)　  
ki nou tei shi an dwu  
機能停止(きのうていし)アンドゥ  
su ga ta mi kai ri shi te  
姿見(すがたみ)　乖離(かいり)して  
nan do demo nan do demo  
何度(なんど)でも　何度(なんど)でも  
tobi o ki te mu se bi naku dake  
飛(と)び起(お)きて咽(むせ)び泣(な)くだけ

nee shi ka tte kure tata i te kure  
ねえ 叱(しか)ってくれ 叩(たた)いてくれ  
ko wa su hodo ni ai shi te yo  
壊(こわ)すほどに愛(あい)してよ  
ki tto a ta ma jya wa ka tte run da  
きっと頭(あたま)じゃわかってるんだ  
kono kuu haku wa sho ki no shi you da rou  
この空白(くうはく)は初期(しょき)の仕様(しよう)だろう

dou shi te ？ dou shi te ？  
どうして？どうして？  
ha ji ki a tte wa ki zu i ta  
弾(はじ)き合(あ)っては気(き)づいた  
a i tsu mo ko i tsu mo  
あいつも こいつも  
u ta ga u yo chi mo naku ji bun da  
疑(うたが)う余地(よち)もなく自分(じぶん)だ

na ri hi bi ku kei shou  
鳴(な)り響(ひび)く警鐘(けいしょう)  
e ra- suru no i zu  
エラーするノイズ  
ji kai se i no pu ro gu ra mu  
自壊性(じかいせい)のプログラム  
boku ga i nai boku ga i nai  
ボクがいない　ボクがいない  
ka ra da ga i ta mi ta ga ru no ni  
身体(からだ)が痛(いた)みたがるのに

kono ji son shin ga  
この自尊心(じそんしん)が  
kyo ei shin ga  
虚栄心(きょえいしん)が  
kokoro wo o ka shi te i ku  
ココロを侵(おか)していく  
zen bu o ma e no sei nan da  
全部(ぜんぶ)お前(まえ)のせいなんだ  
sen ten sei no ji ga wo noro tte  
先天性(せんてんせい)の自我(じが)を呪(のろ)って  
i sshou shi ta ri ga o de mi ku da shi te i ro  
一生(いっしょう)したり顔(がお)で見下(みくだ)していろ