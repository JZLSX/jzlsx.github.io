---
title: 「ポケットモンスターOP】/1・2・3 After the Rain(そらる×まふまふ)罗马音+假名歌词
tags:
  - 1・2・3
  - After the Rain
  - そらる
  - 罗马音
  - まふまふ
  - 假名歌词
id: '822'
date: 2019-11-19 01:40:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/7D684CDC-9C36-46BF-95C6-131D2A4DDE87.jpeg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/7D684CDC-9C36-46BF-95C6-131D2A4DDE87.jpeg
---

《ポケットモンスターOP》  
ー「1・2・3」  
作詞/作曲/編曲：まふまふ  
歌：After the Rain(そらる×まふまふ)  
映像：MONO-Devoid  
絵：そらる×まふまふイラスト SSS by applinot  
ポケモンイラスト アニメ「ポケットモンスター」より

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

nee mada mada mada ？ i so i de！  
ねえ、まだまだまだ？急(いそ)いで！  
de ka ke ru jun bi wa de ki ta kai？  
出(で)かける準備(じゅんび)はできたかい？  
kimi ni mi se tai fu shi gi no se kai  
キミに見(み)せたい不思議(ふしぎ)の世界(せかい)  
mi o ku ri nara i ra na i  
見送(みおく)りならいらない

ta to e hi no naka mi zu no naka  
たとえ火(ひ)の中(なか) 水(みず)の中(なか)  
te sa gu ri de mi e nai kyou no naka  
手(て)さぐりで見(み)えない今日(きょう)の中(なか)  
i chi byou saki da tte ma da shi ra na i ke do  
1秒先(いちびょうさき)だってまだ知(し)らないけど

i tsu mo o mo i de wa do re mo  
いつも思(おも)い出(で)はどれも  
zen bu bo- ru no naka ni  
全部(ぜんぶ)ボールの中(なか)に

wan・tsu-・suri- de to bi ko me！  
1(ワン)・2(ツー)・3(スリー)で 飛(と)び込(こ)め！  
i tsu ka e ga i ta mi rai ga  
いつか描(えが)いた未来(みらい)が  
boku no po ke tto ni a ru kara  
ボクのポケットにあるから

ha ji me ma shi te wa i tsu da tte ha ji me te sa  
はじめましてはいつだって初(はじ)めてさ  
ta me ra u koto na do  
ためらうことなど  
na i (na i )to rai (to rai)  
ナイ！(ナイ!) トライ！(トライ!)  
Let's have a fight！

i chi .ba to ru wo shi ta nara  
1(いち).バトルをしたなら  
ni. wara u ka na i ta tte  
2(に).笑(わら)うか泣(な)いたって  
san de na ka ma ni na rou yo  
3(さん)で仲間(なかま)になろうよ

a no hi da tte ko no hi da tte  
あの日(ひ)だって この日(ひ)だって  
i tsu da tte sou shi te i ta  
いつだってそうしていた  
sa ki mo mi e nai  
先(さき)も見(み)えない  
ha te mo shi ra nai  
果(は)ても知(し)らない  
se ka i ga soko ni a ru ke do  
世界(せかい)がそこにあるけど

re ttsu go- ko ron de su ri mu i te  
レッツゴー 転(ころ)んですりむいて  
re ttsu go- nan do mo a ru ki da su to na ri  
レッツゴー 何度(なんど)も歩(ある)き出(だ)す隣(となり)  
kimi ni ki me ta ！  
キミにきめた！

to na ri no ma chi kara ke shi ki wa  
隣(となり)の街(まち)から景色(けしき)は  
ta me i ki tsu ku hodo se ka i wa  
ため息(いき)つくほど世界(せかい)は  
me ma gu ru shi ku ma wa ri ka wa ru  
目(め)まぐるしく回(まわ)り 変(か)わる  
boku wo o ki za ri ni su ru  
ボクを置(お)き去(ざ)りにする

ko do mo no koro ni wa mu chuu de  
子供(こども)の頃(ころ)には夢中(むちゅう)で  
ku gu ri nu ke ta a na bo ko demo  
くぐり抜(ぬ)けた穴(あな)ぼこでも  
shi ba ra ku bu ri da na mi o to shi te i ta no？  
しばらくぶりだな 見落(みお)としていたの？

demo ne wa su re ta ke shi ki mo  
でもね 忘(わす)れた景色(けしき)も  
kyou no do ko ka ni a ru yo  
今日(きょう)のどこかにあるよ

wan・tsu-・suri- de to bi da se ！  
1(ワン)・2(ツー)・3(スリー)で 飛(と)び出(だ)せ！  
san zan da tte na i te i ta  
散々(さんざん)だって 泣(な)いていた  
hibi to bo- ru no so to ma de  
日々(ひび)とボールの外(そと)まで  
「do ko e yu kou ka」wa  
「どこへ行(ゆ)こうか？」は  
「do ko e da tte yu ke ru 」de sho？  
「どこへだって行(ゆ)ける」でしょ？

i ki tsu ku hi ma nado  
息(いき)つく暇(ひま)など  
na i (na i )to rai (to rai)  
ナイ！(ナイ!) トライ！(トライ!)  
Why don't we go？

i chi ko to ba wo ko e te  
1(いち) 言葉(ことば)を越(こ)えて  
ni kyou kai sen no saki no  
2(に) 境界線(きょうかいせん)の先(さき)の  
ma da mi nu kimi ma de  
まだ見(み)ぬ君(きみ)まで

ta o re ru nara te wo tsu ku nara  
倒(たお)れるなら 手(て)をつくなら  
ma e da tte ki me tan da  
前(まえ)だって決(き)めたんだ  
hi ga shi zu mu you ni ka ge no bi te  
日(ひ)が沈(しず)むように影伸(かげの)びて  
se ta ke mo ka wa tte i ru ke do  
背丈(せたけ)も変(か)わっているけど

re ttsu go- a me a ga ri de naku cha  
レッツゴー 雨上(あめあ)がりでなくちゃ  
re ttsu go- ha re ma ni ni ji wa na i  
レッツゴー 晴(は)れ間(ま)に虹(にじ)はない  
a no hi kara ki zu i te i ru  
あの日(ひ)から気(き)づいている

kimi wa kimi wa  
君(きみ)は 君(きみ)は  
「i tsu no ma ni yara o to nani na ccha i nai kai」  
「いつの間(ま)にやら 大人(おとな)になっちゃいないかい？」

ho ko ri wo ka bu tta boro gi no  
ほこりを被(かぶ)った ボロ着(ぎ)の  
mi gi po kke ni o i te ki ta  
右(みぎ)ぽっけに置(お)いてきた  
ka ta te ni o sa ma ru bou ken  
片手(かたて)に収(おさ)まる冒険(ぼうけん)  
boku ra no su be te da tta  
ボクらの全(すべ)てだった

a no koro no o mo i de ga  
あの頃(ころ)の思(おも)い出(で)が  
kimi wo sa ga shi te i ru yo  
君(きみ)を探(さが)しているよ

wan・tsu-・suri- de to bi ko me！  
1(ワン)・2(ツー)・3(スリー)で 飛(と)び込(こ)め！  
i tsu ka e ga i ta mi rai ga  
いつか描(えが)いた未来(みらい)が  
boku no po ke tto ni a ru kara  
ボクのポケットにあるから

doko ka e i kou yo  
どこかへ行(い)こうよ  
doko e da tte tsu re te i tte yo  
どこへだって連(つ)れていってよ  
ta me ra u koto nado  
ためらうことなど  
na i (na i )to rai (to rai)  
ナイ！(ナイ!) トライ！(トライ!)  
Let's have a fight！

i chi .ba to ru wo shi ta nara  
1(いち).バトルをしたなら  
ni. wara u ka na i ta tte  
2(に).笑(わら)うか泣(な)いたって  
san de na ka ma ni na rou yo  
3(さん)で仲間(なかま)になろうよ

a no hi da tte kono hi da tte  
あの日(ひ)だって この日(ひ)だって  
i tsu da tte sou shi te i ta  
いつだってそうしていた  
saki mo mi e nai  
先(さき)も見(み)えない  
ha te mo shi ra nai  
果(は)ても知(し)らない  
se ka i ga soko ni a ru ke do  
世界(せかい)がそこにあるけど

re ttsu go- ko ron de su ri mu i te  
レッツゴー 転(ころ)んですりむいて  
re ttsu go- nan do mo a ru ki da su to na ri  
レッツゴー 何度(なんど)も歩(ある)き出(だ)す隣(となり)  
kimi ni ki me ta ！  
キミにきめた！