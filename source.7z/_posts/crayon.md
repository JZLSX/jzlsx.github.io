---
title: 【歌词翻译】夜空のクレヨン／まふまふ
tags:
  - まふまふ
  - 歌词翻译
  - 夜空のクレヨン
  - 中文歌词
id: '3119'
date: 2020-07-07 20:10:14
category: 歌词翻译
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/07/maxresdefault-8.jpg
---

[https://m.weibo.cn/status/Ja7St0TqS?display=0&retcode=6102](https://m.weibo.cn/status/Ja7St0TqS?display=0&retcode=6102)