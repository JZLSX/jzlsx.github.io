---
title: 「名前の無い青」/ 神様、僕は気づいてしまった| 别对映象研出手 ED 假名歌词+罗马音
tags:
  - 名前の無い青
  - 歌词翻译
  - 中文歌词
  - 神様、僕は気づいてしまった
id: '1441'
date: 2020-01-10 16:49:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/01/QQ截图20200112221155.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/01/QQ截图20200112221155.jpg
---

「名前の無い青」  
ー 《神様、僕は気づいてしまった》

作詞/作曲：和泉りゅーしん  
Vocal：どこのだれか

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

kodoku no u chi ni ta me kon da  
孤独(こどく)の内(うち)に溜(た)め込(こ)んだ  
kuu sou no ta gu i  
空想(くうそう)の類(たぐい)  
dou shi ta tte zu tto  
どうしたってずっと  
kotoba ni de ki zu ni  
言葉(ことば)に出来(でき)ずに

o sa na sa yu e  
幼(おさな)さ故(ゆえ)  
chi i sa na kono ryo u te kara  
小(ちい)さなこの両手(りょうて)から  
a fu re te tsu i ni wa  
溢(あふ)れてついには  
kyan basu wo u me tsu ku shi ta  
キャンバスを埋(う)め尽(つ)くした

su i hei sen kara ni ji mu you de  
水平線(すいへいせん)から滲(にじ)むようで  
hi e ki tta hoho wo tsu ta u you na  
冷(ひ)え切(き)った頬(ほほ)を伝(つた)うような  
a tata ka na sono i ro ga boku no  
暖(あたた)かなその色(いろ)が僕(ぼく)の　  
ko e ni na tte i ku  
声(こえ)になっていく

sou zou ga gen ji tsu wo ryou ga shi te  
想像(そうぞう)が現実(げんじつ)を凌駕(りょうが)して  
o mo ku ta re ta kumo ga chi tta  
重(おも)く垂(た)れた雲(くも)が散(ち)った  
sono ke shi ki wo no ko se ta nara  
その景色(けしき)を遺(のこ)せたなら

sen nen go no shi ra nai dare ka no me ni  
千年後(せんねんご)の知(し)らない誰(だれ)かの目(め)に  
boku no ko e ga tsu ki sasa ru you na  
僕(ぼく)の声(こえ)が突(つ)き刺(さ)さるような  
a za ya ka na i ro  
鮮(あざ)やかな色(いろ)　  
sore wa mada na ma e no na i i ro  
それはまだ名前(なまえ)のない色(いろ)

kodoku no u chi ni ta me kon da  
孤独(こどく)の内(うち)に溜(た)め込(こ)んだ  
kuu sou no ta gu i  
空想(くうそう)の類(たぐい)  
dare ka to wa ke a u  
誰(だれ)かと分(わ)け合(あ)う  
koto sura de ki zu ni  
ことすら出来(でき)ずに

kokoro no o ku soko de  
心(こころ)の奥底(おくそこ)で  
i ma mo u go me i te ru  
今(いま)も蠢(うごめ)いてる  
na ma e wo mo ta na i  
名前(なまえ)を持(も)たない  
kono kan jyou wo nan to yo bou ka  
この感情(かんじょう)をなんと呼(よ)ぼうか

wa su re nai you ni  
忘(わす)れないように　  
na ku sa nai you ni  
失(な)くさないように

a su wo u re i ta haru no you de  
明日(あす)を憂(うれ)いた春(はる)のようで  
kono mi ni ha shi ru mya ku no you na  
この身(み)に走(はし)る脈(みゃく)のような  
ya wa ra ka na sono i ro de  
柔(やわ)らかなその色(いろ)で  
boku wa boku ni na tte i ta  
僕(ぼく)は僕(ぼく)になっていた

ma sshi ro na kyan basu ni bu tsu keta mi ra i wa  
真(ま)っ白(しろ)なキャンバスにぶつけた未来(みらい)は  
i tsu shi ka i no chi ni na tte  
いつしか命(いのち)になって  
boku ga i ki ta a ka shi ni na ru  
僕(ぼく)が生(い)きた証(あかし)になる

sen nen go no  
千年後(せんねんご)の  
shi ra nai dere ka no se i wo  
知(し)らない誰(だれ)かの生(せい)を  
ko n te i kara ku tsu ga e su you na  
根底(こんてい)から覆(くつがえ)すような  
a za ya ka na i ro  
鮮(あざ)やかな色(いろ)　  
i ki wo no mu hodo u tsu ku shi ku te  
息(いき)を飲(の)むほど美(うつく)しくて

ki tto sore wa mada  
きっとそれはまだ  
na ma e no na i a o da tta  
名前(なまえ)の無(な)い青(あお)だった