---
title: 【歌词翻译】アルターエゴ／まふまふ
tags:
  - アルターエゴ
  - まふまふ
  - 歌词翻译
  - 中文歌词
id: '3105'
date: 2020-07-04 22:24:11
category: 歌词翻译
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/07/maxresdefault1124.jpg
---

[https://m.weibo.cn/detail/4523055269237109](https://m.weibo.cn/detail/4523055269237109)