---
title: 「アンヘル（天使）」歌ってみた /まふまふ 【罗马音+假名歌词】
tags:
  - かいりきベア
  - まふまふ
  - 假名歌词
  - アンヘル
  - 罗马音
id: '745'
date: 2019-11-08 20:09:59
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/QQ截图20191108170949.png
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/QQ截图20191108170949.png
---

「アンヘル」

作詞：かいりきベア  
作曲：かいりきベア  
編曲：かいりきベア  
唄/Mix：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

doku doku ma ji wa tte  
ドクドク交(まじ)わって　  
ta chi ma chi kon ni chi wa  
たちまちコンニチハ　  
a hahahaha ta ta ta tan jyou bi  
あはははは　たたた誕生日(たんじょうび)  
zoku zoku wa zu ra tte  
続々(ぞくぞく)患(わずら)って　  
me no fuchi nu re temo  
目(め)の縁(ふち) 濡(ぬ)れても  
shi a wa se desu i ki te i ru nara hora！  
幸(しあわ)せです 生(い)きているなら ほら！  
ke se ra ke se ra ke se ra  
ケセラ　ケセラ　ケセラ　

a-  
あー

dare ni mo ta non da  
誰(だれ)にも頼(たの)んだ  
o bo e wa naku to mo  
覚(おぼ)えはなくとも　  
a hahahaha un de mo ra e te  
あはははは　産(う)んでもらえて  
jiku jiku a za ni na tte  
ジクジク痣(あざ)になって  
e gu re chi mo re temo  
抉(えぐ)れ 血漏(ちも)れても  
shi a wa se desu i ki te i ru kara hora！  
幸(しあわ)せです 生(い)きているから ほら！  
ke se ra ke se ra ke se ra  
ケセラ　ケセラ　ケセラ　  
ra ra rarara…  
ラララララ…

a ka ku sa i ta  
紅(あか)く咲(さ)いた  
ku doku no ya i ba  
功徳(くどく)の刃(やいば)　  
son zai no i gi wo  
存在(そんざい)の意義(いぎ)を　  
ka za se ka za se  
翳(かざ)せ　翳(かざ)せ  
jyuu boku no ka ru ma  
従僕(じゅうぼく)の業(カルマ)　  
shuu goku no ha te ni  
囚獄(しゅうごく)の果(は)てに　  
ku da ra nu i no chi  
くだらぬ命(いのち)　  
tsu mu ge tsu mu ge yo  
紡(つむ)げ　紡(つむ)げよ

a a  
嗚呼(ああ)  
ke kkai shi ni karu tte  
決壊(けっかい) シニカルって  
i chi ni san  
１(いち)　２(に)　３(さん)  
tsu ra i de sho？hi sshi ni na tte  
辛(つら)いでしょ？必死(ひっし)になって  
sei sei sei sei  
生(せい) 生(せい) 生(せい) 生(せい)  
se kkai kokoro nu tte  
切開(せっかい)　ココロ縫(ぬ)って　  
ni ni san  
２(に)　２(に)　３(さん)  
ga ra kuta na mi ra i  
ガラクタな未来(みらい)  
te ra se te ra se  
照(て)らせ 照(て)らせ

moku soku a ya ma tte  
目測誤(もくそくあやま)って　  
ta chi ma chi kon ni chi wa  
たちまちコンニチハ　  
a hahahaha un de ko ra e te  
あはははは　膿(う)んで堪(こら)えて  
naku naku ta me ra tte  
泣(な)く泣(な)く躊躇(ためら)って  
「i ki ru」wo e ra be ba  
「生(い)きる」を選(えら)べば　  
shi a wa se desu  
幸(しあわ)せです　  
koko wa raku en hora！  
この世（ここ）は楽園(らくえん)　ほら！  
ke se ra ke se ra ke se ra  
ケセラ　ケセラ　ケセラ　  
ra ra rarara…  
ラララララ

a ka ku sa i ta  
紅(あか)く裂(さ)いた　  
hai toku no ka i ga  
背徳(はいとく)の絵画(かいが)  
son zai no gi ri wo  
存在(そんざい)の義理(ぎり)を　  
ha ta se ha ta se  
果(は)たせ　果(は)たせ  
jyuu boku no ka ru ma  
従僕(じゅうぼく)の業(カルマ)　  
bou toku no su e ni  
冒涜(ぼうとく)の末(すえ)に　  
wa zu ka na hi ka ri  
僅(わず)かな希望(ひかり)  
mo to me mo to me  
求(もと)め　求(もと)め

a a  
嗚呼(ああ)  
ke kkai shi ni karu tte  
決壊(けっかい)　シニカルって　  
i chi ni san  
１(いち)　２(に)　３(さん)  
tsu ra i re sshou  
辛(つら)い裂傷(れっしょう)　  
ya kki ni na tte  
躍起(やっき)になって  
sei sei sei sei  
生(せい) 生(せい) 生(せい) 生(せい)  
shi ttai doro kabu tte  
失態(しったい)　泥被(どろかぶ)って　  
ni ni san  
２(に)　２(に)　３(さん)  
kara ppo na mi ra i  
空(から)っぽな未来(みらい)　  
sa ra se sa ra se  
晒(さら)せ　晒(さら)せ

a a  
嗚呼(ああ)  
ke kkai ma-aka na kizu  
決壊(けっかい)　真(ま)っ赤(あか)な傷(きず)  
i chi ni san  
１(いち)　２(に)　３(さん)  
fu mare ta tte ke rare ta tte  
踏(ふ)まれたって 蹴(け)られたって  
sei sei sei sei  
生(せい) 生(せい) 生(せい) 生(せい)  
ji ssai kokoro chi tte  
実際(じっさい)　ココロ散(ち)って　  
ni ni san  
２(に)　２(に)　３(さん)  
ga ra kuta na ji bun  
ガラクタな自分(じぶん)　  
ka ku se ka ku se  
隠(かく)せ　隠(かく)せ

kono hi ni ban zai san shou  
此(こ)の灯(ひ)に万歳三唱(ばんざいさんしょう)　  
ko doku ni son zai i sshou  
孤独(こどく)に存在一生(そんざいいっしょう)  
sono ku ni i ron tei shou  
その苦(く)に異論提唱(いろんていしょう)　  
go taku wa ron gai sa sshou  
御託(ごたく)は論外殺傷(ろんがいさっしょう)  
kono mi ni ma tou byou jyou  
此(こ)の身(み)に纏(まと)う病状(びょうじょう)　  
na raku ni ma dou hyou jyou  
奈落(ならく)に惑(まど)う表情(ひょうじょう)  
kaji kamu re kka na jyou kyou  
悴(かじか)む劣化(れっか)な状況(じょうきょう)  
todo ka nu kyou mei son shou  
届(とど)かぬ救命損傷(きょうめいそんしょう)

sono mi de gen bu tsu ban shou  
その身(み)で見物万象(けんぶつばんしょう)　  
hi ni ku no kon zai ri sshou  
皮肉(ひにく)の混在立証(こんざいりっしょう)  
gi sen no ou kou gen shou  
偽善(ぎぜん)の横行現象(おうこうげんしょう)　  
horo bi no sei zon kyou sou  
滅(ほろ)びの生存競争(せいぞんきょうそう)  
taka daka jin sei hya ku nen  
たかだか人生百年(じんせいひゃくねん)  
dare mo ga ta do ru shuu en  
誰(だれ)もが辿(たど)る終焉(しゅうえん)  
sono ku se i ki ru shuu nen  
そのくせ生(い)きる執念(しゅうねん)  
a ku na ki mu jun ni bou zen  
飽(あ)くなき矛盾(むじゅん)に呆然(ぼうぜん)

ke kkan shi ta i ha tte  
欠陥(けっかん)　肢体(したい)這(は)って　  
i chi ni san  
１(いち)　２(に)　３(さん)  
tsu ra i san jyou de gu chi sura  
辛(つら)い惨状(さんじょう) 出口(でぐち)すら  
nai nai nai na  
無(な)い無(な)い無(な)いな  
ke ttai a kka na shin zou  
結滞(けったい) 悪化(あっか)な心臓(しんぞう)  
ni ni san  
２(に)　２(に)　３(さん)  
i ta i de sho？ hora hora…  
痛(いた)いでしょ？　ほらほら…

a a  
嗚呼(ああ)  
ke kkai shi ni karu tte  
決壊(けっかい)　シニカルって　  
i chi ni san  
１(いち)　２(に)　３(さん)  
tsu ra i de sho？hi sshi ni na tte  
辛(つら)いでしょ？必死(ひっし)になって  
sei sei sei sei  
生(せい) 生(せい) 生(せい) 生(せい)  
se kka i kokoro nu tte  
切開(せっかい)　ココロ縫(ぬ)って　  
ni ni san  
２(に)　２(に)　３(さん)  
ga ra kuta na mi ra i  
ガラクタな未来(みらい)　  
te ra se te ra se  
照(て)らせ 照(て)らせ

a a  
嗚呼(ああ)  
de kkai ma-aka na ba tten  
でっかい真(ま)っ赤(あか)な×点(ばってん)　  
i chi ni san  
１(いち)　２(に)　３(さん)  
fu mare ta tte ke gare ta tte  
踏(ふ)まれたって 穢(けが)れたって  
sei sei sei sei  
生(せい) 生(せい) 生(せい) 生(せい)  
ji ssai kokoro chi tte  
実際(じっさい)　ココロ散(ち)って　  
ni ni san  
２(に)　２(に)　３(さん）  
ga ra kuta na mi ra i  
ガラクタな未来(みらい)  
te ra se te ra se  
照(て)らせ 照(て)らせ　  
sa ra se sa ra se  
晒(さら)せ　晒(さら)せ　  
ko wa se ko wa se  
壊(こわ)せ　壊(こわ)せ