---
title: 「デジャヴ(Dejavu/既视感)」／まふまふ【罗马音+假名歌词】
tags:
  - デジャヴ
  - 罗马音
  - まふまふ
  - 假名歌词
id: '844'
date: 2019-11-23 02:00:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/0f74c7c0d1df57db27a5f0067f5ff9cb84df9421.jpg@518w_1e_1c-2048x1152.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/0f74c7c0d1df57db27a5f0067f5ff9cb84df9421.jpg@518w_1e_1c-2048x1152.jpg
---

「デジャヴ(Dejavu)」

作詞作編曲：まふまふ  
絵：寺田てら  
映像：まふてる  
唄：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

hai ki ga su  
排気(はいき)ガス  
sore to kai ri na ku  
それと乖離(かいり)無(な)く  
chuu ni u i te  
宙(ちゅう)に浮(う)いて  
sa ma yo tte ai ni ma ku  
彷徨(さまよ)って 愛(あい)に巻(ま)く  
yo tei chou wa de ko tei sou ba sei  
予定調和(よていちょうわ)で固定相場制(こていそうばせい)  
tsu gai yo so o i ki do tta kyou made  
番装(つがいよそお)い気取(きど)った今日(きょう)まで

so rya ai jya nai to i u  
そりゃ愛(あい)じゃないという  
mata ai wa nai to i u  
また愛(あい)はないという  
ta ri nai ne ga i i ga i  
足(た)りない願(ねが)い以外(いがい)  
sou ya tte wan to nai te o shi mai  
そうやってワンと鳴(な)いて御仕舞(おしまい)

kowa shi te na o shi kowa shi te  
壊(こわ)して直(なお)し 壊(こわ)して  
so shi te te moto ni a ma tta  
そして手元(てもと)に余(あま)った  
a i no pa-tsu  
哀(あい)のパーツ  
sore wa kou ka na kokoro no a na  
それは高価(こうか)な 心(こころ)の穴(あな)  
ki tto ni do to wa mo do se na sou dana  
きっと二度(にど)とは 戻(もど)せなそうだな  
「kimi wa fu tsuu jya nai」  
「君(きみ)は普通(ふつう)じゃない」  
boku wa fu tsuu jya nai  
ボクは普通(ふつう)じゃない  
zu re tei ta no wa  
ズレていたのは  
i tsu kara da tta kke na  
いつからだったっけな

mado wa ku ha me komu kyuu kyou ka  
窓枠(まどわく)はめ込(こ)む九教科(きゅうきょうか)  
u so tsu i te made  
嘘(うそ)ついてまで  
wara wa se ta i cho-ku  
笑(わら)わせたいチョーク  
kon na kuu so na se ka i nara  
こんな空疎(くうそ)な世界(せかい)なら  
kuru tte shi ma tte i ra re sou da  
狂(くる)ってしまっていられそうだ

nee  
ねえ  
nan de nan de suki ka tte  
なんで なんで 好(す)き勝手(かって)  
haya ri ya mai mi taku ai shi te  
流行(はや)り病(やまい)みたく 愛(あい)して  
ki tai kan mi man  
期待感(きたいかん)未満(みまん)  
ai gan no-ka un to  
哀願(あいがん)ノーカウント  
kaku tei ka  
確定化(かくていか)  
shuu jin no ji ren ma  
囚人(しゅうじん)のジレンマ

mi tsu bai no shin zou  
密売(みつばい)の心臓(しんぞう)  
kou i gan bou  
行為(こうい) 願望(がんぼう)  
to ri ma i ta shin ki rou  
取(と)り巻(ま)いた 蜃気楼(しんきろう)  
i ya o u nai  
否応(いやおう)ない  
kou kai dou dai  
後悔(こうかい) どうだい  
nou nai dou dai  
脳内(のうない) どうだい  
wa ka ra na i n dayo  
わからないんだよ  
nan de nan de yo  
なんで なんでよ

hou tei nai no na i fu mo tta  
法定内(ほうていない)の ナイフ持(も)った  
ba chi gai no kan kaku wa shu jin kou  
場違(ばちが)いの感覚(かんかく)は 主人公(しゅじんこう)  
fu ru e ru kimi wa kyo hi han nou  
震(ふる)える君(きみ)は 拒否反応(きょひはんのう)  
ha saki wa jyou mya ku ni tsu zu i te i ku  
刃先(はさき)は 静脈(じょうみゃく)に続(つづ)いていく  
kono hi to mi ga u zu i ta no wa  
この瞳(ひとみ)が疼(うず)いたのは  
ki shi kan da ra ke no sei  
既視感(きしかん)だらけの生(せい)

do ra ma ni a ri sou na  
ドラマにありそうな  
a i wa ta ku san a tta  
愛(あい)はたくさんあった  
ma ni a wa se ni chou do ii de su ne  
間(ま)に合(あ)わせにちょうどいいですね  
sayo nara no ka o wa  
さよならの顔(かお)は  
ma ru de in shou naku te  
まるで印象(いんしょう)なくて  
jyu shin deki zuni su na a ra shi ga fu i te  
受信(じゅしん)できずに 砂嵐(すなあらし)が吹(ふ)いて  
ko kkei  
滑稽(こっけい)

yuu ya ke ko ya ke de mata a shi ta  
夕焼(ゆうや)け小焼(こや)けでまた明日(あした)  
yaku soku shu ku dai wa su re ta mono ga chi  
約束(やくそく) 宿題(しゅくだい) 忘(わす)れた者(もの)勝(が)ち  
sou shi te kon ya mo se ka i kara  
そうして今夜(こんや)も世界(せかい)から  
ko bo re o chi te shi ma i sou da  
零(こぼ)れ落(お)ちてしまいそうだ

nee  
ねえ  
nan de nan de suki ka tte  
なんで なんで 好(す)き勝手(かって)  
ka ta mu i ta shou gai ni hi jyou tou  
傾(かたむ)いた生涯(しょうがい)に 非常灯(ひじょうとう)  
hi kou tou hi kou o i ru rai ta-  
非行(ひこう) 逃避行(とうひこう) オイルライター  
kou nai no baku dan bara mai te  
口内(こうない)の 爆弾(ばくだん)バラまいて  
hi mi tsu ri bai bai tou ka kou kan  
秘密裡売買(ひみつりばいばい) 等価交換(とうかこうかん)  
ya ji u ma no ba sei  
野次馬(やじうま)の罵声(ばせい)  
i ya o u nai  
否応(いやおう)ない  
kou kai dou dai  
後悔(こうかい) どうだい  
nou nai dou dai  
脳内(のうない) どうだい  
ko wa ga run de shou  
怖(こわ)がるんでしょう  
nan de nan de yo  
なんで なんでよ

hou tei nai no nai fu mo tte  
法定内(ほうていない)の ナイフ持(も)って  
shou rai wo kin tou ni sa bai ta  
将来(しょうらい)を均等(きんとう)に 捌(さば)いた  
ta kai sei fuku made  
高(たか)い制服(せいふく)まで  
ki ko na shi ta ya tsu kara  
着(き)こなした奴(やつ)から  
jun ban ni ta o re te i ku  
順番(じゅんばん)に 倒(たお)れていく  
kyou mo boku wo mu shi ba mu no wa  
今日(きょう)もボクを蝕(むしば)むのは  
ki shi kan da ra ke no sei  
既視感(きしかん)だらけの生(せい)

kyo mu ni jyou me a ta ra shi i mono wa  
虚無二乗(きょむにじょう) 目新(めあたら)しい物(もの)は  
nai ya i ya nai ya i ya  
ないやいや ないやいや  
kore i jyou ma a ta ra shi i mono wa  
これ以上(いじょう) 真新(まあたら)しい物(もの)は  
nai ya i ya nai ya i ya  
ないやいや ないやいや

sen bou ren jyou  
羨望(せんぼう) 恋情(れんじょう)  
mei mou saku sou  
迷妄(めいもう) 錯綜(さくそう)  
hon shou kei shou  
本性(ほんしょう) 警鐘(けいしょう)  
mi rai ei gou sou zou  
未来永劫(みらいえいごう) 創造(そうぞう)  
kou sou sou zou  
構想(こうそう) 想像(そうぞう)  
han chou ni su gi nai  
範疇(はんちゅう)にすぎない  
sai gi shin kyo e i shin  
猜疑心(さいぎしん) 虚栄心(きょえいしん)  
kou hai  
交配(こうはい)  
son zai no shou mei zu mi demo  
存在(そんざい)の証明済(しょうめいず)みでも  
dare kare ka ma wa zu  
誰彼構(だれかれかま)わず  
sen saku sou sa  
詮索(せんさく) 操作(そうさ)

doko wo sa ga se do  
どこを探(さが)せど  
a i wa ke tsu bou  
愛(あい)は欠乏(けつぼう)  
su ku i wa nai  
救(すく)いはない  
yu ga mu mi rai ni  
歪(ゆが)む未来(みらい)に  
o tete wo chou dai  
御手々(おてて)を頂戴(ちょうだい)  
mi ni a ma ru de jya vu ni sa i na ma re  
身(み)に余(あま)る デジャヴに苛(さいな)まれ  
kokoro wa doko ni su te you？  
心(こころ)はどこに捨(す)てよう？

nee  
ねえ  
nan de nan de suki ka tte  
なんで なんで 好(す)き勝手(かって)  
ha ya ri ya mai mi taku ai shi te  
流行(はや)り病(やまい)みたく 愛(あい)して  
ki tai kan mi man  
期待感未満(きたいかんみまん)  
a i gan no-ka un to  
哀願(あいがん)ノーカウント  
kaku tei ka  
確定化(かくていか)  
shuu jin no ji ren ma  
囚人(しゅうじん)のジレンマ

mi tsu bai no shin zou  
密売(みつばい)の心臓(しんぞう)  
kou i gan bou  
行為(こうい) 願望(がんぼう)  
to ri ma i ta shin ki rou  
取(と)り巻(ま)いた 蜃気楼(しんきろう)  
i ya o u nai  
否応(いやおう)ない  
kou kai dou dai  
後悔(こうかい) どうだい  
nou nai dou dai  
脳内(のうない) どうだい  
a i shi te i run de sho  
愛(あい)しているんでしょ  
nan de nan de yo  
なんで なんでよ

nan de nan de  
なんで なんで  
nan de nan de  
なんで なんで  
boku ra wa dou ya tte i ki ru no ？  
ボクらはどうやって生(い)きるの？  
sho sen sen kyu- me ri- ba ddo en do  
所詮(しょせん)センキューメリーバッドエンド  
u ma re rya oo kata wa di su to pi a  
生(う)まれりゃ 大方(おおかた)はディストピア  
kono hi to mi ga u zu i ta no wa  
この瞳(ひとみ)が疼(うず)いたのは  
ki shi kan da ra ke no sei  
既視感(きしかん)だらけの生(せい)