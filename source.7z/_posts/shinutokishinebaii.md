---
title: 「死ぬとき死ねばいい」ーカンザキイオリ/鏡音レン・リン【假名歌词+罗马音】
tags:
  - 死ぬとき死ねばいい
  - 罗马音
  - 鏡音レン
  - 鏡音リン
  - 假名歌词
  - カンザキイオリ
id: '2143'
date: 2020-02-02 21:57:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/cc1c129f1acb73f9945.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/cc1c129f1acb73f9945.jpg
---

「死ぬとき死ねばいい」

作曲 : カンザキイオリ  
作词 : カンザキイオリ  
歌：鏡音レン・リン

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

i tsu ka hito wa shi nu  
いつか人(ひと)は死(し)ぬ  
sore dake ga boku no  
それだけが僕(ぼく)の  
nou zui ni habi ko tte  
脳髄(のうずい)に蔓延(はびこ)って  
kabi ni na tte i masu ga  
カビになっていますが  
kono tabi to kkou yaku ga  
この度(たび)特効薬(とっこうやく)が  
e ra ba re ma shi ta  
選(えら)ばれました  
sei yoku to sho ku yoku to  
性欲(せいよく)と食欲(しょくよく)と  
sui min to kane  
睡眠(すいみん)と金(かね)

niku shi mi toka zen bu wa su re ma shi ta  
憎(にく)しみとか全部(ぜんぶ)忘(わす)れました  
kana shi mi toka zen bu su te ma shi ta  
悲(かな)しみとか全部(ぜんぶ)捨(す)てました  
o mo i dasu koto wa kasu kani a ri masu ga  
思(おも)い出(だ)すことは微(かす)かにありますが  
boku wa mou o to na ni na ri ma shi ta  
僕(ぼく)はもう大人(おとな)になりました

i ki ru i mi wa sore na ri ni a ru shi  
生(い)きる意味(いみ)はそれなりにあるし  
shin de shi ma u toki ni shi ne ba ii ha na shi daro  
死(し)んでしまうときに死(し)ねばいい話(はなし)だろ

hi sshi ni ha ta ra i te  
必死(ひっし)に働(はたら)いて  
kane wo ka se i de  
金(かね)を稼(かせ)いで  
kako wa yu ru sa re ta no ni  
過去(かこ)は許(ゆる)されたのに  
jin sei ha tten to jyou no bo kura wa  
人生発展途上(じんせいはってんとじょう)の僕(ぼく)らは  
jyou shi ki no me ba e ni  
常識(じょうしき)の芽生(めば)えに  
to ma do tte ba ka ri  
戸惑(とまど)ってばかり

tsu yu wa a ke te  
梅雨(つゆ)は明(あ)けて  
hi bi wa ka wa ki  
日々(ひび)は乾(かわ)き  
sono su be te ni kimi ga i ru  
その全(すべ)てに君(きみ)がいる  
hoo zu ki wa ha ze te  
鬼灯(ほおずき)は爆(は)ぜて  
ke mono ta chi wa tabi wo suru  
獣(けもの)たちは旅(たび)をする

sho ka  
初夏(しょか)  
mi kan no kumo no i ga kara maru  
未完(みかん)の蜘蛛(くも)の囲(い)が絡(から)まる  
te de n de ta kusa no ni o i wo o mo i dasu  
手(て)で撫(な)でた草(くさ)の匂(にお)いを思(おも)い出(だ)す  
ban ka  
晩夏(ばんか)  
shi ni gi wa wo o mo i dasu  
死(し)に際(ぎわ)を思(おも)い出(だ)す  
ki mi no hada ni ku sha mi wo shi ta  
君(きみ)の肌(はだ)にくしゃみをした

shi go to o wa ri wa bi-ru wo non de  
仕事(しごと)終(お)わりはビールを飲(の)んで  
dai dan en no e i ga te yoru ni so ma ru  
大団円(だいだんえん)の映画(えいが)で夜(よる)に染(そ)まる  
tomo da chi to soko soko naka yoku yare teru  
友達(ともだち)とそこそこ仲良(なかよ)くやれてる  
hi kara biru hibi no u ra de na ri hibi ku  
干(ひ)からびる日々(ひび)の裏(うら)で  
鳴(な)り響(ひび)く

naa dou ka u ra ma nai de kure  
なあ どうか恨(うら)まないでくれ  
a no ni o i ga i tsu made mo hana wo kusu gu ru  
あの匂(にお)いがいつまでも鼻(はな)をくすぐる  
boku wa i ma wo i ki run da  
僕(ぼく)は今(いま)を生(い)きるんだ  
kimi wa mou shin de i run da  
君(きみ)はもう 死(し)んでいるんだ

i ki ta a ka shi ga shin ki rou ni o do tte  
生(い)きた証(あかし)が蜃気楼(しんきろう)に踊(おど)って  
i mi ga su gi sa ru hi bi ga  
意味(いみ)が過(す)ぎ去(さ)る日々(ひび)が  
jin sei man ryou mi sui no boku ra ni wa  
人生満了未遂(じんせいまんりょうみすい)の僕(ぼく)らには  
tou te i ki ji go ku ni shi ka o mo e na i  
到底(とうて)生(い)き地獄(じごく)にしか思(おも)えない  
sei gi tte nan da ?  
正義(せいぎ)ってなんだ？  
dou toku tte nan da?  
道徳(どうとく)ってなんだ？  
hibi ga na ga re i ma de wa  
日々(ひび)が流(なが)れ今(いま)では  
mi chi bi ku gawa da to  
導(みちび)く側(がわ)だと ke mono ta chi wa ki zu ka na i 獣(けもの)たちは気(き)づかない

sayo nara i ma wa a ko ga re ga a ru  
さよなら 今(いま)は憧(あこが)れがある  
nin gen ra shi saga karada jyuu ni shi mi tsu i ta  
人間(にんげん)らしさが体中(からだじゅう)に染(し)み付(つ)いた  
shi ka shi kimi no koto ba wa wa su re nai  
しかし君(きみ)の言葉(ことば)は忘(わ)れない

「shi a wa se no yon moji nan te na ka tta  
「シアワセの4文字(よんもじ)なんてなかった  
i ma to na ccha dou demo ii sa」  
今(いま)となっちゃどうでもいいさ」

a i ga nan da yume ga nan da  
愛(あい)がなんだ 夢(ゆめ)がなんだ  
sore ga kane ni na ru no ka ？  
それが金(かね)になるのか？  
jin sei ha ten to jyou no bo kura wa  
人生発展途上(じんせいはってんとじょう)の僕(ぼく)らは  
tada shi sato sei chou wo ten bin ni ka ke ru  
正(ただ)しさと成長(せいちょう)を天秤(てんびん)にかける

nan do wa su re te  
何度忘(なんどわす)れて  
nan do na ge ke do  
何度嘆(なんどなげ)けど  
kako wa rin ne su ru kara  
過去(かこ)は輪廻(りんね)するから  
shi nu toki shi ne ba ii  
死(し)ぬとき死(し)ねばいい  
daga shi ka shi i ma wa i ki ta i  
だがしかし 今(いま)は生(い)きたい

nin gen ra shi ku  
人間(にんげん)らしく  
nin gen ra shi ku  
人間(にんげん)らしく  
sou o mo wa nai to ma e ni susu me nai  
そう思(おも)わないと前(まえ)に進(すす)めない