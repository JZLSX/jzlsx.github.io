---
title: 「女の子になりたい」/まふまふ 【罗马音+假名歌词】一「神楽色アーティファクト」
tags:
  - 女の子になりたい
  - 罗马音
  - まふまふ
  - 假名歌词
  - 神楽色アーティファクト
id: '734'
date: 2019-10-16 20:00:35
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/a311e8d2ab4f533e20e4ec620807fad0a3e9ceed.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/a311e8d2ab4f533e20e4ec620807fad0a3e9ceed.jpg
---

「女の子になりたい」想变成女孩子

一「神楽色アーティファクト」アルバム収録曲  
編曲：田中秀和  
作曲：まふまふ・田中秀和(MONACA)  
作詞︰まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

nee on na no ko ni na ri tai  
ねえ　女(おんな)の子(こ)になりたい  
o ne ga i ii de su ka  
お願(ねが)いいいですか？

cho ko re- to no mori wo ku gu ru  
チョコレートの森(もり)をくぐる  
o ren ji ka bo cha no ba sha ni  
オレンジかぼちゃの馬車(ばしゃ)に  
no se ra re te tsu re ra re te  
乗(の)せられて　連(つ)れられて  
mi ru ku i ro no o shi ro  
ミルク色(いろ)のお城(しろ)

min na ki tto a ko ga re tei ru  
みんなきっと憧(あこが)れている  
dou wa no naka no hi ro in  
童話(どうわ)の中(なか)のヒロイン  
i tsu ka mi ta yume ni mi ta  
いつか見(み)た　夢(ゆめ)に見(み)た  
ga ra su no ha i hi-ru  
ガラスのハイヒール

na i sho no ki mo chi  
ナイショの気持(きも)ち　  
hon to no ki mo chi  
ホントの気持(きも)ち  
cho tto ha na shi cha o u  
ちょっと話(はな)しちゃおう

wan tsu- suri- ma hou wo kake te  
ワンツースリー　魔法(まほう)をかけて  
a ta ra shii boku ni nari ta i no desu  
新(あたら)しいボクになりたいのです　  
o ne ga i  
お願(ねが)い！

ya ppa ri boku mo ka wa i ku na ri ta i na  
やっぱりボクも可愛(かわい)くなりたいな  
a no ko mi ta ku ka wa i ku na ri ta i na  
あの子(こ)みたく可愛(かわい)くなりたいな  
fu ri ru do re su wo me shi ma se  
フリルドレスを召(め)しませ  
se ka i de hi to ri no shin de re ra  
世界(せかい)でひとりのシンデレラ

chi ccha na yuu ki to o kki na ha ji me te  
ちっちゃなユウキとおっきなハジメテ  
ki tto ko wa ku na tte fu ru e cha u ke do  
きっと怖(こわ)くなって震(ふる)えちゃうけど  
on na no ko ni na ri tai  
女(おんな)の子(こ)になりたい！  
o ne ga i ii de su ka  
お願(ねが)いいいですか？  
ka wa i ku na tte ii de su ka  
可愛(かわい)くなっていいですか？

o to na ni na re do sa ga ra na i  
大人(おとな)になれど下(さ)がらない  
o ka shi na ko e no to-n to  
可笑(おか)しな声(こえ)のトーンと  
nani shi temo nani shi temo  
何(なに)しても　何(なに)しても  
u ma ku i ka nai kyou da  
うまくいかない今日(きょう)だ

na ra ba ！  
ならば！  
tsu ka no ma demo yume no naka ni  
束(つか)の間(ま)でも夢(ゆめ)の中(なか)に  
boku wo mi tsu ke te mi you kana  
ボクを見(み)つけてみようかな  
su ko shi dake su ko shi dake  
少(すこ)しだけ　少(すこ)しだけ  
ka wa re ru ki ga suru  
変(か)われる気(き)がする

doki doki shi te doki doki shi te  
ドキドキして　ドキドキして  
ne mu re na i yoru  
眠(ねむ)れない夜(よる)

wan tsu- suri- yuu ki wo da se ba  
ワンツースリー　勇気(ゆうき)を出(だ)せば  
dou wa ni tsu zu ku i ri gu chi wa mou soko dayo  
童話(どうわ)に続(つづ)く入口(いりぐち)はもうそこだよ

u wa me zu ka i de tai you ga nobo tte  
上目遣(うわめづか)いで太陽(たいよう)が昇(のぼ)って  
win ku no hi to tsu de ken ka ga o sa ma ru  
ウィンクのひとつで喧嘩(けんか)が収(おさ)まる  
chii sa na ri bon mu su n dara  
小(ちい)さなリボン結(むす)んだら  
se ka i mo hi to tsu ni shin de re ra  
世界(せかい)もひとつに　シンデレラ

hana mo te re te hazu ka shi ga ru you na  
花(はな)も照(て)れて恥(は)ずかしがるような  
mou suko shi kimi wo hitori ji me de ki ru you na  
もう少(すこ)し君(きみ)をひとり占(じ)めできるような  
on na no ko ni nari tai  
女(おんな)の子(こ)になりたい！  
to na ri ni ii de su ka  
隣(となり)にいいですか？

a ta ri ma e no mono do re mo ga  
当(あ)たり前(まえ)のものどれもが  
chi ga tte mi e tan da  
違(ちが)って見(み)えたんだ

wan tsu- suri- ma hou wo ka ke te  
ワンツースリー　魔法(まほう)をかけて  
a ta ra shii boku ni na ri ta i no desu  
新(あたら)しいボクになりたいのです　  
o ne ga i  
お願(ねが)い！

ya ppa ri boku mo ka wa i ku na ri ta i na  
やっぱりボクも可愛(かわい)くなりたいな  
a no ko mi ta ku ka wa i ku na ri ta i na  
あの子(こ)みたく可愛(かわい)くなりたいな  
chii sa ku ku bi wo ka shi ge tara  
小(ちい)さく首(くび)を傾(かし)げたら  
boku mo i ma dake wa shin de re ra  
ボクも今(いま)だけはシンデレラ

dai ji na kyou wo su mi kko ni ka ku re te  
大事(だいじ)な今日(きょう)を隅(すみ)っこに隠(かく)れて  
ji bun no koto mo wa kan naku naru ma e ni  
自分(じぶん)のこともわかんなくなる前(まえ)に  
on na no ko ni na ri tai  
女(おんな)の子(こ)になりたい！  
o ne ga i ii de su ka  
お願(ねが)いいいですか？

ka wa i ku na tte ii de su ka ？  
可愛(かわい)くなっていいですか？

nai sho da yo  
ナイショだよ～