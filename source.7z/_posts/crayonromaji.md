---
title: 「夜空のクレヨン(Crayons in the night sky)」/まふまふ【罗马音+假名歌词】
tags:
  - 夜空のクレヨン
  - 罗马音
  - まふまふ
  - 假名歌词
id: '3122'
date: 2020-07-08 01:32:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/07/maxresdefault-8.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/07/maxresdefault-8.jpg
---

「夜空のクレヨン」

作詞作編曲：まふまふ  
絵：たま  
映像：MONO-Devoid  
Piano：宇都圭輝  
Vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译：[https://m.weibo.cn/status/Ja7St0TqS](https://m.weibo.cn/status/Ja7St0TqS)

se kai jyuu no ku re yon wo  
世界中(せかいじゅう)のクレヨンを  
fu ri ma i ta yoru no u e  
振(ふ)りまいた夜(よる)の上(うえ)  
kimi ni ki ko e nu you ni  
君(きみ)に聞(き)こえぬように  
yo zora e tsu bu ya i ta  
夜空(よぞら)へつぶやいた

nee go tai sou na su to-ri- ya  
ねえ 御大層(ごたいそう)なストーリーや  
hoko reru you na mi rai jya naku ta tte  
誇(ほこ)れるような未来(みらい)じゃなくたって  
kimi to no a su wo  
君(きみ)との明日(あす)を  
sa ga shi tei ta  
探(さが)していた  
ho shi zo ra  
星空(ほしぞら)

sei ten no zora mo ne shi zu maru you na  
晴天(せいてん)の空(ぞら)も寝静(ねしず)まるような  
sei jya ku to kyou wa ta na ba ta no yoru  
静寂(せいじゃく)と今日(きょう)は 七夕(たなばた)の夜(よる)  
ho te ru hoho wo ki zu kare nu you ni  
火照(ほて)る頬(ほほ)を気(き)づかれぬように  
kimi no ma e wo a ru i te i ru  
君(きみ)の前(まえ)を歩(ある)いている

na tsu kaze tsu ki kage  
夏風(なつかぜ) 月影(つきかげ)  
na re na i ge ta no ne  
慣(な)れない下駄(げた)の音(ね)  
yo zora ni hi bi ku  
夜空(よぞら)に響(ひび)く

sei kai jyuu no ku re yon wo  
世界中(せかいじゅう)のクレヨンを  
fu ri ma i ta yoru no u e  
振(ふ)りまいた夜(よる)の上(うえ)  
son na ko i ni ki zu ku no wa  
そんな恋(こい)に気(き)づくのは  
su ko shi saki da tta  
少(すこ)し先(さき)だった

nee go tai sou na su to-ri ya  
ねえ 御大層(ごたいそう)なストーリーや  
hoko reru you na mi rai jya naku ta tte  
誇(ほこ)れるような未来(みらい)じゃなくたって  
kimi to no a su wo  
君(きみ)との明日(あす)を  
sa ga shi tei ta  
探(さが)していた  
ho shi zora  
星空(ほしぞら)

me gu ri a i wa i tsu ka no ki se ki  
巡(めぐ)り合(あ)いは いつかの奇跡(きせき)  
ma chi a wa se wa boku ra no ki se ki  
待(ま)ち合(あ)わせは ボクらの軌跡(きせき)  
do no mi rai mo wa ka tte ru koto wa  
どの未来(みらい)もわかってることは  
dono mi ra i mo bo ku ra no ma e ni aru tte koto  
どの未来(みらい)もボクらの前(まえ)にあるってこと

na ga kami ka ki wake  
長髪(ながかみ) かき分(わ)け  
fi ri mu ku shi gu sa ni  
振(ふ)り向(む)く仕草(しぐさ)に  
mune wa taka na tta  
胸(むね)は高鳴(たかな)った

se i ga ni ne sobe tte kata ra tte  
星河(せいが)に寝(ね)そべって 語(かた)らって  
wara i sou na kimi no yume  
笑(わら)いそうな君(きみ)の夢(ゆめ)  
toki no hako bume no naka  
時(とき)の箱舟(はこぶね)の中(なか)  
ka na ta de tata zun da  
彼方(かなた)で佇(たたず)んだ

ko i shi tau kyou bi ko kai  
恋(こ)い慕(した)う 今日日(きょうび)後悔(こうかい)  
i ku do no ma tsu yo i don na kan jyou mo  
幾度(いくど)の待(ま)つ宵(よい) どんな感情(かんじょう)も  
kimi no to na ri de ki zu ke ta ra  
君(きみ)の隣(となり)で気(き)づけたら  
yo ka tta naa  
よかったなあ

ha ji me te kan ji ta  
初(はじ)めて感(かん)じた  
ki mo chi ni yuku a te wa nai yo  
気持(きも)ちに行(ゆ)く宛(あて)はないよ  
don na ri yuu de don na koto ba de  
どんな理由(りゆう)で どんな言葉(ことば)で  
do n na ka o shi te  
どんな顔(かお)して  
ki mi no te wo to re ba i in da rou  
君(きみ)の手(て)を取(と)ればいいんだろう

sei kai jyuu no ku re yon wo  
世界中(せかいじゅう)のクレヨンを  
fu ri ma i ta yoru no u e  
振(ふ)りまいた夜(よる)の上(うえ)  
kimi ni ki ko e nu you ni  
君(きみ)に聞(き)こえぬように  
yo zora e tsu bu ya i ta  
夜空(よぞら)へつぶやいた

nee go tai sou na su to-ri ya  
ねえ 御大層(ごたいそう)なストーリーや  
hoko reru you na mi rai jya naku ta tte  
誇(ほこ)れるような未来(みらい)じゃなくたって  
yume no tsu zu ki wo  
夢(ゆめ)の続(つづ)きを  
sa ga shi tei ta  
探(さが)していた  
sore wa sa i go no  
それは最後(さいご)の  
ki mi to mi ta ho shi zora  
君(きみ)と見(み)た星空(ほしぞら)

ten tai no sei sai wo  
天体(てんたい)の星祭(せいさい)を  
kimi to a ru i ta  
君(きみ)と歩(ある)いた  
man ten wo shou kei wo  
満天(まんてん)を憧憬(しょうけい)を  
mou kou kai wa hi to tsu da tte shi nai you ni  
もう後悔(こうかい)はひとつだってしないように

ho shi kuzu no furu yoru ni  
星屑(ほしくず)の降(ふ)る夜(よる)に  
ki mi ni tsu ta e ru ta me ni  
君(きみ)に伝(つた)えるために  
a i ni yu ku yo  
会(あ)いに行(ゆ)くよ  
ya ku so ku shi you  
約束(やくそく)しよう