---
title: 「I LOVE … 」/まふまふ (歌ってみた)(Cover：Official髭男dism)【罗马音+假名歌词】
tags:
  - I LOVE … 
  - 罗马音
  - まふまふ
  - 假名歌词
id: '3086'
date: 2020-06-08 02:04:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/06/20200605173742.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/06/20200605173742.jpg
---

「I LOVE … 」

作詞作編曲：藤原聡  
絵：胡麻乃りお  
映像：MONO-Devoid  
Arrange：三矢禅晃  
inst Mix：yasu  
歌/Mix：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

boku ga mi tsu meru ke shi ki no sono naka ni  
僕(ぼく)が見(み)つめる景色(けしき)のその中(なか)に　  
kimi ga ha i tte kara ka wa ri ha te ta se ka i wa  
君(きみ)が入(はい)ってから 変(か)わり果(は)てた世界(せかい)は  
i tsu mo so tsu naku ko na shi ta hibi no man naka  
いつも卒(そつ)なくこなした日々(ひび)の真(ま)ん中(なか)  
fu shi gi na in ryo ku ni sa ka ra e zu ku zu re te ku  
不思議(ふしぎ)な引力(いんりょく)に逆(さか)らえず崩(くず)れてく

i love nan te  
I Love なんて　  
i i kake te wa ya me te  
言(い)いかけてはやめて  
i love i love  
I Love I Love　  
nan do mo  
何度(なんど)も

ta ka ma ru ai no naka  
高(たか)まる愛(あい)の中(なか)  
ka wa ru shin jyou no naka  
変(か)わる心情(しんじょう)の中(なか)  
san zen to ka ga ya ku su ga ta wa  
燦然(さんぜん)と輝(かがや)く姿(すがた)は  
maru de sui sou no naka ni to bi kon de  
まるで水槽(すいそう)の中(なか)に飛(と)び込(こ)んで  
to ke ta e no gu mi ta i na  
溶(と)けた絵(え)の具(ぐ)みたいな　  
i re gyu ra-  
イレギュラー

hi to ri jya na ni hito tsu  
独(ひと)りじゃ何(なに)ひとつ  
ki tsu ke na ka tta da rou  
気付(きつ)けなかっただろう　  
kon na ni a za ya kana shi ki sa i ni  
こんなに鮮(あざ)やかな色彩(しきさい)に  
fu tsu u no koto dato  
普通(ふつう)の事(こと)だと　  
to bo keru kimi ni ii kake ta  
とぼける君(きみ)に言(い)いかけた  
i love sono tsu zu ki wo o ku ra se te  
I Love その続(つづ)きを贈(おく)らせて

mi e na i mono wo mi te wara u  
見(み)えない物(もの)を見(み)て笑(わら)う  
kimi no koto wo  
君(きみ)の事(こと)を　  
wa ka re na i bo ku ga i ru  
分(わ)かれない僕(ぼく)が居(い)る  
u tsu ku shi su gi te  
美(うつく)しすぎて  
me ga ku ran de shi ma u  
目(め)が眩(くら)んでしまう  
i ma mo re ttou kan ni shi ba rare te i ki te i ru  
今(いま)も劣等感(れっとうかん)に縛(しば)られて生(い)きている  
i love i love  
I Love I Love　  
bu ka kkou na mu su bi me  
不恰好(ぶかっこう)な結(むす)び目(め)  
i love i love  
I Love I Love　  
te sa gu ri de mi tsu ke te  
手探(てさぐ)りで見(み)つけて  
i love your love  
I Love Your Love　  
ho do i te kara ma tte  
解(ほど)いて 絡(から)まって  
boku wa ku ri ka e shi te ru  
僕(ぼく)は繰(く)り返(かえ)してる　  
nan do mo  
何度(なんど)も

re pu ri ka ba kari ga kaza rare ta gin ga  
レプリカばかりが飾(かざ)られた銀河(ぎんが)  
ka- ten de tsu ku rare ta ku ra ya mi  
カーテンで作(つく)られた暗闇(くらやみ)  
na ge ku hito mo i nai  
嘆(なげ)く人(ひと)も居(い)ない　  
ne zu mi i ro no ma chi no naka de  
鼠色(ねずみいろ)の街(まち)の中(なか)で  
i love sono a ka shi wo da ki shi me te  
I Love その証(あかし)を抱(だ)き締(し)めて

yo ro ko bi mo ka na shi mi mo  
喜(よろこ)びも悲(かな)しみも  
ku tou ten no na i o mo i mo  
句読点(くとうてん)のない想(おも)いも  
kan zen ni wa ka chi a u yo ri  
完全(かんぜん)に分(わ)かち合(あ)うより　  
ai mai ni na ya mi na ga ra mo  
曖昧(あいまい)に悩(なや)みながらも　  
mi to me a e ta nara  
認(みと)め合(あ)えたなら

ka sa naru ai no naka  
重(かさ)なる愛(あい)の中(なか)  
ni go tta kan jyou no naka  
濁(にご)った感情(かんじょう)の中(なか)  
ma ba ta ki no wa zu ka sono ai ma ni  
瞬(まばた)きの僅(わず)かその合間(あいま)に  
kimi ga kure ta pu re zen to wa kono  
君(きみ)がくれたプレゼントはこの　  
yake ni ya sa shii se ka i da  
やけに優(やさ)しい世界(せかい)だ  
i re gyu ra-  
イレギュラー

hi to ri jya na ni hi to tsu  
独(ひと)りじゃ何(なに)ひとつ  
ki tsu ke na ka tta da rou  
気付(きつ)けなかっただろう　  
kon na ni tai se tsu na hi ka ri ni  
こんなに大切(たいせつ)な光(ひかり)に  
fu tsu u no koto dato  
普通(ふつう)の事(こと)だと　  
to bo ke ru kimi ni ii ka ke ta  
とぼける君(きみ)に言(い)いかけた  
i love sono tsu zu ki wo o ku ra se te  
I Love その続(つづ)きを贈(おく)らせて

u ke to ri a u boku ra  
受(う)け取(と)り合(あ)う僕(ぼく)ら　  
na ma e mo na i yoru ga fu ke te i ku  
名前(なまえ)もない夜(よる)が更(ふ)けていく