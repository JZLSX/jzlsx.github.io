---
title: 「命のユースティティア」/まふまふ (歌ってみた)【假名歌词+罗马音】
tags:
  - 命のユースティティア
  - Neru
  - 罗马音
  - まふまふ
  - 假名歌词
id: '1314'
date: 2020-01-04 00:45:14
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/01/a960x540l.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/01/a960x540l.jpg
---

「命のユースティティア」

作詞：Neru  
作曲：Neru  
歌：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

Justice is still in my heart  
kimi ni to do ke yu-su ti ti a  
君(きみ)に届(とど)け ユースティティア

kura yami ga ta chi ko me ta you na  
暗闇(くらやみ)が立(た)ち込(こ)めた様(よう)な  
mi su te rare ta ma chi de  
見捨(みす)てられた街(まち)で  
hi to ri ko doku wo u ta u ki mi wo mi ta  
一人(ひとり) 孤独(こどく)を詠(うた)う君(きみ)を見(み)た  
yo mi ga e ru ki o ku ni ko dama shi te  
よみがえる過去(きおく)に木霊(こだま)して  
kimi no u de wo tsu ka mu  
君(きみ)の腕(うで)を掴(つか)む  
koko ga yaku soku no chi da to shin ji te  
ここが 約束(やくそく)の地(ち)だと信(しん)じて

ta shi ka na ko ta e wa do ko ni mo  
確(たし)かな答(こた)えは何処(どこ)にも  
na i ke re do  
無(な)いけれど  
ka go no na ka no ko tori wa me za me ta  
籠(かご)の中(なか)の小鳥(ことり)は目覚(めざ)めた  
ha ne sa e na i ma ma ko do u wa  
羽根(はね)さえ無(な)いまま鼓動(こどう)は  
ka so ku shi te  
加速(かそく)して  
boku ra kono hi wo  
僕(ぼく)らこの日(ひ)を  
kono to ki wo ma chi tsu zu ke te tan da  
この時(とき)を待(ま)ち続(つづ)けてたんだ

kana wa nu i no ri ni  
叶(かな)わぬ 祈(いの)りに  
suku i no ryou te wo  
救(すく)いの両手(りょうて)を  
u ma re ka wa re  
生(う)まれ変(か)われ  
i no chi no yu-su ti ti a  
命(いのち)のユースティティア  
don na kaze fu i te i ta tte  
どんな風吹(かぜふ)いていたって  
kono ko e wa ke se ya shi na i  
この声(こえ)は消(け)せやしない

a shi ta no boku ra ni  
未来(あした)の僕(ぼく)らに  
no ko se ru mono wa nani  
残(のこ)せる物(もの)は何(なに)?  
sora wo te ra se  
宙(そら)を照(て)らせ  
i chi ru no yu-su ti ti a  
一縷(いちる)のユースティティア  
i chi byou da tte kuru wa se nai  
一秒(いちびょう)だって 狂(くる)わせない  
u ba ware ta se ka i wo  
奪(うば)われた世界(せかい)を  
saa to ri mo do se  
さあ取(と)り戻(もど)せ

kasa na ri a tte  
重(かさ)なり合(あ)って  
i tsu no hi da tte  
いつの日(ひ)だって  
boku ra wa tomo ni i ru  
僕(ぼく)らは共(とも)にいる

sabi tsu i ta to bi ra ni te ka za shi te  
錆(さ)び付(つ)いた扉(とびら)に手翳(てかざ)して  
fu tata bi e ga ku i ma  
再(ふたた)び描(えが)く現在(いま)  
ki mi no  
君(きみ)の  
kimi dake no u ta ga ha ji ma ru  
君(きみ)だけの物語(うた)が始(はじ)まる  
na ku shi ta koto ba to koto ba no  
失(な)くした言葉(ことば)と言葉(ことば)の  
i mi wo tsu mu gi a wa se te  
意味(いみ)を紡(つむ)ぎ合(あ)わせて  
tsu yo ku dare yori chi ka ra tsu yo ku  
強(つよ)く 誰(だれ)より力強(ちからづよ)く  
saki ho ko ru sono ne wo dou ka  
咲(さ)き誇(ほこ)るその音(ね)をどうか  
ta ya sa na i de  
絶(た)やさないで

boku ga boku ra shi ku a ru koto  
僕(ぼく)が僕(ぼく)らしく在(あ)ること  
kimi ga kimi ra shi ku a ru koto  
君(きみ)が君(きみ)らしく在(あ)ること  
sore ga hate shi na i  
それが果(は)てしない  
boku ra no yu-su ti ti a  
僕(ぼく)らのユースティティア

kana wa nu i no ri ni  
叶(かな)わぬ祈(いの)りに  
suku i no ryou te wo  
救(すく)いの両手(りょうて)を  
u ma re ka wa re  
生(う)まれ変(か)われ  
i no chi no yu-su ti ti a  
命(いのち)のユースティティア  
don na kaze fu i te i ta tte  
どんな風吹(かぜふ)いていたって  
kono ko e wa ke se ya shi na i  
この声(こえ)は消(け)せやしない

a shi ta no boku ra ni  
未来(あした)の僕(ぼく)らに  
noko se ru mono wa nani  
残(のこ)せる物(もの)は何(なに)?  
sora wo te ra se  
宙(そら)を照(て)らせ  
i chi ru no yu-su ti ti a  
一縷(いちる)のユースティティア  
i chi byou da tte kuru wa se nai  
一秒(いちびょう)だって 狂(くる)わせない  
u ba wa re ta se ka i wo  
奪(うば)われた世界(せかい)を  
saa to ri mo do se  
さあ取(と)り戻(もど)せ

i tsu wa ri a tte dama sa re ta tte  
偽(いつわ)り合(あ)って 騙(だま)されたって  
sore demo so tto hi kari wa fu tte  
それでもそっと 光(ひかり)は降(ふ)って  
i tsu ka wa ki tto kana ra zu ki tto  
いつかはきっと 必(かなら)ずきっと  
boku ga kimi no kokoro to mo su kara  
僕(ぼく)が君(きみ)の心燈(こころとも)すから