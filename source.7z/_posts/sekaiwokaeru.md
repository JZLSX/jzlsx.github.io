---
title: 「世界を変えるひとつのノウハウ」/After the Rain【罗马音+平假名歌词】
tags:
  - 世界を変えるひとつのノウハウ
  - After the Rain
  - 罗马音
  - まふまふ
  - 假名歌词
  - そらる
id: '707'
date: 2019-08-10 19:29:32
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/f7265a7be509d1185cbb4201b8552f21158951ac.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/f7265a7be509d1185cbb4201b8552f21158951ac.jpg@1075w_602h.jpg
---

「世界を変えるひとつのノウハウ」

絵　　l　茶々ごま  
映像　l　MONO-Devoid  
作詞作編曲／まふまふ  
Mix&Mastering / まふまふ×そらる  
唄／After the Rain

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

weiku appu ga tomara nai  
ウェイクアップが止(と)まらない  
haku shu to kan sei wa nari yama nai  
拍手(はくしゅ)と歓声(かんせい)は鳴(な)り止(や)まない  
kagiri aru inochi no endo ro-ru  
限(かぎ)りある命(いのち)のエンドロール  
sekai kai kaku go ran aso ba se  
世界改革(せかいかいかく)ご覧(らん)あそばせ

(What's up ？)  
kokoro aka shin gou  
心(こころ)＝赤信号(あかしんごう)、  
totemo tan jun ni  
とても単純(たんじゅん)に  
ki ga mui tara ao ni naru  
気(き)が向(む)いたら青(あお)になる  
botan shi ki de o-rai  
ボタン式(しき)でオーライ

are are  
あれあれ?  
shiro kuro ku sun dei ru  
白黒(しろくろ)くすんでいる  
sora demo tai gai wa  
空(そら)でも大概(たいがい)は  
kumo ri megane ga  
曇(くも)りメガネが  
go ai kyou na ketsu ron  
ご愛嬌(あいきょう)な結論(けつろん)

ko-hi- iro wa ka ppu no naka dake  
コーヒー色(いろ)はカップの中(なか)だけ  
horo niga i no maho u wo kake ta  
ほろ苦(にが)いの魔法(まほう)をかけた  
kaku zatou wo hito tsu bu  
角砂糖(かくざとう)を一粒(ひとつぶ)  
sou dayo  
そうだよ  
ama ku te tamara nai de sho  
甘(あま)くてたまらないでしょ？

weiku appu ga tomara nai  
ウェイクアップが止(と)まらない  
haku shu to kan sei wa nari yama nai  
拍手(はくしゅ)と歓声(かんせい)は鳴(な)り止(や)まない  
kuraku shizumi kitta yozora ga  
暗(くら)く沈(しず)みきった夜空(よぞら)が  
kaketa hoshi mo kirei ni suru  
欠(か)けた星(ほし)も綺麗(きれい)にする

hai tacchi do re mi fa so  
ハイタッチドレミファソ  
dare moga chiga tte dekiru ka on  
誰(だれ)もが違(ちが)ってできる和音(かおん)  
boku no namida mo doko kano  
ボクの涙(なみだ)もどこかの  
oo zora ni ni ji wo kakeru no  
大空(おおぞら)に虹(にじ)をかけるの？

ta tta hito tsu de seka i wo kae te shi mau  
たったひとつで世界(せかい)を変(か)えてしまう  
suteki na nou hau wo o shi e ru yo  
素敵(すてき)なノウハウを教(おし)えるよ

deko boko pazuru no pi-su na boku ra  
凸凹(でこぼこ)パズルのピースなボクら  
kimi ga hitori kake tei tara  
君(きみ)がひとり欠(か)けていたら  
mi kan se i no mama  
未完成(みかんせい)のまま

sou 「yaku gara fu mei」de o wari wa  
そう『役柄不明(やくがらふめい)で終(お)わり』は  
en ryo shi you  
遠慮(えんりょ)しよう  
kan tan ni fina-re wa  
簡単(かんたん)にフィナーレは  
sagashi cha ike nai ze  
探(さが)しちゃいけないぜ

chii sa na kyu jin  
小(ちい)さな巨人(きょじん)  
se no taka i ko bito  
背(せ)の高(たか)い小人(こびと)  
are kore abe kobe ni na tte iru  
あれこれあべこべになっている？  
maru ba tsu ni san kaku  
○(まる)✕(ばつ)に△(さんかく)  
an ga i  
案外(あんがい)  
a te ha mara na i mon de sho  
当(あ)てはまらないもんでしょ？

an happi- wa mu ron  
アンハッピーは無論(むろん)  
mai nasu kakeru mai nasu de  
マイナス×(かける)マイナスで  
nureru tema made habu ke tara  
濡(ぬ)れる手間(てま)まで省(はぶ)けたら  
u ten chuushi mo chuushi chuu  
雨天(うてん)中止(ちゅうし)も中止中(ちゅうしちゅう)

happi-en do wo cho isu  
ハッピーエンドをチョイス  
kyou wari kimi no kimochi shi dai  
9割(きゅうわり)君(きみ)の気持(きも)ち次第(しだい)  
are wa shiro kana ao kana  
あれは白(しろ)かな？青(あお)かな？  
sore tomo hare ta sora kana  
それとも晴(は)れた空(そら)かな？

kokoro ni a i ta ana wa ume kko shi you  
ココロに開(あ)いた穴(あな)は埋(う)めっこしよう  
soshi tara sukoshi dake wara tte yo  
そしたら少(すこ)しだけ笑(わら)ってよ

re ttsu go- de migi muke  
レッツゴーで右向(みぎむ)け  
moshi kuwa hidari muke  
もしくは左向(ひだりむ)け  
maware maware maware  
まわれまわれまわれ

suki na hou wo mu i te  
好(す)きな方(ほう)を向(む)いて  
takaku te wo agete  
高(たか)く手(て)をあげて  
maware maware maware  
まわれまわれまわれ

sou ya tte sekai mo mawa tte i kun de sho  
そうやって世界(せかい)も回(まわ)っていくんでしょ？

weiku appu ga tomara nai  
ウェイクアップが止(と)まらない  
haku shu to kansei wa nari yama nai  
拍手(はくしゅ)と歓声(かんせい)は鳴(な)り止(や)まない  
kagiri aru inochi no endo ro-ru  
限(かぎ)りある命(いのち)のエンドロール  
imi no nai mono wa nai mon  
意味(いみ)のないものはないもん

hai tacchi do re mi fa so  
ハイタッチドレミファソ  
dare moga chiga tte dekiru ka on  
誰(だれ)もが違(ちが)ってできる和音(かおん)  
boku no namida mo doko kano  
ボクの涙(なみだ)もどこかの  
oo zora ni niji wo kakeru no  
大空(おおぞら)に虹(にじ)をかけるの？

ta tta hitotsu de sekai wo kae te shima u  
たったひとつで世界(せかい)を変(か)えてしまう  
suteki na nou hau de  
素敵(すてき)なノウハウで  
ashita mo shin tai ken  
明日(あした)も新体験(しんたいけん)  
soshi tara sukoshi dake wara tte yo  
そしたら少(すこ)しだけ笑(わら)ってよ