---
title: グランドエスケープ/ まふまふ (歌ってみた) -「天気の子」 OP【罗马音+平假名】
tags:
  - グランドエスケープ
  - 罗马音
  - まふまふ
  - 假名歌词
id: '705'
date: 2019-07-30 19:26:38
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/07/5993be09bc5387865df4123640940bd870287695.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/07/5993be09bc5387865df4123640940bd870287695.jpg@1075w_602h.jpg
---

グランドエスケープ

絵:ゆりぼう  
Movie:MONO-Devoid  
vocal/編曲:まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

sora tobu hane to hiki kae ni  
空(そら)飛(と)ぶ羽根(はね)と引(ひ)き換(か)えに  
tsu na gi au te wo e ran da boku ra  
繋(つな)ぎ合(あ)う手(て)を選(えら)んだ僕(ぼく)ら  
sore demo sora ni mise rarete  
それでも空(そら)に魅(み)せられて  
yume wo kasa neru no wa tsumi ka  
夢(ゆめ)を重(かさ)ねるのは罪(つみ)か？

natsu wa aki no senaka wo mite  
夏(なつ)は秋(あき)の背中(せなか)を見(み)て  
sono kao wo omo i uka beru  
その顔(かお)を思(おも)い浮(う)かべる  
ako gare nano ka  
憧(あこが)れなのか  
koi nano ka  
恋(こい)なのか  
kana wa nu to shi tte ina gara  
叶(かな)わぬと知(し)っていながら

jyuu ryo ku ga nemuri ni tsuku  
重力(じゅうりょく)が眠(ねむ)りにつく  
sen nen ni ichi do no kyou  
1000年(せんねん)に一度(いちど)の今日(きょう)  
taiyou no shikaku ni tachi  
太陽(たいよう)の死角(しかく)に立(た)ち  
boku ra kono hoshi wo de you  
僕(ぼく)らこの星(ほし)を出(で)よう

kare ga me wo sama shi ta toki  
彼(かれ)が目(め)を覚(さ)ました時(とき)  
tsure modo se nai basho e  
連(つ)れ戻(もど)せない場所(ばしょ)へ  
「se-no」de dai chi wo ke tte  
「せーの」で大地(だいち)を蹴(け)って  
kokode wa nai hoshi e  
ここではない星(ほし)へ

「i kou」  
「行(い)こう」

mou suko shi de un mei no mu kou  
もう少(すこ)しで運命(うんめい)の向(む)こう  
mou suko shi de bun mei no mu kou  
もう少(すこ)しで文明(ぶんめい)の向(む)こう  
「i kou」  
「行(い)こう」  
mou suko shi de un mei no mu kou  
もう少(すこ)しで運命(うんめい)の向(む)こう  
mou suko shi de  
もう少(すこ)しで

yume ni bokura de ho wo ha tte  
夢(ゆめ)に僕(ぼく)らで帆(ほ)を張(は)って  
kitaru beki hi no tame ni yoru wo koe  
来(きた)るべき日(ひ)のために夜(よる)を超(こ)え  
iza ki tai dake man tan de  
いざ期待(きたい)だけ満(まん)タンで  
ato wa dou ni kanaru sa to  
あとはどうにかなるさと  
kata wo kun da  
肩(かた)を組(く)んだ

kowa ku nai wake nai  
怖(こわ)くない わけない  
demo to man nai  
でも止(と)まんない  
pin chi no saki mawari shi ta tte  
ピンチの先回(さきまわ)りしたって  
boku ra jya shou ga nai  
僕(ぼく)らじゃしょうがない  
boku ra no koi ga iu  
僕(ぼく)らの恋(こい)が言(い)う  
koe ga iu  
声(こえ)が言(い)う

「i ke」to iu  
「行(い)け」と言(い)う