---
title: 「傀儡の心臓（傀儡的心脏）」/ まふまふ 【罗马音+假名歌词】一「神楽色アーティファクト」
tags:
  - 傀儡の心臓
  - 罗马音
  - まふまふ
  - 假名歌词
  - 神楽色アーティファクト
id: '738'
date: 2019-10-17 20:03:42
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026152443.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026152443.jpg
---

「傀儡の心臓」

一「神楽色アーティファクト」アルバム収録曲  
編曲：まふまふ  
作詞・作曲：まふまふ  
vocal︰まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

yu bi sa ki hi to tsu kara  
指先(ゆびさき)ひとつから　  
fu ka ku nu i tsu ke te wa  
深(ふか)く縫(ぬ)いつけては  
ta do re ba kokoro made  
辿(たど)れば心(こころ)まで　  
toke ko mu you na kumo no i to  
溶(と)け込(こ)むような蜘蛛(くも)の糸(いと)

so re wa koro sa nu you ni  
それは殺(ころ)さぬように　  
sa re do i ka sa nu you ni  
されど生(い)かさぬように  
ha ne wo tsu i ba n de wa  
翅(はね)を啄(ついば)んでは　  
sasa ya ku dou ke  
囁(ささや)く 道化(どうけ)　  
a ma i u so  
甘(あま)い嘘(うそ)

a na ta ni su ga ru  
貴方(あなた)に縋(すが)る  
mi ji me na yume ni  
惨(みじ)めな夢(ゆめ)に  
sono dore mo u ta ga wa shi i ho do  
そのどれも疑(うたが)わしいほど  
mi ryou sa re ru  
魅了(みりょう)される

kono mi wo shi ba ru kuru shi mi ga  
この身(み)を縛(しば)る苦(くる)しみが  
a i to kan ji te shi ma u no  
愛(あい)と感(かん)じてしまうの  
a na ta no yu bi saki ni  
貴方(あなた)の指先(ゆびさき)に  
u na zu i tei ru dake  
頷(うなず)いているだけ

doro to a ma tsu bu ni han sha shi ta  
泥(どろ)と雨粒(あまつぶ)に反射(はんしゃ)した  
mono yu wa nu u su yo go re ta nin gyou  
物言(ものゆ)わぬ薄汚(うすよご)れた人形(にんぎょう)  
a ya tsu ri i to no iu mama ni  
操(あやつ)り糸(いと)の言(い)うままに  
ka ge wo fu mu  
影(かげ)を踏(ふ)む

fu i ni te ba na sa re te  
不意(ふい)に手放(てばな)されて　  
ha ba ta ke ta to shi temo  
羽(は)ばたけたとしても  
do u se ka wa re ya shi nai  
どうせ変(か)われやしない　  
nozo mu mi rai wa kumo no i to  
望(のぞ)む未来(みらい)は蜘蛛(くも)の糸(いと)

ya ma na i a me ni  
止(や)まない雨(あめ)に　  
ya me ru kokoro ga  
病(や)める心(こころ)が  
te ma ne ku mama too za ka ru se wo  
手招(てまね)くまま遠(とお)ざかる背(せ)を  
sa ga shi te i ru  
探(さが)している  
a na ta wa do ko ？  
貴方(あなた)はどこ？

wa ta shi no yu bi saki ni  
私(わたし)の指先(ゆびさき)に　  
wa ta shi no a shi ta ga a tte mo  
私(わたし)の明日(あした)があっても  
sa wa ri kata wo shi ra nai  
触(さわ)り方(かた)を知(し)らない　  
yuku a te mo shi ra nai  
行(ゆ)く宛(あ)ても知(し)らない

kuru shi ku te dou shi you mo nai  
苦(くる)しくてどうしようもない  
a i ni o bo re te i ta i no  
愛(あい)に溺(おぼ)れていたいの  
a na ta no yu bi saki ni  
貴方(あなた)の指先(ゆびさき)に  
u na zu i tei ru dake  
頷(うなず)いているだけ

do ro to a ma tsu bu ni han sha shi ta  
泥(どろ)と雨粒(あまつぶ)に反射(はんしゃ)した  
mono yu wa nu u su yo go re ta nin gyou  
物言(ものゆ)わぬ薄汚(うすよご)れた人形(にんぎょう)  
a ya tsu ri i to no iu mama ni  
操(あやつ)り糸(いと)の言(い)うままに  
ka ge wo fu mu  
影(かげ)を踏(ふ)む

wa ta shi wo yoku mi te  
私(わたし)をよく見(み)て　  
wa ta shi dake wo mi te  
私(わたし)だけを見(み)て  
wa ta shi no mi mo kokoro mo  
私(わたし)の身(み)も心(こころ)も  
ta be te shi ma tte  
食(た)べてしまって