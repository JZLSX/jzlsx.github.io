---
title: 「パンダヒーロー」(Panda Hero 熊猫英雄)/ 【罗马音+平假名歌词+中文翻译整理】
tags:
  - パンダヒーロー
  - 罗马音
  - まふまふ
  - luz
  - nqrse
  - そらる
  - 假名歌词
  - ハチ
id: '701'
date: 2019-07-21 19:23:14
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/35425745.69201212.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/35425745.69201212.jpg
---

パンダヒーロー　

作词作编曲：ハチ  
Mix：まふまふ  
后期：そらる  
Rap作词：nqrse  
pv：MONO-Devoid  
曲绘：△○□×  
歌：luz / nqrse / そらる/ まふまふ  
翻译：26  
Rap翻译：JZLSX

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

haizai ni pai pu  
廃材(はいざい)にパイプ  
废材作烟斗　  
sabi ta sha rin  
錆(さ)びた車輪(しゃりん)  
生锈的车轮  
meimei ni kuru tta  
銘々(めいめい)に狂(くる)った  
人人癫狂的　  
kai ga no ichi  
絵画(かいが)の市(いち)  
绘画的市集  
kiiroi dātsu ban ni  
黄色(きいろ)いダーツ板(ばん)に  
朝黄色的镖靶  
chuusha no hari to  
注射(ちゅうしゃ)の針(はり)と  
丢出注射筒的针  
ho-mu be-su ni houshi no te  
ホームベースに縫糸(ほうし)の手(て)  
抓住本垒板　缝线的手

o komari naraba aitsu wo yobe  
お困(こま)りならばあいつを呼(よ)べ  
有什么困扰就呼叫那家伙吧  
sou dentou ga kakomu gura un do  
送電塔(そうでんとう)が囲(かこ)むグラウンド  
电线塔围绕的操场  
shiro kuro aimai na seigi no hi-ro-  
白黒曖昧(しろくろあいまい)な正義(せいぎ)のヒーロー  
是非暧昧的正义英雄  
hidari te ni wa kin zoku batto  
左手(ひだりて)には金属(きんぞく)バット  
左手拿着金属球棒

no izu dake haite inu raji o  
ノイズだけ吐(は)いて犬(いぬ)ラジオ  
净只是乱吐噪音的　狗电台  
furafura ni ne on bani-ga-ru  
フラフラにネオンバニーガール  
摇摇晃晃霓虹灯下　兔女郎  
souba wa opiu mu no tane hitotsu bu  
相場(そうば)はオピウムの種一粒(たねひとつぶ  
行情价是鸦片种子一粒  
oku no hou ni nomarete iku  
奥(おく)の方(ほう)に呑(の)まれていく  
吞咽到最深处下去

hitotsu tanomu ze onegai da  
「一(ひと)つ頼(たの)むぜ、お願(ねが)いだ」  
给我一个吧 拜托啦  
karakara no ringo sashi dashi te  
カラカラの林檎(りんご)差(さ)し出(だ)して  
就递去干巴巴的苹果  
nan demo nai you na koe de guzu tte  
何(なん)でもないような声(こえ)で愚図(ぐず)って  
像在说着没什么啦声音慢吞吞  
saa dokonimo ikenai na  
さあ 何処(どこ)にも行(い)けないな  
来吧 哪里也去不了啊

pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
kemuru jyouki kensou no me  
煙(けむ)る蒸気(じょうき)喧騒(けんそう)の目(め)  
熏烟　蒸气　喧骚的眼  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
kokode toujyou pinchi hitta-  
ここで登場(とうじょう)ピンチヒッター  
在此登场代打 距Hitte  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
arewa kitto panda hi-ro-  
あれはきっとパンダヒーロー  
那一定就是熊猫英雄  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
saraba ototoi sa tsu jin raina-  
さらば一昨日(おととい)殺人(さつじん)ライナー  
再会吧 前日杀人直球

（rap part）  
Tell me why

告诉我为什么  
sono kyou kai sen wa  
その境界線(きょうかいせん)は?  
那个边界线是？  
(P two P)kara bou gai den pa  
P2Pから妨害電波(ぼうがいでんぱ)  
从P2P开始的干扰电波  
dare kare  
誰彼(だれかれ)  
黄昏(那是谁)  
baka nukashi tera  
馬鹿(ばか)抜(ぬ)かしてら  
漏掉那傻子  
nakami wa sukasuka  
中身(なかみ)はスカスカ  
里面空荡荡  
kaibou suru sabukaru cha-  
解剖(かいぼう)するサブカルチャー  
解剖的亚文化  
(Yeah ready Back again )  
kokowa yu-topia  
此処(ここ)はユートピア  
这里是乌托邦？  
susumi odoru gusha no ma-chi  
進(すす)み 踊(おど)る 愚者(ぐしゃ)のマーチ  
前进着 舞蹈着 愚者的行军

kaniba rizumu to kotoba dake  
カニバリズムと言葉(ことば)だけ  
只不过与食人族一起聊天  
utau ando roido to ason deru  
歌(うた)うアンドロイドと遊(あそ)んでる  
与歌唱的人形机器人一起游戏  
kitto kiraware ten da waga hi-ro-  
きっと嫌(きら)われてんだ我(わ)がヒーロー  
一定会被大家讨厌吧我的英雄  
kitto nozomare ten da hora hi-ro-  
きっと望(のぞ)まれてんだほらヒーロー  
一定是被大家期望着吧看哪英雄

kaniba rizumu to kotoba dake  
カニバリズムと言葉(ことば)だけ  
只不过与食人族一起聊天  
utau ando roido to ason deru  
歌(うた)うアンドロイドと遊(あそ)んでる  
与歌唱的人形机器人一起游戏  
kitto kiraware ten da waga hi-ro-  
きっと嫌(きら)われてんだ我(わ)がヒーロー  
一定会被大家讨厌吧我的英雄  
kitto nozomare ten da hora hi-ro-  
きっと望(のぞ)まれてんだほらヒーロー  
一定是被大家期望着吧看哪英雄

pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
nerai kuramu san yuu kan  
狙(ねら)い眩(くら)む三遊間(さんゆうかん)  
瞄准　晕眩　三垒与游击者的对峙间  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
kokode tou jyou pinchi ranna-  
ここで登場(とうじょう)ピンチランナー  
在此登场代跑　危机马拉松  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
tsumari niten bi hain do  
つまり二点(にてん)ビハインド  
简单来说　得分还差两点  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
umaku ika nai  
上手(うま)く行(い)かない  
无法顺利表现的  
kan jyou sei gen  
感情制限(かんじょうせいげん)～  
情感限制～  
kan jyou sei gen  
感情制限(かんじょうせいげん)…  
情感限制…  
kan jyou sei gen  
感情制限(かんじょうせいげん)ー  
情感限制ー  
kan jyou sei gen  
感情制限(かんじょうせいげん)↑↑↑  
情感限制↑↑↑

（rap part ）  
BANG  
konou wo dogai shi  
効能(こうのう)を度外視(どがいし)  
将效能置之度外  
bara makare ta\* ばら撒(ま)かれた\*  
散播开的\*\*\*\*  
mattan made kanji ta kyou shuku  
末端(まったん)まで感(かん)じた恐縮(きょうしゅく)  
一直到末端都感觉到的恐惧  
risei ga honnou no maigo  
理性(りせい)が本能(ほんのう)の迷子(まいご)  
理性是本能的迷路的孩子  
kono shin ryaku sensou hiraku  
この侵略戦争(しんりゃくせんそう)開(ひら)く  
打响这侵略战争  
tenbou ippatsu KO bo-ru  
展望(てんぼう)一発(いっぱつ)KO ボール  
展望一发KO的球  
(Lethal Weapon）  
致命武器  
nigasu heraua batto  
逃(に)がすヘラウアバット  
逃走Heraua Bat  
toraburu bakka  
トラブルばっか?  
全是trouble？

baketsu kabu tta neko ga naku  
バケツ被(かぶ)った猫(ねこ)が鳴(な)く  
关在水桶里的猫哭叫著  
hitori mata hitori kiete iku  
一人(ひとり)また一人(ひとり)消(き)えて行(い)く  
一人又一人的消失不见  
imasara dou shiyou mo nai kono ge-mu  
今更(いまさら)どうしようもないこのゲーム  
反正现在做什麼也没用了这个游戏  
saa dokonimo ike nai na  
さあ何処(どこ)にも行(い)けないな  
来吧哪里也去不了啊

pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
ganaru baita bou gen no me  
がなる売女(ばいた)暴言(ぼうげん)の目(め)  
轻而易举　妓/女　恶言恶语的眼  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
buza- kumo no ko kei hou tou  
ブザー蜘蛛(くも)の子(こ)警報灯(けいほうとう)  
蜂鸣器　蜘蛛女　警报灯  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
arewa kitto panda hi-ro-  
あれはきっとパンダヒーロー  
那一定就是熊猫英雄  
pa ppa ppara ppa pa para pa  
パッパッパラッパパパラパ  
啪啪 叭啦 叭叭叭啦叭  
saraba ototoi sa tsu jin raina-  
さらば一昨日(おととい)殺人(さつじん)ライナー  
再会吧 前日杀人直球

kowa shite maware bura un kan  
壊(こわ)して回(まわ)れブラウン管(かん)  
半坏还转着的映像管

saraba ototoi sa tsu jin raina-  
さらば一昨日(おととい)殺人(さつじん)ライナー