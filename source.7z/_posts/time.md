---
title: 〔1〕「オーバータイムオーバーラン」/神様、僕は気づいてしまった(罗马音+平假歌词)
tags:
  - オーバータイムオーバーラン
  - 罗马音
  - 神様、僕は気づいてしまった
  - 假名歌词
id: '703'
date: 2019-07-25 19:25:15
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
---

「オーバータイムオーバーラン」  
(Over Time Over Run)

神様、僕は気づいてしまった  
ー「20XX」专辑收录曲

作曲: 東野へいと

作词: 東野へいと  
Vocal：どこのだれか

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

se-no de fu rai to  
せーのでフライト　  
喊着口号登上航班  
za ttou e rai doon  
雑踏(ざっとう)へライドオン  
乘上纷杂的人群  
i sshun de mai go  
一瞬(いっしゅん)で迷子(まいご)  
就算考量着前进方向  
yuki saki nado kan gae temo  
行(ゆ)き先(さき)など考(かんが)えても  
也会瞬间迷路  
jin sei wa mei ro  
人生(じんせい)は迷路(めいろ)  
人生如迷宫  
sei kai wa nai zo  
正解(せいかい)は無(な)いぞ  
没有正确答案哦  
isso motto fumi kome  
いっそもっと踏(ふ)み込(こ)め  
干脆更进一步吧

buka kkou de sae naku temo  
不恰好(ぶかっこう)で冴(さ)えなくても　  
就算笨拙又不敏锐  
kawan nai bokura datte ii yo  
変(か)わんない僕等(ぼくら)だっていいよ  
我们也无需做出改变  
wakan nai ze koko kara ga en chou sen da  
わかんないぜここからが延長戦(えんちょうせん)だ  
我才不管 此后就是延长战了  
kudan nai koto wa kore ijyou  
くだんないことはこれ以上(いじょう)　  
感到无聊的事情  
kudan nai mama ni shita tte iiyo  
くだんないままにしたっていいよ  
也不用改变看法  
wakan nai ze koko kara ga en chou sen da  
わかんないぜここからが延長戦(えんちょうせん)だ  
我才不管 此后就是延长战了  
mi kae shite yarou ze ki nou wo  
見返(みかえ)してやろうぜ昨日(きのう)を  
让我们来回顾一下昨天吧

kon kai ga sai go tte mou nan kai to  
今回(こんかい)が最後(さいご)ってもう何回(なんかい)と  
这是最后一次这话已经说过多少次了  
san shin shite au to  
三振(さんしん)してアウト　  
三振出局  
hai sou shite wa nai te i ta rou  
敗走(はいそう)しては泣(な)いていたろう  
失败之后也曾失声痛哭吧  
cho tto shita tei do  
ちょっとした程度(ていど)　  
微不足道的程度  
son kurai no sai nou  
そんくらいの才能(さいのう)  
毫不起眼的才能  
isso sute chi ma tta hou ga ii to  
いっそ捨(す)てちまった方(ほう)がいいと  
还不如舍弃掉比较好吧  
nage ire ta yume no kazu dake hokore  
投(な)げ入(い)れた夢(ゆめ)の数(かず)だけ誇(ほこ)れ  
为自己投入过的每一个梦想骄傲吧  
mou ushi nau mono nan te nai  
もう失(うしな)うものなんてない　  
已经没什么可以失去的了  
mei sei wo se ou hi tsu you mo nai  
名声(めいせい)を背負(せお)う必要(ひつよう)もない  
没有必要非得背负名声

mi kan sei de kita naku temo  
未完成(みかんせい)で汚(きたな)くても　  
就算还不成熟满身泥污  
nu gue nai bokura datte ii yo  
拭(ぬぐ)えない僕等(ぼくら)だっていいよ  
我们也不必非要擦拭干净  
wakan nai ze koko kara ga en chou sen da  
わかんないぜここからが延長戦(えんちょうせん)だ  
我才不管 此后就是延长战了  
tsuman nai koto wa sore ijyou  
つまんないことはそれ以上(いじょう)　  
感觉没有价值的事  
tsuman nai mama no mushi de iiyo  
つまんないままの無視(むし)でいいよ  
继续无视掉就好了  
wakan nai ze koko kara ga en chou sen da  
わかんないぜここからが延長戦(えんちょうせん)だ  
我才不管 此后就是延长战了  
mi kae shite ya rou ze ki nou wo  
見返(みかえ)してやろうぜ昨日(きのう)を　  
让我们来回顾一下昨天吧  
owa tte shima tta ki nou no boku tachi wo  
終(お)わってしまった昨日(きのう)の僕達(ぼくたち)を  
回顾一下已经结束的 昨天的我们

bu ai sou de shiri gomi demo  
無愛想(ぶあいそう)で尻込(しりご)みでも　  
就算态度冷淡踌躇不前  
yuzun nai bokura datte ii yo  
譲(ゆず)んない僕等(ぼくら)だっていいよ  
我们也不必退让  
wakan nai ze koko kara ga en chou sen da  
わかんないぜここからが延長戦(えんちょうせん)だ  
我才不管 此后就是延长战了  
sekai jyuu ga dou fukashi temo  
世界中(せかいじゅう)がどう吹(ふ)かしても　  
无论世界如何转动  
jibun sae shin ji re reba ii yo  
自分(じぶん)さえ信(しん)じれればいいよ  
只要相信自己就好  
wakan nai ze kokokara ga en chou sen da  
わかんないぜここからが延長戦(えんちょうせん)だ  
我才不管 此后就是延长战了  
suku tte yarou ze ki nou wo  
救(すく)ってやろうぜ　昨日(きのう)を  
让我们来拯救昨天吧  
toba shite ikou ze motto  
飛(と)ばしていこうぜ　もっと  
向更高的天空飞翔吧