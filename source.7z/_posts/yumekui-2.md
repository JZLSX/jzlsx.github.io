---
title: 「ユメクイ（食梦貘）」/After the Rain (そらる&まふまふ)【罗马音+假名歌词】
tags:
  - ユメクイ
  - まふまふ
  - そらる
  - After the Rain
  - 罗马音
  - 假名歌词
id: '742'
date: 2019-10-31 20:07:48
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/3353f0ff8bb890c546e1f61dcfa58d6c0033c714.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/3353f0ff8bb890c546e1f61dcfa58d6c0033c714.jpg
---

「ユメクイ」/After the Rain

作詞作編曲：まふまふ  
Mix/mastering：そらる  
Guitar：三矢禅晃  
絵：Aちき  
映像：みず希  
唄: After the Rain(そらる&まふまふ)

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

ran tan no o yaku wa go men kai？  
ランタンの お役(やく)は御免(ごめん)かい?  
u wa tsu i ta yume naka wo jyou ei shi you  
浮(うわ)ついた 夢中(ゆめなか)を上映(じょうえい)しよう  
ka shi zu i ta te wo to rya mu kou e  
傅(かしず)いた 手(て)を取(と)りゃ向(む)こうへ  
o tsu re shi na sen ri tsu no pa-thi- nai to  
お連(つ)れしな 戦慄(せんりつ)のパーティーナイト

hi ,kids  
horo yo i no fei ku ta da en do fe-zu  
微酔(ほろよ)いのフェイク ただエンドフェーズ  
dewa ko i no (siave) po-ka- fei su ki to tte  
では恋(こい)のsiave ポーカーフェイス気取(きと)って  
(fall in) wa nai hou  
fall in は 内包(ないほう)  
nai fu fo-ku jya tori wake ran nai  
ナイフ＆フォークじゃ取(と)り分(わ)けらんない  
tei ku au to go sho mou  
テイクアウトご所望(しょもう)  
ai ta gurasu wo u me ru dou ri ko chou you  
空(あ)いたグラスを埋(う)める道理(どうり)誇張用(こちょうよう)  
(Cheers) kan pai no ai zu  
Cheers 乾杯(かんぱい)の合図(あいず)  
ta ri nai no (eyes)  
足(た)りないの eyes  
all is well.

yume ku i jyo-ka-  
夢喰(ゆめく)いジョーカー  
hi i tara sai go  
引(ひ)いたら最後(さいご)  
kimi ni nu i tsu i te  
君(きみ)に 縫(ぬ)いついて  
pe a hi to tsu  
ペアひとつ  
mayo e ru ai ni yuu yo wa nai no sa  
迷(まよ)える愛(あい)に猶予(ゆうよ)はないのさ  
koko e o i de te ma ne ku ho rou  
ここへ おいで 手招(てまね)くホロウ

tsu mi mo ne gai mo  
罪(つみ)も 願(ねが)いも  
ko kyu u hito tsu mo  
呼吸(こきゅう)ひとつも  
zen bu no mi kon de  
全部(ぜんぶ) 飲(の)み込(こ)んで  
a ge ru kara  
あげるから  
a shi ta kara boku no o hime sama  
明日(あした)からボクのお姫様(ひめさま)  
ne mu re ne mu re  
眠(ねむ)れ 眠(ねむ)れ  
to wa no naka  
永久(とわ)の中(なか)

su te fuda wo a tsu me ta fu guu wo  
捨(す)て札(ふだ)を 集(あつ)めた不遇(ふぐう)を  
ka e te a ge you kimi dake wa toku be tsu ni  
変(か)えてあげよう 君(きみ)だけは特別(とくべつ)に

hora (get lost in a maze)  
ほら get lost in a maze  
o do re to tema neki dasu shou mei  
踊(おど)れと手招(てまね)き出(だ)す照明(しょうめい)  
ho ri na tei sai wa(like a holy night)  
放(ほ)りな 体裁(ていさい)は like a holy night  
kou ri na dai shou ka ccha i na sou i da  
高利(こうり)な 代償(だいしょう)買(か)っちゃいな 総意(そうい)だ  
o ki ni me su kana (Princess)  
お気(き)に召(め)すかなPrincess  
tsu ko na shi tei ru (Twin tail）  
着(つ)こなしているTwin tail  
sou zou jya furi-ge-mu dami-ne-mu  
想像(そうぞう)じゃ フリーゲーム ダミーネーム  
(You are the one.) nera u ei mu  
You are the one. 狙(ねら)うエイム  
(笑)

michi ni ma yo tta saki no ne on ni  
道(みち)に迷(まよ)った 先(さき)のネオンに  
i za na e ru a su wa  
誘(いざな)える 明日(あす)は  
a ri wa shi nai  
ありはしない  
maya kasu you ni kubi wo kan de i ru  
瞞(まやか)すように首(くび)を噛(か)んでいる  
boku wa dou ke  
ボクは 道化(どうけ)  
kimi wo sa ra u  
君(きみ)を攫(さら)う

「a na ta wa dare？」  
「貴方(あなた)は誰(だれ)?」  
dare da tte ii sa  
誰(だれ)だっていいさ  
dare mo shin sou wo  
誰(だれ)も真相(しんそう)を  
shi ri wa shi nai  
知(し)りはしない  
suga ta mi wa kata mu ku mama de ii  
姿見(すがたみ)は傾(かたむ)くままでいい  
to mo ni shi zu mu  
共(とも)に 沈(しず)む  
to wa no naka  
永久(とわ)の中(なか)

mou yoru ga a ke re ba pare-do wa o wa ru  
もう夜(よる)が明(あ)ければパレードは終(お)わる  
i chi mai sura mo ta nai kimi ga su te fuda  
1枚(いちまい)すら持(も)たない君(きみ)が捨(す)て札(ふだ)  
ni ge rare ya shi nai  
逃(に)げられやしない  
ni ga shi ya shi na i  
逃(に)がしやしない  
ma kku ra na yume made  
真(ま)っ暗(くら)な夢(ゆめ)まで  
o bore te chou dai  
溺(おぼ)れてちょうだい

『What’s your name ?』

yume ku i jyo-ka-  
夢喰(ゆめく)いジョーカー  
hi i tara sai go  
引(ひ)いたら最後(さいご)  
kimi ni nu i tsu i te  
君(きみ)に 縫(ぬ)いついて  
pe a hi to tsu  
ペアひとつ  
mayo e ru ai ni yuu yo wa nai no sa  
迷(まよ)える愛(あい)に猶予(ゆうよ)はないのさ  
koko e o i de te ma ne ku ho rou  
ここへ おいで 手招(てまね)くホロウ

tsu mi mo ne gai mo  
罪(つみ)も 願(ねが)いも  
ko kyu u hito tsu mo  
呼吸(こきゅう)ひとつも  
zen bu no mi kon de  
全部(ぜんぶ) 飲(の)み込(こ)んで  
a ge ru kara  
あげるから  
a shi ta kara boku no o hime sama  
明日(あした)からボクのお姫様(ひめさま)  
ne mu re ne mu re  
眠(ねむ)れ 眠(ねむ)れ  
to wa no naka  
永久(とわ)の中(なか)