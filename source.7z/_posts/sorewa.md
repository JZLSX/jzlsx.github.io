---
title: 「それは恋の終わり」/まふまふ 【罗马音 + 假名歌词】
tags:
  - それは恋の終わり
  - 罗马音
  - まふまふ
  - 假名歌词
  - 神楽色アーティファクト
id: '712'
date: 2019-09-19 19:33:39
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/4d4b7f989321b9178e0d6e88956699ecbea31612.jpg@380w_240h_100Q_1c.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/4d4b7f989321b9178e0d6e88956699ecbea31612.jpg@380w_240h_100Q_1c.jpg
---

「それは恋の終わり」

——《神楽色アーティファクト》収録曲  
作詞/作編曲: まふまふ  
唄: まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

a se bamu o n do wo ka ze ni no se te  
汗(あせ)ばむ温度(おんど)を風(かぜ)に乗(の)せて  
kono na tsu sai go no hana bi wo mi run da  
この夏(なつ)最後(さいご)の花火(はなび)を見(み)るんだ  
yuu hi no kage ga yoru wo tsu re ta  
夕日(ゆうひ)の影(かげ)が夜(よる)を連(つ)れた  
kono na tsu sai go no boku ra no yume  
この夏(なつ)最後(さいご)のボクらの夢(ゆめ)

fu i no shi sen to kuro i naga kami wo yuwa i ta  
不意(ふい)の視線(しせん)と黒(くろ)い長髪(ながかみ)を結(ゆ)わいた  
yu ka ta su gata to kya sha na se naka  
浴衣(ゆかた)姿(すがた)と華奢(きゃしゃ)な背中(せなか)  
ta so gare do ki no mu kou  
黄昏時(たそがれどき)の向(む)こう  
pa- tto  
ぱーっと  
a no sora ni  
あの空(そら)に

ha na bi ga a ga tte  
花火(はなび)が上(あ)がって  
ki mi ga hoho e n de  
君(きみ)が微笑(ほほえ)んで  
sono a ri fure ta hi bi ga sube te de  
その有(あ)り触(ふ)れた日々(ひび)が全(すべ)てで  
sore dake da tta  
それだけだった

yo zora wo ki ka zaru  
夜空(よぞら)を着飾(きかざ)る  
hi ka ri no tsu bu ni  
光(ひかり)の粒(つぶ)に  
o ku rete o to ga suru  
遅(おく)れて音(おと)がする  
sore ga ko i no o wari to shi ra zu ni  
それが恋(こい)の終(お)わりと知(し)らずに  
kimi ni wa ra i kake te ita  
君(きみ)に笑(わら)いかけていた

koko ro ga doko ka sozo ro na no wa  
心(こころ)がどこか漫(そぞ)ろなのは  
geta ga ko su rete i ta mu kara da kke  
下駄(げた)が擦(こす)れて痛(いた)むからだっけ  
hoha ba mo nani mo a wa na i no wa  
歩幅(ほはば)も何(なに)も合(あ)わないのは  
hito me wo sa ke te a ru i ta kara  
人目(ひとめ)を避(さ)けて歩(ある)いたから?

kara ppo no te sura u me rare nai  
空(から)っぽの手(て)すら埋(う)められない  
i ku ji na shi no sai shuu re ssha  
意気地(いくじ)なしの最終列車(さいしゅうれっしゃ)  
ra mu ne no ko kyuu ni to ji komo ru  
ラムネの呼吸(こきゅう)に閉(と)じこもる  
kono bi- dama mi tai ni  
このビー玉(だま)みたいに  
a no u mi no mu kou gawa yori mo  
あの海(うみ)の向(む)こう側(がわ)よりも  
zu tto zu tto too i i ppo  
ずっとずっと遠(とお)い一歩(いっぽ)  
tato e dore dake chi ka tsu i te mo  
たとえどれだけ近(ちか)づいても  
sono ne ga i wa mou too sugi ru  
その願(ねが)いはもう遠(とお)すぎる

ha na bi ga ka ren ni  
花火(はなび)が可憐(かれん)に  
i ro tsu i te mi seru  
色付(いろつ)いてみせる  
sono kura yami no fuka i to ko ro ni  
その暗闇(くらやみ)の深(ふか)いところに  
kizu ke na ka tta  
気(き)づけなかった  
fu ta ri no suki ma wo  
ふたりの隙間(すきま)を  
te ra su no ko ri bi  
照(て)らす残(のこ)り火(び)  
o kure te o to ga suru  
遅(おく)れて音(おと)がする

u chi a ga tte wa nigi wa u hito nami  
打(う)ち上(あ)がっては賑(にぎ)わう人波(ひとなみ)  
kyou wa ha chi ga tsu no zora  
今日(きょう)は8月(はちがつ)の空(ぞら)  
sore ga ko i no o wa ri to shi ra zu ni  
それが恋(こい)の終(お)わりと知(し)らずに  
kimi ni wara i kake te ita  
君(きみ)に笑(わら)いかけていた

a to su ko shi no mou su ko shi no  
あと少(すこ)しの もう少(すこ)しの  
u mara nai kyo ri to na tsu  
埋(う)まらない 距離(きょり)と夏(なつ)  
to do ka na i sa wa re na i  
届(とど)かない 触(さわ)れない  
a no ha na bi no you ni  
あの花火(はなび)のように