---
title: 「シャルル」 まふまふ 歌ってみた【罗马音+假名歌词】
tags:
  - シャルル
  - バルーン
  - 罗马音
  - まふまふ
  - 假名歌词
id: '719'
date: 2019-10-09 19:38:37
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/84ad0a60e0a80e03501d7c16c56f6276dafe927f.jpg@380w_240h_100Q_1c.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/84ad0a60e0a80e03501d7c16c56f6276dafe927f.jpg@380w_240h_100Q_1c.jpg
---

「シャルル」

作詞：バルーン  
作曲：バルーン  
唄・Mix：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

sa yo na ra wa a na ta kara i tta  
さよならはあなたから言(い)った  
so re na no ni  
それなのに  
hoo wo nu ra shi te shi ma u no  
頬(ほお)を濡(ぬ)らしてしまうの  
sou ya tte ki nou no koto mo  
そうやって昨日(きのう)の事(こと)も  
ke shi te shi mau nara  
消(け)してしまうなら  
mou ii yo  
もういいよ  
wa ra tte  
笑(わら)って

hana taba wo kaka e te a ru i ta  
花束(はなたば)を抱(かか)えて歩(ある)いた  
i mi mo naku  
意味(いみ)もなく  
ta da ma chi wo mi o ro shi ta  
ただ街(まち)を見下(みお)ろした  
kou ya tte ri sou no fu chi ni  
こうやって理想(りそう)の縁(ふち)に  
kokoro wo o ki sa tte iku  
心(こころ)を置(お)き去(さ)っていく  
mou ii ka  
もういいか

kara ppo de i you  
空(から)っぽでいよう  
sore de i tsu ka  
それでいつか  
fuka i a o de mi ta shi ta  
深(ふか)い青(あお)で満(み)たした  
no nara dou da rou  
のならどうだろう  
ko n na fuu ni  
こんな風(ふう)に  
na ya me ru no kana  
悩(なや)めるのかな

ai wo  
愛(あい)を  
u ta tte u ta tte  
謳(うた)って 謳(うた)って  
kumo no u e  
雲(くも)の上(うえ)  
ni go ri ki tte wa mi e na i ya  
濁(にご)りきっては見(み)えないや  
i ya i ya  
嫌(いや) 嫌(いや)  
too ku e ga i te ita hi bi wo  
遠(とお)く描(えが)いていた日々(ひび)を  
ka ta tte ka ta tte  
語(かた)って語(かた)って  
yo ru no mu re  
夜(よる)の群(む)れ  
i ga mi a tte kiri ga na i na  
いがみ合(あ)ってきりがないな  
i na i na  
否(いな) 否(いな)  
wa ra i a tte sa yo na ra  
笑(わら)い合(あ)ってさよなら

a sa ya ke to  
朝焼(あさや)けと  
a na ta no ta me i ki  
あなたの溜息(ためいき)  
kono ma chi wa  
この街(まち)は  
boku ra no yume wo mi te ru  
僕等(ぼくら)の夢(ゆめ)を見(み)てる  
kyou da tte ta ga i no koto wo  
今日(きょう)だって互(たが)いの事(こと)を  
wa su re te i kun da ne  
忘(わす)れていくんだね  
nee sou de sho  
ねえ そうでしょ

da ma tte i you  
黙(だま)っていよう  
sore de i tsu ka  
それでいつか  
sa i na mare ta to shi te mo  
苛(さいな)まれたとしても  
be tsu ni i in da yo  
別(べつ)に良(い)いんだよ  
kon na u re i mo  
こんな憂(うれ)いも  
i mi ga a ru nara  
意味(いみ)があるなら

ko i to  
恋(こい)と  
ka za tte ka za tte  
飾(かざ)って 飾(かざ)って  
shi zu ka na hou e  
静(しず)かな方(ほう)へ  
yo go re ki tta ko to ba wo  
汚(よご)れきった言葉(ことば)を  
i ma i ma i ma  
今 (いま) 今 (いま) 今 (いま)  
「koko ni wa dare mo i nai」  
「此処(ここ)には誰(だれ)もいない」  
「ee、sou ne」  
「ええ、そうね」  
ma za tte ma za tte  
混(ま)ざって 混(ま)ざって  
fu ta ri no ha te  
二人(ふたり)の果(は)て  
yu zu ri a tte nani mo na i na  
譲(ゆず)り合(あ)って何(なに)もないな  
i na i na  
否(いな) 否(いな)  
i ta mi da tte o shi e te  
痛(いた)みだって教(おし)えて

ki tto ki tto  
きっと きっと  
wa ka tte i ta  
わかっていた  
da ma shi a u nan te  
騙(だま)し合(あ)うなんて  
baka ra shii yo na  
馬鹿(ばか)らしいよな  
zu tto zu tto  
ずっと ずっと  
ma yo tte i ta  
迷(まよ)っていた  
hora ne bo ku ra wa ka wa re na i  
ほらね 僕等(ぼくら)は変(か)われない  
so u da rou  
そうだろう  
ta ga i no se i de  
互(たが)いのせいで  
i ma ga a ru no ni  
今(いま)があるのに

a i wo  
愛(あい)を  
u ta tte u ta tte  
謳(うた)って 謳(うた)って  
kumo no u e  
雲(くも)の上(うえ)  
ni go ri ki tte wa mi e na i ya  
濁(にご)りきっては見(み)えないや  
i ya i ya  
嫌(いや) 嫌(いや)  
hi ni hi ni fu e te ita kou kai wo  
日(ひ)に日(ひ)に増(ふ)えていた後悔(こうかい)を  
ka ta tte ka ta tte  
語(かた)って 語(かた)って  
yoru no mu re  
夜(よる)の群(む)れ  
yu ru shi a tte i mi mo na i na  
許(ゆる)し合(あ)って意味(いみ)もないな  
i na i na  
否(いな) 否(いな)

a i wo  
愛(あい)を  
u ta tte u ta tte  
謳(うた)って 謳(うた)って  
kumo no u e  
雲(くも)の上(うえ)  
ka ta tte ka ta tte  
語(かた)って 語(かた)って  
yoru no mu re  
夜(よる)の群(む)れ

wa ra i a tte sa yo na ra  
哂(わら)い合(あ)ってさよなら