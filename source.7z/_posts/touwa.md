---
title: 「永眠童话」/まふまふ【罗马音+平假名+（中文翻译整理）】
tags:
  - 永眠童话
  - 罗马音
  - まふまふ
  - 假名歌词
id: '699'
date: 2019-07-17 19:21:57
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/07/55c1cdbb290220f7baceb1812ae482a5fa74e845.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/07/55c1cdbb290220f7baceb1812ae482a5fa74e845.jpg@1075w_602h.jpg
---

「永眠童话」  
「えいみんどうわ」

作詞：まふまふ  
作曲：まふまふ  
編曲：まふまふ  
唄：IA  
翻译：唐伞小僧

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

shihatsu ni tobi no tte  
始発(しはつ)に飛(と)び乗(の)って　  
飞身跳上始发车  
nai chie wo shibo tte  
無(な)い知恵(ちえ)を絞(しぼ)って  
绞尽未有的脑汁  
orino naka uta tte  
檻(おり)の中(なか)唱(うた)って　  
在牢笼之中咏唱  
chiisa na boku wo shou mei  
小(ちい)さな僕(ぼく)を証明(しょうめい)  
为了证明  
surun da  
するんだ  
渺小的我

seikai no hitotsu mo  
正解(せいかい)の一(ひと)つも  
手头没有一个  
mochi awase chai nakute  
持(も)ち合(あ)わせちゃいなくて  
正确答案  
dareno seki uba tte  
誰(だれ)の席(せき)奪(うば)って  
要夺下别人的位置  
ikite ikuka nan te  
生(い)きていくかなんて　  
而活着  
kowai yo  
怖(こわ)いよ  
太可怕了

sou zenbu shi ttei tan da  
そう全部(ぜんぶ)知(し)っていたんだ  
我心里都一清二楚  
boku ga umarete  
僕(ぼく)が生(う)まれて　  
自出生以来  
karada ga umaku ugo ka naku te  
身体(からだ)がうまく動(うご)かなくて  
身体便无法活动自如  
sei wo su i  
生(せい)を吸(す)い　  
即使吸取生机  
iki wo su i kon datte  
息(いき)を吸(す)い込(こ)んだって  
深深的呼吸  
kawara na in datte  
変(か)わらないんだって　  
都无所改变  
waka tte ita ke do  
わかっていたけど  
我心知肚明

ikite ita koto su ra mo  
生(い)きていたことすらも  
就连活着一事  
itsuka wasure te  
いつか忘(わす)れて  
也终将忘却  
mita sarenu kanashimi  
満(み)たされぬ悲(かな)しみ　  
郁郁不满的悲伤  
sekai ni tokeru you ni  
世界(せかい)に溶(と)けるように  
仿佛融进了世界中  
nozomare nai mono nado  
望(のぞ)まれない物(もの)など　  
不予期待的事物  
nani hitotsu nai  
何(なに)ひとつ無(な)い  
根本就不存在  
asu wo yume miru you ni  
明日(あす)を夢(ゆめ)見(み)るように　  
仿佛梦见明日一般  
mabuta no naka  
瞼(まぶた)の中(なか)  
在眼睑的深处

senro gai no tettou ga  
線路外(せんろがい)の鉄塔(てっとう)が  
轨道外的铁塔  
taore kon dei ku youna  
倒(たお)れ込(こ)んでいくような  
不断的倒塌  
me hirai ta sakiga  
目(め)開(ひら)いた先(さき)が  
睁开双眼见那前方  
mushi bamare teiku  
蝕(むしば)まれていく  
被渐渐吞噬

sou zenbu shitte tanda  
そう全部(ぜんぶ)知(し)ってたんだ　  
我都一清二楚  
ikite iku koto  
生(い)きていくこと  
活着一事  
son na mononi nanimo  
そんなものに何(なに)も  
根本不存在  
imi wa na ku te  
意味(いみ)はなくて  
任何意义  
kanashikute demo hita hashiru  
悲(かな)しくてでもひた走(はし)る  
即使满怀悲伤也要一味冲刺  
sonna ki wa nai kara  
そんな気(き)はないから　  
不想这样做  
mou nekase teyo  
もう寝(ね)かせてよ  
所以让我睡下吧

nokosare ta tomoshibi ga  
残(のこ)された灯(ともしび)が  
残留的灯光  
kieru koro ni wa  
消(き)えるころには  
熄灭之时  
boku ga boku de aru koto mo  
僕(ぼく)が僕(ぼく)であることも　  
我将连自己的事  
wasure te shi ma tte  
忘(わす)れてしまって  
都忘却掉  
suku wareru mono nan te  
救(すく)われるものなんて　  
能得到救赎的事物  
nani hitotsu nai  
何(なに)ひとつ無(な)い  
根本就不存在  
yuuyuu to ochi tewa  
悒々(ゆうゆう)と堕(お)ちては　  
若郁郁坠落的话  
owari ga kuruno nara  
終幕(おわり)が来(く)るのなら  
会迎来终结

asu wo yume miru yori  
明日(あす)を夢(ゆめ)見(み)るより　  
那就勿要梦见明日  
mabuta no naka de  
瞼(まぶた)の中(なか)で  
于眼睑深处