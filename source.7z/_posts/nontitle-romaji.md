---
title: 「ノンタイトル」/まふまふ【罗马音+假名歌词】
tags:
  - ノンタイトル
  - 罗马音
  - まふまふ
  - 假名歌词
id: '2346'
date: 2020-02-14 23:52:11
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/nontitle.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/nontitle.jpg
---

「ノンタイトル」

<a href="https://www.nicovideo.jp/watch/sm36362968">【MV】ノンタイトル／まふまふ</a>

作詞作編曲：まふまふ  
Acoustic guitar：三矢禅晃  
映像：小猫まり  
歌：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译： [https://unijzlsx.cn/translation/nontitle/](https://unijzlsx.cn/translation/nontitle/)

a sa wo ko bo shi ta  
朝(あさ)をこぼした  
ki gu mi no su ki ma  
木組(きぐ)みの隙間(すきま)  
kaze no nu ke mi chi  
風(かぜ)の抜(ぬ)け道(みち)  
haru i ro no sora  
春色(はるいろ)の空(そら)  
kimi no ne goto ga tsu bu ya ku su be te de  
君(きみ)の寝言(ねごと)がつぶやくすべてで  
kyo u ga haji ma ru mi ta i na  
今日(きょう)が始(はじ)まるみたいな

kumo no su ha tta to dana wo a ke te  
蜘蛛(くも)の巣(す)張(は)った戸棚(とだな)を開(あ)けて  
kabi ha e kake no ra i mugi no pan  
カビ生(は)えかけのライ麦(むぎ)のパン  
ka ba n ni tsu me te doko ka e yu kou ka  
かばんに詰(つ)めてどこかへ行(ゆ)こうか  
kimi no shi ra na i ma chi  
君(きみ)の知(し)らない街(まち)

mi chi yuku dake de se ri fu mo na kere ba  
道行(みちゆ)くだけで台詞(せりふ)もなければ  
tori na o shi mo na i wan shi-n  
撮(と)り直(なお)しもないワンシーン  
dono kamera ni mo ko bo re ta se kai ni  
どのカメラにもこぼれた世界(せかい)に  
dai hon mo kan toku mo nan mo nai  
台本(だいほん)も監督(かんとく)も何(なん)もない  
tada no i ba sho no hito tsu mo nai  
ただの居場所(いばしょ)のひとつもない  
sore ga boku no ei ga ka  
それがボクの映画(えいが)か

u shi na tta mono nan te kazo e naku te ii yo  
失(うしな)ったものなんて数(かぞ)えなくていいよ  
boku ra ri yuu na shi ni u ma re ta non tai toru  
ボクら理由(りゆう)無(な)しに生(う)まれたノンタイトル  
nani mo ki ni shi na i te naki jya ku tte ii yo  
何(なに)も気(き)にしないで泣(な)きじゃくっていいよ  
dare mo kimi no ko e nan te ki i cha i nai sa  
誰(だれ)も君(きみ)の声(こえ)なんて聞(き)いちゃいないさ

tama razu i shi wo na ge ta ko men ni  
たまらず石(いし)を投(な)げた湖面(こめん)に  
kimi wa wara tte o do ke te mi se ru  
君(きみ)は笑(わら)っておどけてみせる  
tato e ba a ya shii i ro shi ta mi wo ku chi ni shi temo  
例(たと)えば怪(あや)しい色(いろ)した実(み)を口(くち)にしても  
da re mo o ko ra na i de sho  
誰(だれ)も怒(おこ)らないでしょ？

gare ki no hana wo tsu mu i da bo-to de  
瓦礫(がれき)の花(はな)を紡(つむ)いだボートで  
kimi to futa ri no to u hi ko u  
君(きみ)とふたりの逃避行(とうひこう)  
boku ra wo i wa u ke-ki wa na i kedo  
ボクらを祝(いわ)うケーキはないけど  
aa kon na ku da mo no nai fu de  
ああ こんな果物(くだもの)ナイフで  
son na nu sun da bu-ke mo  
そんな盗(ぬす)んだブーケも  
kimi wo kaza re run da naa  
君(きみ)を飾(かざ)れるんだなあ

en din gu wa ki ta i doo ri  
エンディングは期待(きたい)通(どお)り  
nan te a ru wake nai sa  
なんてあるわけないさ  
na i ta ni fun cho tto  
泣(な)いた2分(にふん)ちょっと  
gomi su te ba no tai toru  
ゴミ捨(す)て場(ば)のタイトル  
a shi ta hai ni na tte  
明日(あした)灰(はい)になって  
fu ki to ba sare you to  
吹(ふ)き飛(と)ばされようと  
dare ka na i te ku reru nan te  
誰(だれ)か泣(な)いてくれるなんて  
o mo ccha i nai yo  
思(おも)っちゃいないよ

nee  
ねえ  
doko ka too ku e nige you yo  
どこか遠(とお)くへ逃(に)げようよ  
koko jya nai doko ka too ku e  
ここじゃないどこか遠(とお)くへ  
mou kou kaku no ren zu ni da tte  
もう 広角(こうかく)のレンズにだって  
u tsu ra na i doko ka too ku e  
映(うつ)らないどこか遠(とお)くへ

sou shi te sai go ni ne ru ma e ni  
そうして最後(さいご)に寝(ね)る前(まえ)に  
na ri ya ma nu jyuu no naka de  
鳴(な)りやまぬ銃(じゅう)の中(なか)で  
kimi no ryou me ni u tsu ri kon da  
君(きみ)の両目(りょうめ)に映(うつ)りこんだ  
sore dake de ii naa  
それだけでいいなあ

kimi wa naka na i de  
君(きみ)は泣(な)かないで  
naka na i de ii yo  
泣(な)かないでいいよ  
o wa ri ni fun ma e no en do ro-ru ni tai toru  
終(お)わり2分前(にふんまえ)のエンドロールにタイトル  
sore wa dare hi tori mo o bo e tei na i you na  
それは誰一人(だれひとり)も覚(おぼ)えていないような  
ki tto a ri kita ri da tta mono ga ta ri  
きっと在(あ)り来(きた)りだった物語(ものがたり)

u shi na tta mono nan te kazo e naku te ii yo  
失(うしな)ったものなんて数(かぞ)えなくていいよ  
boku wa ri yuu na shi ni u ma re ta non tai to ru  
ボクは理由(りゆう)無(な)しに生(う)まれたノンタイトル  
nani mo ki ni shi na i de na ki jya ku tte ii yo  
何(なに)も気(き)にしないで泣(な)きじゃくっていいよ  
dare mo boku no koto nan te shi ri ya shi nai  
誰(だれ)もボクのことなんて知(し)りやしない

kore wa kimi to boku dake no  
これは君(きみ)とボクだけの  
na mo na ki tai to ru  
名(な)もなきタイトル