---
title: 「それを愛と呼ぶだけ」/まふまふ【罗马音+假名歌词】
tags:
  - それを愛と呼ぶだけ
  - 罗马音
  - まふまふ
  - 假名歌词
id: '2374'
date: 2020-02-21 09:38:04
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/005T6iKpgy1gc3ghwex5gj30n70miabt.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/005T6iKpgy1gc3ghwex5gj30n70miabt.jpg
---

「それを愛と呼ぶだけ」

作詞作編曲：まふまふ  
歌：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

a nata no koto ba ga  
貴方(あなた)の言葉(ことば)が  
a nata no ki o ku ga  
貴方(あなた)の記憶(きおく)が  
wa zu kana se ka i wo mi ta shi te  
わずかな世界(せかい)を満(み)たして  
e i ga no o wa ri ni suu fu n a ru you na  
映画(えいが)の終(お)わりに数分(すうふん)あるような  
ko ko chi yo i kyou da  
心地(ここち)よい今日(きょう)だ

te ni toru un mei wa  
手(て)に取(と)る運命(うんめい)は  
te bana su un mei ga  
手放(てばな)す運命(うんめい)が  
fu e te i ku dake  
増(ふ)えていくだけ  
son na chii sa na hoko ro bi ni  
そんな小(ちい)さな綻(ほころ)びに  
ki zu i te i ta no ni  
気(き)づいていたのに

kokoro ga karada wo mi o to su made  
心(こころ)が身体(からだ)を見落(みお)とすまで  
a su no na i se kai e yu ku ma de  
明日(あす)のない世界(せかい)へ行(ゆ)くまで  
u shi na u hito tsu wo kazo e ru koto  
失(うしな)うひとつを数(かぞ)えること  
sore wo a i to yobu dake  
それを愛(あい)と呼(よ)ぶだけ  
a i to yobu dake  
愛(あい)と呼(よ)ぶだけ

a na ta no e ga o mo  
貴方(あなた)の笑顔(えがお)も  
ma ba ta ki hito tsu de  
瞬(まばた)きひとつで  
mi e naku naru ku rai mi jyuu ku da  
見(み)えなくなるくらい未熟(みじゅく)だ  
sore nara moto yori i to shii shi gu sa wo  
それならもとより愛(いと)しい仕草(しぐさ)を  
shi ra nai mama ga ii naa  
知(し)らないままがいいなあ

sugi saru shou gai wo  
過(す)ぎ去(さ)る生涯(しょうがい)を  
ka wa ranu kou kai wo  
変(か)わらぬ後悔(こうかい)を  
i no chi to i u kara  
命(いのち)というから  
dou shi you mo nai hodo ni  
どうしようもないほどに  
a nata ni hi kare tei ru no da rou  
貴方(あなた)に惹(ひ)かれているのだろう

kono te wo no ba se to todo kanu mu kou  
この手(て)を伸(の)ばせど届(とど)かぬ向(む)こう  
yume wo mi ru yori too ku made  
夢(ゆめ)を見(み)るより遠(とお)くまで  
sari yuku a na ta wo moto me ta koto  
去(さ)り行(ゆ)く貴方(あなた)を求(もと)めたこと

sore wo a i to yobu dake  
それを愛(あい)と呼(よ)ぶだけ  
a i to yobu dake  
愛(あい)と呼(よ)ぶだけ