---
title: アルターエゴ(Alter Ego)/まふまふ【罗马音+假名歌词】(第五人格二周年纪念联动原创曲）
tags:
  - アルターエゴ
  - 罗马音
  - まふまふ
  - 假名歌词
id: '3111'
date: 2020-07-05 14:19:33
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/07/maxresdefault1124.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/07/maxresdefault1124.jpg
---

アルターエゴ(Alter Ego)

作詞作編曲：まふまふ  
絵/映像：まふてる  
Vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译：[https://m.weibo.cn/detail/4523055269237109](https://m.weibo.cn/detail/4523055269237109)

yu gan da ki o ku to  
歪(ゆが)んだ記憶(きおく)と  
wa zu ka ni mi ta sare nai  
僅(わず)かに満(み)たされない  
kuu ha ku wa  
空白(くうはく)は  
a na ta no jin kaku  
貴方(あなた)の人格(じんかく)  
mi te kure dake wa o mo te u ra hito tsu no  
見(み)てくれだけは表裏(おもてうら)ひとつの  
a mi gu ru mi  
編(あ)みぐるみ  
soko ni a tte mo  
其処(そこ)に在(あ)っても  
shou tai wa fu mei de shi ta  
正体(しょうたい)は不明(ふめい)でした

tsu gu nai ma ka nai a i tsu mi tsu ku ri  
償(つぐな)い 賄(まかな)い合(あ)い 罪作(つみつく)り  
i tsu ka do kka no yota bana shi？  
いつか何処(どっ)かの与太話(よたばなし)？  
kana shii kana shii mono mono wara i  
悲(かな)しい 愛(かな)しい者(もの) 物笑(ものわら)い  
do cchi e ni ge te kaku re temo  
どっちへ逃(に)げて隠(かく)れても  
ya mi yo no sono  
闇夜(やみよ)の園(その)

「o ni san ko chi ra te no naru hou e」  
「鬼(おに)さんこちら 手(て)の鳴(な)る方(ほう)へ」  
towa ni mu shi ku tta se ka i e  
永久(とわ)に虫喰(むしく)った世界(せかい)へ  
yo a ke nu mama tsu mi wo kazo e te i ru  
夜明(よあ)けぬまま罪(つみ)を数(かぞ)えている  
sai te na fei ku sho- da  
最低(さいて)なフェイクショーだ

ya ma nai a me ni ya me do  
止(や)まない雨(あめ)に病(や)めど  
naga re o chi ru toga nado na i  
流(なが)れ落(お)ちる咎(とが)などない  
soba ni i te kure na i ka  
そばにいてくれないか  
shi kka ku sha  
失格者(しっかくしゃ)

kyo jya ku na ko e wa  
虚弱(きょじゃく)な声(こえ)は  
kokoro wo ka wa su hodo  
心(こころ)を交(か)わすほど  
yume mi tei ta  
夢見(ゆめみ)ていた  
dare ka no jin kaku  
誰(だれ)かの人格(じんかく)  
yo no koto wari ni  
世(よ)の理(ことわり)に  
tada senu a ya ma ri ni  
正(ただ)せぬ誤(あやま)りに  
ki zu i temo i mi wa nai no sa  
気(き)づいても意味(いみ)はないのさ  
jyaa nan ni ki tai shi tei run da  
じゃあ何(なん)に期待(きたい)しているんだ

i tsu wa ru hodo kizu tsu ku hodo o wa ri e  
偽(いつわ)るほど 傷(きず)つくほど終(お)わりへ  
ta e zu ka soku suru puro sesu  
絶(た)えず加速(かそく)するプロセス  
se ki ko mu hodo sei san na ai nara ba  
咳(せ)き込(こ)むほど凄惨(せいさん)な愛(あい)ならば  
ko kkei na fi ku shon de  
滑稽(こっけい)なフィクションで

a no hi yo mi chi ga e ta  
あの日(ひ)読(よ)み違(ちが)えた  
ryo u me i ma da mi e nu mama no  
両目(りょうめ) 未(いま)だ見(み)えぬままの  
boku ni shi tsu bou shi te i tan da  
ボクに失望(しつぼう)していたんだ  
shi kka ku sha  
失格者(しっかくしゃ)

nin gen shi kaku sa naki yo ga ta ri  
人間失格(にんげんしっかく)さ 無(な)き世語(よがた)り  
kyou ga kon na ni ku ra i no ni  
今日(きょう)がこんなに暗(くら)いのに  
u ta gai u ta gai  
疑(うたが)い 疑(うたが)い  
kimi ni yo ri so u chii sa na i ppo mo  
君(きみ)に寄(よ)り添(そ)う小(ちい)さな一歩(いっぽ)も  
kono te ni wa a ma ru you da  
この手(て)には余(あま)るようだ

「o ni san ko chi ra te no naru hou e」  
「鬼(おに)さんこちら 手(て)の鳴(な)る方(ほう)へ」  
towa ni mu shi ku tta se ka i e  
永久(とわ)に虫喰(むしく)った世界(せかい)へ  
yo a ke nu mama tsu mi wo kazo e te i ru  
夜明(よあ)けぬまま罪(つみ)を数(かぞ)えている  
sai te na fei ku sho- da  
最低(さいて)なフェイクショーだ

se i te to o no ku sei ni  
急(せ)いて遠(とお)のく背(せ)に  
a se ta ko e wa todo ki shi na i  
褪(あ)せた声(こえ)は届(とど)きしない  
soba ni i te kure na i ka  
そばにいてくれないか  
shi kka ku sha  
失格者(しっかくしゃ)