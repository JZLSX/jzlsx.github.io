---
title: 「アートを科学する（将艺术科学化）」/まふまふ 【罗马音+假名歌词】一「神楽色アーティファクト」
tags:
  - アートを科学する
  - 罗马音
  - まふまふ
  - 假名歌词
id: '740'
date: 2019-10-17 20:06:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026153733.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/QQ%E6%88%AA%E5%9B%BE20191026153733.jpg
---

「アートを科学する」

一「神楽色アーティファクト」アルバム収録曲  
編曲：まふまふ  
作詞・作曲：まふまふ  
vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

sa mi shi i mama  
寂(さみ)しいまま  
kyou wo o wa ra se nai kara  
今日(きょう)を終(お)わらせないから  
o ki ma ri ni  
お決(き)まりに  
ta do ru tsu- fai bu  
辿(たど)るIIm7→V7(ツーファイブ)

ru- pu shi te  
ループして  
nan do demo mata ru-pu shi te  
何度(なんど)でもまたループして  
hon no san pun han  
ほんの3分半(さんぷんはん)  
yoru wo u me ta  
夜(よる)を埋(う)めた

nai sho ba na shi ga ki ko e te kuru  
ないしょばなしが聞(き)こえてくる  
wan sha- pu no yu me  
I#dim(ワンシャープ)の夢(ゆめ)

boku to a-to wo ka ga ku shi you  
ボクとアートを科学(かがく)しよう  
bu tsu ke a u hodo ki nou shi te  
ぶつけ合(あ)うほど帰納(きのう)して  
kokoro to kimi no han kyuu tai e  
心(こころ)と君(きみ)の半球体(はんきゅうたい)へ  
kuri she shi te i ku  
クリシェしていく

a ri ki ta ri na se kai nara  
在(あ)り来(きた)りな世界(でかい)なら  
nana me shi ta kara i ji ccha e  
斜(なな)め下(した)からいじっちゃえ  
tsu ma saki da chi de a ru ku  
爪先(つまさき)立(だ)ちで歩(ある)く  
go sen fu  
五線譜(ごせんふ)

ri ta ru dan do de  
リタルダンドで  
kyou mo yoru wo o e tara  
今日(きょう)も夜(よる)を終(お)えたら  
san do ten chou shi te  
3度(さんど)転調(てんちょう)して　  
mo tto too ku  
もっと遠(とお)く  
fo ru te  
フォルテ　  
fo ru thi shi mo demo dou shi te  
フォルティシモでもどうして  
ri fu rei n shi nai bo ku no ko to ba  
リフレインしないボクの言葉(ことば)

cho tto demo to do ke ba i i na  
ちょっとでも届(とど)けばいいな

kimi to a-to wo ka ga ku shi tai  
君(きみ)とアートを科学(かがく)したい  
yume no yume demo ba un su shi tai  
夢(ゆめ)の夢(ゆめ)でもバウンスしたい  
dore dake o to wo tsu mu ge ba  
どれだけ音(おと)を紡(つむ)げば  
mata a e ru no ？  
また会(あ)えるの？

tsu zu ku ko-do wa kuri ppin gu no izu  
続(つづ)くコードはクリッピングノイズ  
demo o wa ra nai de fe ru ma-ta  
でも終(お)わらないでフェルマータ  
tsu ma saki da chi de a ru ku  
爪先(つまさき)立(だ)ちで歩(ある)く  
go sen fu  
五線譜(ごせんふ)