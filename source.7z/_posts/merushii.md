---
title: 「2」「メルシー」/ 神様、僕は気づいてしまった【罗马音+假名歌词】
tags:
  - メルシー
  - 罗马音
  - 假名歌词
  - 僕は気づいてしまった
id: '716'
date: 2019-10-12 19:36:47
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
---

「メルシー」

神様、僕は気づいてしまった  
－「20XX」アルバム収録曲

作曲 : Heito Higashino  
作词 : Heito Higashino  
Vocal：どこのだれか

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

su thi gu ma wo o tta  
スティグマを負(お)った  
sa e nai shou nen  
冴(さ)えない少年(しょうねん)  
wara e na i hodo ni  
笑(わら)えない程(ほど)に  
jyuu shou da tta  
重傷(じゅうしょう)だった  
sa re do hibi wa shin zou wo  
されど日々(ひび)は心臓(しんぞう)を  
tsu ki sa shi te ku  
突(つ)き刺(さ)してく

i ki ru ta me  
生(い)きる為(ため)、  
ai wo u tta shi thi - ga-ru  
愛(あい)を売(う)ったシティーガール  
da tou na ne u chi mo  
妥当(だとう)な値打(ねう)ちも  
tsu i cha i na i sa  
付(つ)いちゃいないさ  
do ro no you na ko-hi- non de  
泥(どろ)のようなコーヒー飲(の)んで  
go ma ka shi ta  
誤魔化(ごまか)した

bo ku ra no ko do ku wa  
僕等(ぼくら)の孤独(こどく)は　  
bo ku ra no na mi da wa  
僕等(ぼくら)の涙(なみだ)は　  
ke tsu raku wa  
欠落(けつらく)は  
ga so rin mi tai ni u kan de i te  
ガソリンみたいに浮(う)かんでいて  
tsu ma ha ji ki ni a tte i ru  
爪弾(つまはじ)きに遭(あ)っている

so i tsu ni to ku i ge de  
そいつに得意気(とくいげ)で  
hi wo tsu ke te  
火(ひ)を着(つ)けて  
da i ki ra i na su be te ga  
大嫌(だいきら)いな全(すべ)てが  
hi to o mo i ni shi te  
一思(ひとおも)いにして  
bo ku ra mo ma ki kon de  
僕等(ぼくら)も巻(ま)き込(こ)んで  
fu ki ton de shi ma e ta ra ii no ni  
吹(ふ)き飛(と)んでしまえたらいいのに

se ka i nan te i sshou  
世界(せかい)なんて一生(いっしょう)  
a i se ya shi nai to u ran de ta  
愛(あい)せやしないと恨(うら)んでた  
u ta ga u koto de  
疑(うたが)うことで  
ji bun no i no chi ga  
自分(じぶん)の命(いのち)が  
su ku e ru to o mo tte i ta  
救(すく)えると思(おも)っていた  
na ki jya ku tta mi ra i wo  
泣(な)きじゃくった未来(みらい)を  
bou kan nan te  
傍観(ぼうかん)なんて  
mou de ki nai yo  
もうできないよ

todo ku made mou i kka i  
届(とど)くまでもう一回(いっかい)  
todo ku made mou i kka i  
届(とど)くまでもう一回(いっかい)  
ha ppi- en do nan te no zon jya i nai  
ハッピーエンドなんて望(のぞ)んじゃいない  
hon tou no ji bun ga ki tto  
本当(ほんとう)の自分(じぶん)がきっと  
ho shii da ke  
欲(ほ)しいだけ

yoko ni yu re te su kuramu gun de  
横(よこ)に揺(ゆ)れてスクラム組(ぐ)んで  
ko i wo u ta tta  
恋(こい)を歌(うた)った  
ji dai wa o wa tta  
時代(じだい)は終(お)わった  
nara ba boku ra nani wo to i  
ならば僕等(ぼくら)、何(なに)を問(と)い  
tata ka tte 、su ga tte、 u ta u beki da  
戦(たたか)って、縋(すが)って、歌(うた)うべきだ

i sso i ki te ko na ke rya  
いっそ生(い)きてこなけりゃ  
boku ga boku de na ke re ba ai sare ta  
僕(ぼく)が僕(ぼく)でなければ愛(あい)された  
nee、dou shi te ma da  
ねえ、どうしてまだ  
boku wa i ki run da rou  
僕(ぼく)は生(い)きるんだろう

shi ra re ta ka gen demo  
知(し)られた嘉言(かげん)でも  
ya sa shii i no ri mo  
優(やさ)しい祈(いの)りも　  
wara i gu sa mo  
笑(わら)い種(ぐさ)も  
kono mune ni a i ta ki zu gu chi wo  
この胸(むね)に空(あ)いた傷口(きずぐち)を  
u me rare ya shi nai you da  
埋(う)められやしないようだ

ha ji me kara shi tte ta  
初(はじ)めから知(し)ってた  
ha ji me kara shi tte tan da  
初(はじ)めから知(し)ってたんだ  
sou da rou  
そうだろう  
ji bun wo suku e ru nan te hoka de mo nai  
自分(じぶん)を救(すく)えるなんて他(ほか)でもない  
hon tou no ji bun jya na i no ka  
本当(ほんとう)の自分(じぶん)じゃないのか

se kai da tte boku wo  
世界(せかい)だって僕(ぼく)を  
ai shi cha kure na in da to  
愛(あい)しちゃくれないんだと  
kokoro ni ka gi wo mi ka tte ni  
心(こころ)に鍵(かぎ)を身(み)勝手(かって)に  
ka ke te shi na tte i tan da tta  
かけてしなっていたんだった  
na ki jya ku tta mi rai wo  
泣(な)きじゃくった未来(みらい)を  
bou kan dan te  
傍観(ぼうかん)なんて  
mou deki nai yo  
もうできないよ

todo ku made mou i kka i  
届(とど)くまでもう一回(いっかい)  
todo ku made mou i kka i  
届(とど)くまでもう一回(いっかい)  
ha ppi-en do nan te no zon jya i nai  
ハッピーエンドなんて望(のぞ)んじゃいない  
hon tou no ji bun ga ki tto  
本当(ほんとう)の自分(じぶん)がきっと  
ho shii da ke  
欲(ほ)しいだけ

mei mou mo 、kan shou mo  
迷妄(めいもう)も　感傷(かんしょう)も　  
ai zou mo 、 an tou mo  
愛憎(あいぞう)も　暗闘(あんとう)も  
kuu so na pu rai do mo zen bu wo  
空疎(くうそ)なプライドも全部(ぜんぶ)を  
o wa ri ni shi you  
終(お)わりにしよう

sen bou mo 、sen jyou mo  
羨望(せんぼう)も　扇情(せんじょう)も　  
kou sou mo 、hou nen shi te  
抗争(こうそう)も 放念(ほうねん)して  
i tsu ka no boku ra e ka e rou  
いつかの僕(ぼく)らへ帰(かえ)ろう