---
title: 「メリーバッドエンド(Merry Bad End)」/まふまふ【罗马音+假名歌词】
tags:
  - メリーバッドエンド
  - 罗马音
  - まふまふ
  - 假名歌词
  - イザナワレトラバラー
id: '2508'
date: 2020-03-17 20:11:35
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/03/maxresdefault-1.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/03/maxresdefault-1.jpg
---

「メリーバッドエンド」

作詞作編曲：まふまふ  
絵：寺田てら  
映像：りゅうせー  
Drums：樋口 幸佑  
Mix/Mastering：そらる  
歌：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

ki rai wo hya ku to yon jyuu ji  
嫌(きら)いを１００(ひゃく)と４０字(よんじゅうじ)  
kaki tsu ki no koko ro  
カギ付(つ)きの心(こころ)  
ko to ba no nai fu  
言葉(ことば)のナイフ  
na ki goto de ki ka za tte  
泣(な)き言(ごと)で着飾(きかざ)って  
o ke shou wa tai sou  
お化粧(けしょう)は大層(たいそう)  
ki re i da rou na  
綺麗(きれい)だろうな

a ya tori wo shi ma shou ka  
あやとりをしましょうか  
a ka i ito ni kaku reru  
赤(あか)い糸(いと)に隠(かく)れる  
pi a no no sen  
ピアノの線(せん)  
a na ta wa mou kyou han sha  
貴方(あなた)はもう共犯者(きょうはんしゃ)  
te ni to tta kyou ki no  
手(て)に取(と)った凶器(きょうき)の  
i i wa ke wo dou zo  
言(い)い訳(わけ)をどうぞ

ki i te ki i te  
聞(き)イテ 聞(き)イテ  
a no ko no u wa sa  
アノ子(こ)ノ噂(うわさ)  
nai sho nai sho  
密(ナイショ) 密(ナイショ)  
hiso hiso hiso hiso  
密告(ヒソ)密告(ヒソ)密告(ヒソ)密告(ヒソ)  
(dou zo)  
(どうぞ)  
ki i te ki i te  
聞(き)イテ 聞(き)イテ  
a no ko no u wa sa  
アノ子(こ)ノ噂(うわさ)  
hito no fu kou wa mi tsu no a ji  
人(ひと)の不幸(ふこう)は蜜(みつ)の味(あじ)

ai mo fu ta shi kana yu-to pi a  
愛(あい)も不確(ふたし)かなユートピア  
o ni a so bi shi ma sho  
鬼遊(おにあそ)びしましょ  
ya dori gi no po e tto  
宿(やど)り木(ぎ)のポエット  
kon na mama go to ni naru  
こんなママゴトに生(な)る  
ne gu sa re no e ga o  
根腐(ねぐさ)れの笑顔(えがお)  
ne u chi nan te nai  
値打(ねう)ちなんてない

kyou ki ra wa re na i tame  
今日(きょう)嫌(きら)われないため  
wa ni na tte a no ko wo  
輪(わ)になってあの子(こ)を  
ki ra i ni naru no  
嫌(きら)いになるの  
hai ta hai seki mato a tte  
排他(はいた) 排斥(はいせき)的当(まとあ)て  
u chi nu i te shi ma e ba  
打(う)ち抜(ぬ)いてしまえば  
tsu gi wa dare no ban  
次(つぎ)は誰(だれ)の番(ばん)？

me ri- ba ddo endo  
メリーバッドエンド（笑）  
a hahahaha  
あはははは

ki rai wo hya ku to yon jyuu ji  
嫌(きら)いを１００(ひゃく)と４０字(よんじゅうじ)  
kaki tsu ki no koko ro  
カギ付(つ)きの心(こころ)  
ko to ba no nai fu  
言葉(ことば)のナイフ  
o cha ka i no pasu wa-do  
お茶会(ちゃかい)のパスワード  
do u chou no hen tou ga  
同調(どうちょう)の返答(へんとう)が  
o ki ni i ri  
お気(き)に入(い)り

se naka ni tsu i ta re tte ru to  
背中(せなか)についたレッテルと  
ji tsu you teki ka chi no ne bu mi a i  
実用的(じつようてき)価値(かち)の値踏(ねぶ)み合(あ)い  
a re to kore wa kyuu dai ten  
あれとこれは及第点(きゅうだいてん)  
sore no ta chi i ri wa kin shi suru  
それの立(た)ち入(い)りは禁止(きんし)する

to mare to ma re kono yubi to ma re  
とまれ とまれ このゆびとまれ  
to mare to ma re kono yubi to ma re  
とまれ とまれ このゆびとまれ  
to mare to ma re naka yubi to ma re  
とまれ とまれ なかゆびとまれ  
ka wa i i a no ko wa ka ya no soto  
かわいいあの子(こ)は蚊帳(かや)の外(そと)  
dou zo  
どうぞ

ki i te ki i te  
聞(き)イテ 聞(き)イテ  
a no ko no u wa sa  
アノ子(こ)ノ噂(うわさ)  
nai sho nai sho  
密(ナイショ)密(ナイショ)  
hiso hiso hiso hiso  
密告(ヒソ)密告(ヒソ)密告(ヒソ) 密告(ヒソ)  
(dou zo)  
(どうぞ)  
ki i te ki i te  
聞(き)イテ 聞(き)イテ  
a no ko no u wa sa  
アノ子(こ)ノ噂(うわさ)  
tsu gi no a i zu de a na ta no ban  
次(つぎ)の合図(あいず)で貴方(あなた)の番(ばん)

ai mo fu ta shi kana yu-to pi a  
愛(あい)も不確(ふたし)かなユートピア  
o ni a so bi shi ma sho  
鬼遊(おにあそ)びしましょ  
ya dori gi no po e tto  
宿(やど)り木(ぎ)のポエット  
ki tto hon tou no na mi da mo  
きっと本当(ほんとう)の涙(なみだ)も  
wa ra i kata sura mo wa su re cha tta yo  
笑(わら)い方(かた)すらも忘(わす)れちゃったよ

ai mo fu ta shi kana yu-to pi a  
愛(あい)も不確(ふたし)かなユートピア  
i tsu made mo tsu zu ku  
いつまでも続(つづ)く  
ya dori gi no po e tto  
宿(やど)り木(ぎ)のポエット  
kon na mama go to ni naru  
こんなママゴトに生(な)る  
ne gu sa re no e ga o  
根腐(ねぐさ)れの笑顔(えがお)  
ne u chi nan te nai  
値打(ねう)ちなんてない

dou shi te? dou shi te? shi a wa se ga  
どうして？どうして？ 幸(しあわ)せが  
kokoro no suki ma wo ko bo re o chi ru no  
心(こころ)の隙間(すきま)を零(こぼ)れ落(お)ちるの  
zen bu zen bu wo ko wa shi te  
全部(ぜんぶ)全部(ぜんぶ)を壊(こわ)して  
a na da rake no yo ni dare mo i naku na tta  
穴(あな)だらけの夜(よ)に誰(だれ)もいなくなった

me ri- ba ddo endo  
メリーバッドエンド　  
a hahahahahahaha  
あははははははは