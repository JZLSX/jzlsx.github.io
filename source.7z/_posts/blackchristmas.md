---
title: 【歌词翻译】ブラッククリスマス / After the Rain（黑色圣诞）
tags:
  - ブラッククリスマス
  - まふまふ
  - そらる
  - After the Rain
  - 歌词翻译
  - 中文歌词
id: '42'
date: 2018-12-24 23:09:42
category: 歌词翻译
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2018/12/8b1b6e539e57c3d226477a7648aed8621f5c4eed.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2018/12/8b1b6e539e57c3d226477a7648aed8621f5c4eed.jpg
---

黑色圣诞  
翻译：JZLSX

作詞作編曲：まふまふ

\# 转载翻译请标明译者！请勿自行改动翻译！

ブッシュドノエルには蜘蛛のリース（ding-dong）  
用蜘蛛造型的花圈装饰圣诞树干蛋糕（ding-dong）  
食べたりないや  
吃不够啊  
靴下の中身は味気ない　（ding-dong）  
对长袜里的礼物不感兴趣　（ding-dong）  
響け鐘の音  
钟声响起

良い子はいいや（アイツに任せた）  
好孩子就罢了（就交给那家伙了）  
悪い子になった（あの子に夢中さ）  
变成坏孩子的那位（才是令我着迷的对象）  
どこへ行くんだい（どこへ逃げるんだい）  
你打算去哪呢（你打算逃到哪呢）  
遊ぼう？（遊ぼう？）  
来玩吧？（来玩吧？）  
All my love for you will be Christmas gift.  
我对你的所有的爱都将成为圣诞节礼物

A Black Santa Claus is coming to town tonight.  
黑色圣诞老人今晚将降临小镇  
A Black Santa Claus is coming to town tonight.  
黑色圣诞老人今晚将降临小镇  
A Black Santa Claus is coming to town tonight.  
黑色圣诞老人今晚将降临小镇  
A Black Santa Claus is …  
黑色圣诞老人将…

「悪い子はここかな？」  
「坏孩子在这里吧」

うなされるだけの愛に  
为什么我仍梦想着那  
まだ夢を見ているのはどうして？  
会令人在噩梦中呻吟的爱  
１２時の君を目覚めさせるよ  
我会让12点的你醒来的  
冷たい街角はクリスマス  
寒冷的街角里 是圣诞的气息

いたずら好きの世界を  
能将这爱恶作剧的世界  
正せる祈りなどはないさ  
纠正的祷告是不存在的  
泣き声を掻き消して鐘が鳴る  
将哭声抹去 钟声响起  
まだ淡々聖夜か何かに祈っているの？  
你还在冷静地祈祷着圣夜那种东西吗？

今宵はding-dong ding-dong  
今夜是 ding-dong ding-dong  
明かさず眠る　ハッピークリスマスデイ  
不熬夜而沉睡的 快乐的圣诞日

安易なヴェールだ　Christmas Scene  
马虎的头纱 圣诞节的场景  
Let's party timeさ　OK？  
我们开始派对时间吧 OK？  
チケットと小さなハーブチキン  
入场门票与小小的香草鸡  
グロスブラックな帽子かベルライン  
亮黑色的帽子还是铃铛状

馬鹿なピーポー　デイタイムだって沸いて  
愚蠢的人们因白天的到来而激动着  
「見違えたろ？ハロウィン」  
「你看错了吧？万圣节」  
それじゃ何だかんだで誰かの手の平じゃん  
这样的话任何事物都被某人掌控着不是吗

え？  
咦？

いたずらしようぜ　（大騒ぎしようぜ）  
来恶作剧吧（来大闹一场吧）  
偽物になって　（本物気取って）  
变成冒牌货（装作是本人）  
どこへ行くんだい（どこへ逃げるんだい）  
你打算去哪呢（你打算逃到哪呢）  
遊ぼう？（遊ぼう？）  
来玩吧？（来玩吧？）  
There's no way you can get out of this one.  
你没有办法从这里出去

踊り明かせ　Rave-up tonight  
跳舞至天明吧 今夜狂欢起来吧  
メメント・モリはそいつがRight  
Memento mori（勿忘你终有一死）这句话没有错  
flash on and off 愛に優劣はない  
闪亮 熄灭 爱没有优劣之分  
ここに縛りはない  
这里没有束缚

Drink! Sing! Dance! Shout!  
喝吧！唱吧！跳吧！叫吧！  
昨日の二時から地獄まで  
从昨天2点开始直到地狱  
いいからさっさと唱和しろ！  
别管了 快给我重复一次

Merry Christmas!!  
圣诞快乐！

A Black Santa Claus is coming to town tonight.  
黑色圣诞老人今晚将降临小镇  
A Black Santa Claus is coming to town tonight.  
黑色圣诞老人今晚将降临小镇  
A Black Santa Claus is coming to town tonight.  
黑色圣诞老人今晚将降临小镇  
A Black Santa Claus is …  
黑色圣诞老人将…

「さらってやろうか」  
「我来把你拐走吧」

等しい幸せなんて  
同等的幸福什么的  
切り取ったケーキより曖昧さ  
比切好的那块蛋糕更难解啊  
仮初の指切りで踊ろうよ  
草草拉钩后跳舞吧  
終わらない悪夢はクリスマス  
无止境的噩梦就是圣诞

傷つくだけの世界を  
能纠正这充满伤害的世界的  
正すのは黒いサンタクロースさ  
是那黑色的圣诞老人啊  
泣き声を掻き消して鐘が鳴る  
将哭声抹去 钟声响起  
まだ淡々聖夜か何かに祈っているの？  
你还在冷静地祈祷着圣夜那种东西吗？

こびり付いた愛も不安も  
在脑海中萦绕着的爱也好 不安也好  
その身も　何だって委ねてごらん  
身体也好 不管是什么都交给我吧  
今宵はding-dong ding-dong  
今夜是 ding-dong ding-dong  
明かさず眠る　ハッピークリスマスデイ  
不熬夜而沉睡的 快乐的圣诞日