---
title: 「最終宣告」/まふまふ【罗马音+假名歌词】
tags:
  - 最終宣告
  - 罗马音
  - まふまふ
  - 假名歌词
id: '2640'
date: 2020-03-25 22:42:02
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/03/qr9KP8re.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/03/qr9KP8re.jpg
---

「最終宣告」

<a href="https://www.nicovideo.jp/watch/sm36566206">【MV】最終宣告／まふまふ</a>

作詞作編曲：まふまふ  
映像：まふてる  
絵：ノヤ  
Vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译： [https://unijzlsx.cn/translation/saisyuusennkoku/](https://unijzlsx.cn/translation/saisyuusennkoku/)

i zen tada bou zen  
依然(いぜん) ただ呆然(ぼうぜん)  
「a shi ta ga kimi no sai go no yuu sho ku desu。」  
「明日(あした)が君(きみ)の最後(さいご)の夕食(ゆうしょく)です。」  
se kai wo tsu zu tta suu shi ki de su ra  
世界(せかい)を綴(つづ)った 数式(すうしき)ですら  
kai doku fu nou ga  
解読不能(かいどくふのう)が  
i no chi to i u sou da  
命(いのち)と言(い)う そうだ

so za tsu ni ki nou wo tsu i ya shi ta sono mi  
粗雑(そざつ)に昨日(きのう)を費(つい)やしたその身(み)  
kyou ni i no ru wa ko kkei  
今日(きょう)に祈(いの)るは滑稽(こっけい)  
da min de su te ta  
惰眠(だみん)で捨(す)てた  
byou shin ni sura  
秒針(びょうしん)にすら  
ka ji ri tsu i te su ga ru da rou  
噛(かじ)りついて 縋(すが)るだろう

dou dai？ dou dai？  
どうだい？ どうだい？  
shi ni ta ga ri ba kka ri da  
死(し)にたがりばっかりだ  
suku wa re nu san jyou ni  
救(すく)われぬ惨状(さんじょう)に  
ki ba wo mu ku you na  
牙(きば)を剥(む)くような  
byou jyou ni na ri ma shi ta  
病状(びょうじょう)になりました

sai shuu sen koku da  
最終宣告(さいしゅうせんこく)だ  
o do re ya sho-tai mu  
踊(おど)れや ショータイム(show time)  
u ma re o chi ta yu e ni  
生(う)まれ落(お)ちた 故(ゆえ)に  
wan sai do ge-mu  
ワンサイドゲーム(one sided game)  
san zan da tte  
散々(さんざん)だって  
na ge su te ru i no chi nara  
投(な)げ捨(す)てる命(いのち)なら  
boku ni o ku re  
ボクに おくれ

en mei shi you to  
延命(えんめい)しようと  
yu bi o ri de gu bbai  
指折(ゆびお)りで グッバイ  
sore nara ba koko ra de ta-mi naru ke a  
それならば ここらで ターミナルケア  
no- wan esu ke-pusu saa  
ノーワンエスケープス(No One Escapes) さあ  
sa i go ni i i noko shi ta  
最後(さいご)に言(い)い残(のこ)した  
koto ba wo i e  
言葉(ことば)を言(い)え

ta e ma nai ji sa tsu shi gan to  
絶(た)え間(ま)ない自殺志願(じさつしがん)と  
yume no hi to tsu mo nai you na kou gai  
夢(ゆめ)のひとつもないような郊外(こうがい)  
kon nan ki wa mari nai go shin tai  
困難(こんなん)極(きわ)まりないご神体(しんたい)  
ya rare ppa na shi no mama  
やられっぱなしのまま  
pa ppa ra pa na shi no jin sei  
ぱっぱらぱなしの人生(じんせい)  
son na no chi tto mo u ma ku nee yo  
そんなのちっとも美味(うま)くねえよ  
kimi wa sore de o wa ri de ii no ka？  
君(きみ)はそれで終(お)わりでいいのか？

dou dai？ dou dai？  
どうだい？ どうだい？  
kokoro ni mo nai koto ba  
心(こころ)にもない言葉(ことば)  
—ku da ra na i shou gai  
———くだらない生涯(しょうがい)  
mou ii ya。  
もういいや。

dou shi ta tte wa zu ra tta  
どうしたって患(わずら)った  
ka ri tora reru un mei  
刈(か)り取(と)られる運命(うんめい)  
fu byou dou na kan kaku ga  
不平等(ふびょうどう)な間隔(かんかく)が  
samo kin tou ni a tta  
さも均等(きんとう)にあった  
kyou da tte za ttou ga  
今日(きょう)だって雑踏(ざっとう)が  
ware saki ni to kaku e ki no den sha ni  
我先(われさき)にと各駅(かくえき)の電車(でんしゃ)に  
to bi kon dei ku  
飛(と)び込(こ)んでいく

ma e bu re mo naku ki e ta a i tsu yori  
前触(まえぶ)れもなく消(き)えたアイツより  
i ku bun demo ma shi na mi rai dayo naa？  
幾分(いくぶん)でもマシな未来(みらい)だよなあ？  
maa ka ji kan da se ka i sa  
まあ 悴(かじか)んだ世界(せかい)さ  
sore nara ba  
それならば  
bu za ma ni i ki te mi se ro yo  
無様(ぶざま)に生(い)きてみせろよ

sai shuu sen koku da  
最終宣告(さいしゅうせんこく)だ  
o do re o do re  
踊(おど)れ踊(おど)れ  
u ma re o chi ta yu e ni  
生(う)まれ落(お)ちた 故(ゆえ)に  
wan sai do ge-mu  
ワンサイドゲーム(one sided game)  
san zan da tte  
散々(さんざん)だって  
na ge su teru i no chi nara  
投(な)げ捨(す)てる命(いのち)なら  
boku ni o ku re  
ボクにおくれ

en mei shi you to  
延命(えんめい)しようと  
yu bi o ri de gu bbai  
指折(ゆびお)りで グッバイ  
sore nara ba koko ra de ta-mi naru ke a  
それならば ここらで ターミナルケア  
no-wan esu ke-pusu saa  
ノーワンエスケープス(No One Escapes) さあ  
sa i go ni i i no ko shi ta  
最後(さいご)に言(い)い残(の)した  
koto ba wo i e  
言葉(ことば)を言(い)え

nin gen dare da tte yuku saki wa shuu ten  
人間(にんげん)誰(だれ)だって行先(ゆくさき)は終点(しゅうてん)  
suki ka tte yaru dake ga kai tou  
好(す)き勝手(かって)やるだけが解答(かいとう)  
sei zei ri-pa-ni  
せいぜい リーパーに  
o wa re tsu zu ke te demo  
追(お)われ続(つづ)けてでも  
koto ba wo i e  
言葉(ことば)を言(い)え

sai shuu sen koku da  
最終(さいしゅう) 宣告(せんこく)だ  
kimi wa i i noko shi ta  
君(きみ)は言(い)い残(のこ)した

i ki ru to i e  
生(い)きると言(い)え