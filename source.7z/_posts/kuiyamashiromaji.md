---
title: 「喰病しのイデア」/After the Rain(そらるｘまふまふ)【假名歌词+罗马音】
tags:
  - 喰病しのイデア
  - 罗马音
  - まふまふ
  - そらる
  - After the Rain
  - 假名歌词
id: '2062'
date: 2020-01-26 13:23:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/kuiyamaishi.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/kuiyamaishi.jpg
---

var player = new DogePlayer({ container: document.getElementById('player'), userId: 908, vcode: '7e2b50308cb916bf', autoPlay: false });

「喰病しのイデア」

作詞作編曲：まふまふ  
絵：くっか  
映像 ：お菊  
歌：After the Rain(そらるｘまふまふ)

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

「a nata no sai no u i ta da ki ni ki ma shi ta。」  
「貴方(あなた)の才能(さいのう)いただきに来(き)ました。」  
i zen  
依然(いぜん)  
shi ta saki san zun  
舌先三寸(したさきさんずん)  
go ta ku wa hi to ka do de  
御託(ごたく)は一角(ひとかど)で  
tata ki a ge tte  
叩(たた)き上(あ)げって  
tsu ji tsu ma a wa se tara  
辻褄(つじつま)合(あ)わせたら  
ya me ru i bu ku ro no naka e  
病(や)める胃袋(いぶくろ)の中(なか)へ

mi zu ga ho shii ka  
水(みず)が欲(ほ)しいか  
yu e n wa tai gai  
所以(ゆえん)は大概(たいがい)  
shi o ke ki kase ta yoku bou de  
塩気(しおけ)利(き)かせた欲望(よくぼう)で  
dare ka no na mi da de ni tsu me ta su- pu wa  
誰(だれ)かの涙(なみだ)で煮詰(につ)めたスープは  
nodo wo kawa ka se te i ku  
喉(のど)を乾(かわ)かせていく

ko yo i di na- wa nani ni i ta shi masu ka  
今宵(こよい)ディナーは何(なに)に致(いた)しますか  
o nomi mono wa do nata de tsu ku ri masu ka  
お飲(の)み物(もの)はどなたで作(つく)りますか  
dare ka no yume wo hodo i te ni kon de  
誰(だれ)かの夢(ゆめ)を解(ほど)いて煮込(にこ)んで  
o a ji wa o i shi i kai  
お味(あじ)は 美味(おい)しいかい

nodo moto ni nu i tsu ki ha ki da shi temo  
喉元(のどもと)に縫(ぬ)いつき吐(は)き出(だ)しても  
ke shi te te wo to me ru koto wa de ki nu you ni  
決(け)して 手(て)を止(と)めることはできぬように  
mada mada kimi wa mada tabe tari nai  
まだまだ 君(きみ)はまだ食(た)べ足(た)りない  
tsu mi wo sho ku se sho ku se  
罪(つみ)を食(しょく)せ 食(しょく)せ

dare kare kama wazu mi sa kai wa na i sa  
誰彼構(だれかれかま)わず 見境(みさかい)はないさ  
don yoku na yami wa zu rai ka  
貪欲(どんよく)な病(や)み煩(わずら)いか  
nara wa shi nan da  
習(なら)わしなんだ  
in su tan to mi-mu de fu ta tsu ki en mei  
インスタントミームで2月延命(ふたつきえんめい)  
yo se a tsu me no di suku wa dou dai  
寄(よ)せ集(あつ)めのディスクはどうだい  
a ta ma ka zu a wa se te  
頭数合(あたまかずあ)わせて  
shi ta na me zu ri shi tei ru  
舌(した)なめずりしている

a no ko no shou rai u wa zu mi susu tte  
あの子(こ)の将来(しょうらい) 上澄(うわず)みすすって  
koro a i ni na cha po i suru no？  
頃合(ころあ)いになっちゃポイするの？  
yume wo mi ru hodo ni shin ji ru  
夢(ゆめ)を見(み)るほどに信(しん)じる  
kokoro wa o a tsu ra e mu ki desu ne  
心(こころ)は お誂(あつら)え向(む)きですね

doro dara ke wa dare de nu gu i masu ka？  
泥(どろ)だらけは誰(だれ)で拭(ぬぐ)いますか？  
mata e-yon no kami de shi ba ri masu ka？  
またA4(Aよん)の紙(かみ)で縛(しば)りますか？  
kari to ru kimi wa  
刈(か)り取(と)る 君(きみ)は  
kari to ra re ru me no  
刈(か)り取(と)られる芽(め)の  
kokoro wo ke ri to ba shi te  
心(こころ)を 蹴(け)り飛(と)ばして

go tai sou na i su ni ko shi wo kake ru dake  
御大層(ごたいそう)な椅子(いす)に腰(こし)を掛(か)けるだけ  
yaku sha ki do ri de  
役者(やくしゃ)気取(きど)りで　  
ii ki ni na run jya nee  
いい気(き)になるんじゃねえ  
mada mada kimi wa mada tabe tari nai  
まだまだ 君(きみ)はまだ食(た)べ足(た)りない  
tsu mi wo sho ku se sho ku se  
罪(つみ)を食(しょく)せ 食(しょく)せ

kimi no ko do mo no koro no yume  
君(きみ)の子供(こども)の頃(ころ)の夢(ゆめ)  
boku ni a ma sa zu ki ka se te kure na i kai  
ボクに余(あま)さず聞(き)かせてくれないかい  
u wa su be ri wo shi te  
上滑(うわすべ)りをして  
mu kun da o to na ni  
浮腫(むく)んだ大人(おとな)に  
na ri ta ka tta no ka i  
なりたかったのかい  
dou da rou？  
どうだろう？

ko yo i di na- wa nani ni i ta shi masu ka  
今宵(こよい) ディナーは何(なに)に致(いた)しますか  
o nomi mono wa do nata de tsu ku ri masu ka  
お飲(の)み物(もの)はどなたで作(つく)りますか  
dare ka no yume wo hodo i te ni kon de  
誰(だれ)かの夢(ゆめ)を解(ほど)いて煮込(にこ)んで  
o a ji wa o i shi i kai  
お味(あじ)は美味(おい)しいかい

ha ki da se do ta be ta ri nu ku u fuku wa  
吐(は)き出(だ)せど食(た)べ足(た)りぬ空腹(くうふく)は  
ya ga te kimi ji shin ni sura ki ba wo mu ku  
やがて 君自身(きみじしん)にすら牙(きば)を剥(む)く  
sayo nara o wa ga re no ban san da  
さよなら お別(わが)れの晩餐(ばんさん)だ  
tsu mi wo sho ku se sho ku se  
罪(つみ)を 食(しょく)せ 食(しょく)せ