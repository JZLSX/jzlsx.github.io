---
title: 「馬と鹿」/まふまふ(歌ってみた)｜(Cover：米津玄師)【罗马音+假名歌词】
tags:
  - 馬と鹿
  - 罗马音
  - まふまふ
  - 假名歌词
  - 米津玄師
id: '2750'
date: 2020-04-10 21:20:11
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/maxresdefault-5.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/maxresdefault-5.jpg
---

「馬と鹿 」

作詞作曲：米津玄師  
Arrange：三矢禅晃  
InstMix：yasu  
絵：茶々ごま  
映像：MONO-Devoid  
Vocal/Mix：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

yu ga n de ki zu da ra ke no haru  
歪(ゆが)んで傷(きず)だらけの春(はる)  
ma su i mo u ta zuni a ru i ta  
麻酔(ますい)も打(う)たずに歩(ある)いた  
ka ra da no o ku so ko de hi bi ku  
体(からだ)の奥底(おくそこ)で響(ひび)く  
i ki tari na i to tsu yo ku  
生(い)き足(た)りないと強(つよ)く

mada a ji wa u sa  
まだ味(あじ)わうさ　  
ka mi o e ta gamu no a ji  
噛(か)み終(お)えたガムの味(あじ)  
sa me ki re na i mama no ko ko ro de  
冷(さ)めきれないままの心(こころ)で  
hi to tsu hi to tsu naku shi ta ha te ni  
ひとつひとつなくした果(は)てに  
you ya ku noko tta mono  
ようやく残(のこ)ったもの

ko re ga a i jya na ke re ba  
これが愛(あい)じゃなければ  
nan to yo bu no ka  
なんと呼(よ)ぶのか  
boku wa shi ra na ka tta  
僕(ぼく)は知(し)らなかった  
yo be yo hana no na ma e wo  
呼(よ)べよ 花(はな)の名前(なまえ)を  
tada hi to tsu dake  
ただ一(ひと)つだけ  
ha ri sa ke ru ku ra i ni  
張(は)り裂(さ)けるくらいに  
hana saki ga fu re ru  
鼻先(はなさき)が触(ふ)れる  
ko kyuu ga to ma ru  
呼吸(こきゅう)が止(と)まる  
i ta mi wa ki e na i mama de ii  
痛(いた)みは消(き)えないままでいい

tsu ka re ta sono me de nani wo i u  
疲(つか)れたその目(め)で何(なに)を言(い)う  
ki zu a to ka ku shi te a ru i ta  
傷跡(きずあと)隠(かく)して歩(ある)いた  
so no kuse ka ge wo ba ra ma i ta  
そのくせ影(かげ)をばら撒(ま)いた  
ki zu i te ho shi ka tta  
気(き)づいて欲(ほ)しかった

ma da a ru keru ka  
まだ歩(ある)けるか　  
kami shi me ta su na no a ji  
噛(か)み締(し)めた砂(すな)の味(あじ)  
yo tsu yu de nu re ta shi ba fu no u e  
夜露(よつゆ)で濡(ぬ)れた芝生(しばふ)の上(うえ)  
ha ya ru mu ne ni  
はやる胸(むね)に　  
ta zu ne ru ko to ba  
尋(たず)ねる言葉(ことば)  
o wa ru ni wa mada ha ya i da rou  
終(お)わるにはまだ早(はや)いだろう

dare mo ka na shi ma nu you ni  
誰(だれ)も悲(かな)しまぬように  
hoho e mu koto ga  
微笑(ほほえ)むことが  
u ma ku de ki na ka tta  
上手(うま)くできなかった  
hi to tsu tada hi to tsu de ii  
一(ひと)つ ただ一(ひと)つでいい　  
mamo re ru dake de  
守(まも)れるだけで  
so re de yo ka tta no ni  
それでよかったのに  
a ma ri ni ku da ra nai  
あまりにくだらない　  
ne ga i ga ki e nai  
願(なが)いが消(き)えない  
dare ni mo u ba e na i ta ma shi i  
誰(だれ)にも奪(うば)えない魂(たましい)

nani ni ta to e you  
何(なに)に例(たと)えよう　  
kimi to boku wo  
君(きみ)と僕(ぼく)を　  
kaka to ni no ko ru ni ta ki zu wo  
踵(かかと)に残(のこ)る似(に)た傷(きず)を  
ha re ma wo yu e ba ma da tsu zu ku  
晴(は)れ間(ま)を結(ゆ)えばまだ続(つづ)く　  
yu kou hana mo saka na i u chi ni  
行(ゆ)こう 花(はな)も咲(さ)かないうちに

ko re ga a i jya na ke re ba  
これが愛(あい)じゃなければ  
nan to yo bu no ka  
なんと呼(よ)ぶのか  
boku wa shi ra na ka tta  
僕(ぼく)は知(し)らなかった  
yo be yo o so re ru mama ni  
呼(よ)べよ 恐(おそ)れるままに  
hana no na ma e wo  
花(はな)の名前(なまえ)を  
ki mi jya na kya dame dato  
君(きみ)じゃなきゃ駄目(だめ)だと  
hana saki ga fu re ru  
鼻先(はなさき)が触(ふ)れる　  
ko kyuu ga to ma ru  
呼吸(こきゅう)が止(と)まる  
i ta mi wa ki e na i mama de ii  
痛(いた)みは消(き)えないままでいい

a ma ri ni ku da ra nai  
あまりにくだらない　  
ne ga i ga ki e nai  
願(ねが)いが消(き)えない  
ya ma nai  
止(や)まない