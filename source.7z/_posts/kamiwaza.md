---
title: 「人生逆転の神業」/After the Rain(そらる×まふまふ)【罗马音+假名歌词】
tags:
  - After the Rain
  - そらる
  - まふまふ
  - 罗马音
  - 人生逆転の神業
  - 假名歌词
id: '2452'
date: 2020-02-29 22:07:16
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/IMg0gMCq.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/IMg0gMCq.jpg
---

「人生逆転の神業」

<a href="https://www.nicovideo.jp/watch/sm36438077">【MV】人生逆転の神業／After the Rain【そらる×まふまふ】</a>

作詞作編曲：まふまふ  
Mix/Mastering：そらる  
絵：くっか  
映像：お菊  
唄：After the Rain(そらる×まふまふ)

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译： [https://unijzlsx.cn/translation/jinseigyakutennokamiwaza/](https://unijzlsx.cn/translation/jinseigyakutennokamiwaza/)

hai kizu mi no jin sei  
廃棄(はいき)済(ず)みの人生(じんせい)  
o shi e te chou dai  
教(おし)えて頂戴(ちょうだい)  
to bi kiri no tane wo sa ga shi te mo tto  
とびきりの種(たね)を 探(さが)してもっと  
ba ka no nari shi te sa  
馬鹿(ばか)の形(なり)してさ

jyuu roku tai kyuu kei ha me tsu  
16：9(じゅうろくたいきゅう)系(けい)  
gan bou shuu tai sei  
破滅願望(はめつがんぼう)集大成(しゅうたいせい)  
sei zon hon nou no yuu re tsu  
生存(せいぞん) 本能(ほんおう)の優劣(ゆうれつ)  
kaki mi da shi te  
掻(か)き乱(みだ)して  
a re mo ko re mo  
あれも これも  
ku i bu chi tsu nai de  
食(く)い扶持(ぶち) 繋(つな)いで  
yo so u ri so u de  
予想(よそう) 理想(りそう)で  
fude ha shi ra se ta  
筆走(ふではし)らせた

dou mo ko n ni chi wa desu  
どうもこんにちは です  
sho- mo na i hou ga ai sa re ru mon nano？  
しょーもないほうが 愛(あい)されるものなの？

sei kai no ko to ba jya  
正解(せいかい)の言葉(ことば)じゃ  
tsu ki sasa ra nai  
突(つ)き刺(さ)さらない  
me wo u ba e nai  
目(め)を奪(うば)えない  
so n na sa i no u mo nai noka  
そんな才能(さいのう)もないのか  
dare no fu kou  
誰(だれ)の不幸(ふこう)  
kimi no tsu gou  
君(きみ)の都合(つごう)  
jin se i gya ku ten no kami waza  
人生逆転(じんせいぎゃくてん)の神業(かみわざ)

a re wa dare？ko re wa dare？  
あれは誰(だれ)？これは誰(だれ)？  
chi ma nako de doro susu tte ra  
血眼(ちまなこ)で 泥(どろ)すすってら  
yume ni mi ta a ko gare mo  
夢(ゆめ)に見(み)た 憧(あこが)れも  
ki no u ku da i te  
昨日(きのう)砕(くだ)いて  
shi ri a ru ni shi ten da  
シリアルにしてんだ

hai kizu mi no jin sei  
廃棄(はいき)済(ず)みの人生(じんせい)  
o shi e te chou dai  
教(おし)えて頂戴(ちょうだい)  
hi mo na i gai kou ni  
火(ひ)もない外光(がいこう)に  
ga so rin ma i te  
ガソリン撒(ま)いて  
o nawa ga ni a i da rou  
お縄(なわ)が似合(にあ)いだろう

ho ko ri chi ri hito tsu naku tomo tata i te  
埃(ほこり) 塵(ちり) ひとつなくとも叩(たた)いて  
ri ron wa hou kai jyou tou  
理論(りろん)は崩壊上等(ほうかいじょうとう)  
shi ri me tsu re tsu  
支離滅裂(しりめつれつ)  
o do ri o do re  
踊(おど)り踊(おど)れ  
ku i bu chi tsu na i de  
食(く)い扶持(ぶち) 繋(つな)いで  
tsu gi wa dare wo hyo u teki ni suru no？  
次(つぎ)は誰(だれ)を標的(ひょうてき)にするの？

・ka gaku sha ni na tte  
・科学者(かがくしゃ)になって  
dare ka no i no chi wo suku e tara ii na  
誰(だれ)かの命(いのち)を救(すく)えたらいいな  
・myu-ji shan ni na tte  
・ミュージシャンになって  
hito no koko ro ni yori so e tara ii na  
人(ひと)の心(こころ)に寄(よ)り添(そ)えたらいいな

「son na mon ga nan no yaku ni ta tsu？」  
「そんなもんが 何(なん)の役(やく)に立(た)つ？」  
「o mo i a ga tte tori hada ga ta tsu」  
「思(おも)いあがって 鳥肌(とりはだ)が立(た)つ」  
aa sou ka yume mo mi re na kya  
あぁそうか 夢(ゆめ)も見(み)れなきゃ  
wa kara na i da rou naa  
わからないだろうなあ

dou mo ko n ni chi wa desu  
どうもこんにちは です  
furu e ru yubi de sha tta- ki reru no ka？  
震(ふる)える指(ゆび)で シャッターきれるのか？

sai tei na koto ba de  
最低(さいてい)な言葉(ことば)で  
sai tei na koko ro no  
最低(さいてい)な心(こころ)の  
sai tei hen na kimi ga  
最底辺(さいていへん)な君(きみ)が  
na mi da mo de cchi a ge teru noka  
涙(なみだ)もでっち上(あ)げてるのか  
sore wa naze？kimi wa dare？  
それは何故(なぜ)？君(きみ)は誰(だれ)？  
maru de kami、hoto ke no mi waza  
まるで 神(かみ)、仏(ほとけ)の御業(みわざ)

o ka shi i na o ka shi i na  
おかしいな おかしいな  
nani mo ga ne ji ma ge rare tera  
何(なに)もが 捻(ね)じ曲(ま)げられてら  
fu tsu gou na suji gaki wa  
不都合(ふつごう)な筋書(すじが)きは  
hi da ri kuri kku de sayo nara bai ba i  
左(ひだり)クリックで さよなら バイバイ  
bai ba-i-  
バイバーイー

te wo tata ke te wo tata ke  
手(て)を叩(たた)け 手(て)を叩(たた)け  
sa e teru boku wo tata e te yo tte  
冴(さ)えてるボクを称(たた)えてよって

ko domo no koro no yume nan te  
子供(こども)の頃(ころ)の夢(ゆめ)なんて  
shi n demo shou ga i  
死(し)んでも生涯(しょうがい)  
ku chi ni dasu na yo  
口(くち)に出(だ)すなよ