---
title: 「動かざること山の如し」/まふまふ【罗马音+假名歌词】一「神楽色アーティファクト」
tags:
  - 動かざること山の如し
  - 罗马音
  - まふまふ
  - 假名歌词
  - 神楽色アーティファクト
id: '732'
date: 2019-10-16 19:58:23
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/d60d31d0d23de4cbc956650002233c7b1875fe3e.jpg@360w_360h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/d60d31d0d23de4cbc956650002233c7b1875fe3e.jpg@360w_360h.jpg
---

「動かざること山の如し」

一「神楽色アーティファクト」アルバム収録曲  
編曲：まふまふ  
作詞・作曲：まふまふ  
vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

yo me nu kuu ki wa yo ma nu mama  
読(よ)めぬ空気(くうき)は読(よ)まぬまま  
bu tai ni a ga ru karu ha zu mi  
舞台(ぶたい)にあがる軽(かる)はずみ  
i ku man wo ko e te re tsu wo na shi  
幾万(いくまん)を超(こ)えて列(れつ)を成(な)し  
nara bu nara bu  
並(なら)ぶ　並(なら)ぶ

no ppi ki nara na i sen kyou ni  
のっぴきならない戦況(せんきょう)に  
ni ge go shi wa moto no mo ku a mi  
逃(に)げ腰(ごし)は元(もと)の木阿弥(もくあみ)  
sa re do kokoro no hi ki komo ri  
然(さ)れど心(こころ)のひきこもり  
o wa ri  
終(お)わり＼(＾o＾)／  
o wa ri wa se tsu na  
終(お)わりは刹那(せつな)

tada i tsu ka mi ta yume wo  
ただいつか見(み)た夢(ゆめ)を　  
sono yume wo ka na e ru tame ni  
その夢(ゆめ)を叶(かな)えるために  
kan chi ga i a wa re  
勘違(かんちが)い哀(あわ)れ  
kara ya bu ru ke tte i da  
殻破(からやぶ)る決定打(けっていだ)

ya da ya da  
やだ やだ　  
son na no kan kei nai  
そんなの関係(かんけい)ない  
kokoro ni ki za mi kon da  
心(こころ)に刻(きざ)み込(こ)んだ  
a i ko to ba  
合言葉(あいことば)  
ha na ka ra iu nara hai sen da  
はなから言(い)うなら敗戦(はいせん)だ  
mi e ha tte wa tsu yo ga re do  
見栄(みえ)はっては強(つよ)がれど  
shi men so ka  
四面楚歌(しめんそか)

de mo de mo  
でも でも　  
yan na kya nan nai nai  
やんなきゃなんないない  
ka ta ma tte wa u ra ka e tte  
固(かた)まっては裏返(うらかえ)って  
kono shi u chi  
この仕打(しう)ち  
ya da ya da  
やだ やだ　  
son na no kan kei nai  
そんなの関係(かんけい)ない  
u go ka zaru koto yama no go to shi  
動(うご)かざること山(やま)の如(ごと)し

a ke ga ta ni ne te yo ru o ki te  
明(あ)け方(がた)に寝(ね)て 夜起(よるお)きて  
ku chi mo a ke zu ni a su wo mate  
口(くち)も開(あ)けずに明日(あす)を待(ま)て  
ta e te shi no bu ga zen han sei  
耐(た)えて忍(しの)ぶが前半生(ぜんはんせい)  
hi to ri hi to ri  
独(ひと)り　独(ひと)り

kokoro hi to tsu wo ka wa su dake  
ココロひとつを交(か)わすだけ  
son na no mo deki zu ni jyuu suu nen  
そんなのも出来(でき)ずに十数年(じゅうすうねん)  
ni ge te ka ku re te ten te ko ma i  
逃(に)げて隠(かく)れて天手古舞(てんてこまい)  
o wa ri  
終(お)わり＼(＾o＾)／  
o wa ri wa se tsu na  
終(お)わりは刹那(せつな)

nee i tsu ka mi ta yume no  
ねえいつか見(み)た夢(ゆめ)の　  
sono tsu zu ki wo a ru ku ha zu ga  
その続(つづ)きを歩(ある)くはずが  
su gu o re ru kokoro  
すぐ折(お)れるココロ　  
kata ya bu ri sai tei hen  
型破(かたやぶ)り最底辺(さいていへん)

ya da ya da  
やだ やだ　  
son na no kan kei nai  
そんなの関係(かんけい)ない  
mi no ta ke ni a wa na ka tta  
身(み)の丈(たけ)に合(あ)わなかった  
no ki dyou chin  
軒提灯(のきぢょうちん)  
dou shi te dou shi te  
どうして どうして　  
kono na mi ga tte ga  
こんな身勝手(みがって)が  
yuru sare ru a ge ku ni haku shu no a me  
許(ゆる)される挙句(あげく)に拍手(はくしゅ)の雨(あめ)

hi i te hi i te  
引(ひ)いて 引(ひ)いて　  
hi i te wa hi i te  
引(ひ)いては引(ひ)いて  
hi ku ba kka de o shi wa shi nai ga  
引(ひ)くばっかで押(お)しはしないが  
za yuu no mei  
座右(ざゆう)の銘(めい)  
ya da ya da  
やだ やだ　  
son na no kan kei nai  
そんなの関係(かんけい)ない  
u go ka zaru koto yama no go to shi  
動(うご)かざること山(やま)の如(ごと)し

nu ki a shi sa shi a shi  
抜(ぬ)き足(あし)　差(さ)し足(あし)  
a-  
あー　  
kon na shi a wa se nya mou bai bai  
こんな幸(しあわ)せにゃもうバイバイ  
ki tai ki tai  
期待(きたい)　期待(きたい)　  
shi nai de chou dai  
しないで頂戴(ちょうだい)  
son na no tou ni wa ka tte n da  
そんなの疾(と)うにわかってんだ

a re ko re a re ko re  
あれこれ　あれこれ  
mou i ya ni naru koto ba mo mou man tai  
もう嫌(いや)になる言葉(ことば)も無問題(もうまんたい)  
ki tai ki tai  
期待(きたい)　期待(きたい)　  
shi nai de chou dai  
しないで頂戴(ちょうだい)  
i sshou ka ra ni komo tte i tai  
一生(いっしょう)殻(から)にこもっていたい

ya da ya da  
やだ やだ　  
son na no kan kei nai  
そんなの関係(かんけい)ない  
kokoro ni ki za mi kon da  
心(こころ)に刻(きざ)み込(こ)んだ  
a i ko to ba  
合言葉(あいことば)  
ha na ka ra iu nara hai sen da  
はなから言(い)うなら敗戦(はいせん)だ  
mi e ha tte wa tsu yo ga re do  
見栄(みえ)はっては強(つよ)がれど  
shi men so ka  
四面楚歌(しめんそか)

de mo de mo  
でも でも　  
yan na kya nan nai nai  
やんなきゃなんないない  
kata ma tte wa u ra ka e tte  
固(かた)まっては裏返(うらかえ)って  
kono shi u chi  
この仕打(しう)ち  
ya da ya da  
やだ やだ　  
son nano kan kei nai  
そんなの関係(かんけい)ない  
u go ka zaru koto yama no go to shi  
動(うご)かざること山(やま)の如(ごと)し