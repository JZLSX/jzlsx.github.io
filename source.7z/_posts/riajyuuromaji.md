---
title: 「リア充になりたい」/まふまふ【罗马音+假名歌词】
tags:
  - リア充になりたい
  - 罗马音
  - まふまふ
  - 假名歌词
id: '2702'
date: 2020-04-05 20:31:35
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/maxresdefault-2.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/maxresdefault-2.jpg
---

「リア充になりたい」

作詞作編曲：まふまふ  
Vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译： [https://unijzlsx.cn/translation/riacyuuninaritai/](https://unijzlsx.cn/translation/riacyuuninaritai/)

me-ku a ppu ri a jyuu  
メークアップ・リア充(じゅう)  
ko i ni ko i se yo  
恋(こい)に恋(こい)せよ  
tsu- suto rai ku kara hon ban！  
ツーストライクから本番(ほんばん)！

na mo na i kan jyou ga na mo na i  
名(な)も無(な)い感情(かんじょう)が名(な)も無(な)い  
mama de o wa ru tte yoku a ru koto  
ままで終(お)わるってよくあること  
sore tte dai tai boku no koto？  
それって大体(だいたい)ボクのこと？  
fu mi ko me nai mou i ppo no kazu  
踏(ふ)み込(こ)めないもう一歩(いっぽ)の数(かず)  
ka zo e tara chi kyuu nan shuu da tte  
数(かぞ)えたら地球(ちきゅう)何周(なんしゅう)だって  
ma wa re sou na ku rai  
回(まわ)れそうなくらい  
yo wa ki na boku da  
弱気(よわき)なボクだ  
kimi ga too za ka tte i ku  
君(きみ)が遠(とお)ざかっていく

aa i ba sho mo na i yo ru niwa na re ta ke do  
ああ 居場所(いばしょ)もない夜(よる)には慣(な)れたけど  
dare mo ga byou dou ni  
誰(だれ)もが平等(びょうどう)に  
ko i ni ko i wo shi te i i  
恋(こい)に恋(こい)をしていい  
ha zu de su yo ne  
はずですよね

i tsu mo ko i bi to mi man de to mo da chi no shi ta  
いつも恋人未満(こいびとみまん)で友達(ともだち)の下(した)  
ki tto 「ki ni naru a i tsu 」no ma wa ri no hi to e-  
きっと「気(き)になるアイツ」の周(まわ)りの人(ひと)A  
kimi wo fu ri mu ka se ru you na  
君(きみ)を振(ふ)り向(む)かせるような  
ma ho u no hi to tsu mo na i kere do  
魔法(まほう)のひとつもないけれど  
hiki tate yaku no mama o wa re nai no desu  
引(ひ)き立(た)て役(やく)のまま終(お)われないのです

me-ku a ppu ri a jyuu  
メークアップ・リア充(じゅう)  
ko i ni ko i se yo  
恋(こい)に恋(こい)せよ  
tsu- au to kara ban kai！  
ツーアウトから挽回(ばんかい)！

o mo e ba tan jyun na ki mo chi wa  
思(おも)えば単純(たんじゅん)な気持(きも)ちは  
tan jyun na ho do ii zu ra ku te  
単純(たんじゅん)なほど言(い)いづらくて  
sore tte ki tto ka ra ma wa ri？  
それってきっと空回(からまわ)り？  
ji bun i gai ni na re ta nara  
自分以外(じぶんいがい)になれたなら  
kimi wa boku wo a i shi te kure ta no ka nan tesa  
君(きみ)はボクを愛(あい)してくれたのかなんてさ  
yo wa ne no me ro di ka i te  
弱音(よわね)のメロディ書(か)いて  
kyou mo u ta tte i ru  
今日(きょう)も歌(うた)っている

aa kyou ka sho ni nai ko ta e wo sa ga su yo ri  
ああ 教科書(きょうかしょ)にない答(こた)えを探(さが)すより  
u go ke kan tan na 「o ha you」  
動(うご)け 簡単(かんたん)な「おはよう」  
hi to tsu de i i kara  
ひとつでいいから

u ma ra na i san jyuu sen chi no  
埋(う)まらない30(さんじゅう)センチの  
yuu ki wo ku da sai  
勇気(ゆうき)をください  
a su wo ka ki na o seru you na  
明日(あす)を書(か)き直(なお)せるような  
ko to ba wo ku da sai  
言葉(ことば)をください  
i tsu mo yoko gi ru dake de o shi ma i no  
いつも横切(よこぎ)るだけでおしまいの  
kimi no shi sen sura mo  
君(きみ)の視線(しせん)すらも  
to ri ko ni suru ma hou wo kake te kuda sai  
虜(とりこ)にする 魔法(まほう)をかけてください

hai sen su na ko-di ni pa fyu-mu  
ハイセンスなコーデにパフューム  
su ko shi se no bi shi ta tte ii  
少(すこ)し背伸(せの)びしたっていい  
on to ren do de ni wa ri ma shi  
オン トレンドで2割増(にわりま)し  
yo sou gai ku rai ga chou do ii  
予想外(よそうがい)くらいがちょうどいい

to do ke kimi ni to do ke  
届(とど)け 君(きみ)に届(とど)け  
ha ya ru ki mo chi  
はやる気持(きも)ち  
tsu ta wa re kono o mo i hi to tsu bu  
伝(つた)われこの想(おも)い一粒(ひとつぶ)  
ki mi ni dake  
君(きみ)にだけ

ko i bi to mi man de to mo da chi no shi ta  
恋人未満(こいびとみまん)で友達(ともだち)の下(した)  
ki tto 「ki ni naru a i tsu 」no ma wa ri no hi to e-  
きっと「気(き)になるアイツ」の周(まわ)りの人(ひと)A  
kimi wo fu ri mu ka se ru you na  
君(きみ)を振(ふ)り向(む)かせるような  
ma ho u no hi to tsu mo na i kere do  
魔法(まほう)のひとつもないけれど  
hiki tate yaku no mama o wa re nai no desu  
引(ひ)き立(た)て役(やく)のまま終(お)われないのです

me-ku a ppu ri a jyuu  
メークアップ・リア充(じゅう)  
ko i ni ko i se yo  
恋(こい)に恋(こい)せよ  
tsu- suto rai ku kara hon ban！  
ツーストライクから本番(ほんばん)！