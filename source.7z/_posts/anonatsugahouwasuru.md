---
title: 「あの夏が飽和する。」ーカンザキイオリ/まふまふ (歌ってみた)|假名歌词 +罗马音
tags:
  - あの夏が飽和する。
  - 假名歌词
  - カンザキイオリ
  - まふまふ
  - 罗马音
id: '2139'
date: 2020-02-02 21:56:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/maxresdefault.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/maxresdefault.jpg
---

「あの夏が飽和する。」

作詞：カンザキイオリ  
作曲：カンザキイオリ  
歌/Mix：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

「ki nou hito wo koro shi tan da」  
「昨日(きのう)人(ひと)を殺(ころ)したんだ」  
kimi wa sou i tte i ta  
君(きみ)はそう言(い)っていた。  
tsu yu doki zubu nu re no man ma  
梅雨時(つゆどき)ずぶ濡(ぬ)れのまんま、  
he ya no ma e de na i te i ta  
部屋(へや)の前(まえ)で泣(な)いていた。  
na tsu ga ha ji ma tta ba ka ri to i u no ni  
夏(なつ)が始(はじ)まったばかりというのに、  
kimi wa hi do ku furu e te i ta  
君(きみ)はひどく震(ふる)えていた。  
son na ha na shi de ha ji maru  
そんな話(はなし)で始(はじ)まる、  
a no na tsu no hi no ki o ku da  
あの夏(なつ)の日(ひ)の記憶(きおく)だ。

「ko ro shi ta no wa to na ri no se ki no  
「殺(ころ)したのは隣(となり)の席(せき)の、  
i tsu mo i ji me te ku ru a i tsu  
いつも虐(いじ)めてくるアイツ。  
mou i ya ni na tte kata wo tsu ki toba shi te  
もう嫌(いや)になって、肩(かた)を突(つ)き飛(と)ばして、  
u chi do koro ga wa ru ka ttan da  
打(う)ち所(どころ)が悪(わる)かったんだ。  
mo u koko ni wa i ra re nai to o mou shi  
もうここには居(い)られないと思(おも)うし、  
do kka too i toko de shin de kuru yo」  
どっか遠(とお)いとこで死(し)んでくるよ」  
son na kimi ni boku wa i tta  
そんな君(きみ)に僕(ぼく)は言(い)った。

「so re jya boku mo tsu re te tte」  
「それじゃ僕(ぼく)も連(つ)れてって」

sa i fu wo mo tte na i fu wo mo tte  
財布(さいふ)を持(も)って、ナイフを持(も)って、  
kei ta i ge-mu mo ka ban ni tsu me te  
携帯(けいたい)ゲームもカバンに詰(つ)めて、  
i ra na i mo no wa zen bu ko wa shi te i kou  
いらないものは全部(ぜんぶ)壊(こわ)していこう。  
a no sha shin mo a no ni kki mo  
あの写真(しゃしん)も、あの日記(にっき)も、  
i ma to na ccha mou i ra nai sa  
今(いま)となっちゃもういらないさ。  
hi to go ro shi to dame nin gen no  
人殺(ひとごろ)しとダメ人間(にんげん)の  
kimi to boku no tabi da  
君(きみ)と僕(ぼく)の旅(たび)だ。

so shi te boku ra wa ni ge da shi ta  
そして僕(ぼく)らは逃(に)げ出(だ)した。  
kono se ma i se ma i kono se kai kara  
この狭(せま)い狭(せま)いこの世界(せかい)から。  
ka zoku mo ku ra su no ya tsu ra mo  
家族(かぞく)もクラスの奴(やつ)らも  
nani mo kamo zen bu su tete kimi to fu tari de  
何(なに)もかも全部(ぜんぶ)捨(す)てて  
君(きみ)と二人(ふたり)で。  
too i too i dare mo i nai ba sho de fu tari de shi nou yo  
遠(とお)い遠(とお)い誰(だれ)もいない場所(ばしょ)で二人(ふたり)で死(し)のうよ。  
mou kono se ka i ni ka chi na do nai yo  
もうこの世界(せかい)に価値(かち)などないよ。  
ho to go ro shi nan te soko ra jyuu wa i te ru jyan ka  
人殺(ひとごろ)しなんてそこら中(じゅう)湧(わ)いてるじゃんか。  
kimi wa nani mo waru ku na i yo  
君(きみ)は何(なに)も悪(わる)くないよ。  
kimi wa nani mo waru ku na i yo  
君(きみ)は何(なに)も悪(わる)くないよ。

ke kkyo ku boku ra dare ni mo a i sare ta koto nado na ka ttan da  
結局(けっきょく)僕(ぼく)ら誰(だれ)にも愛(あい)されたことなどなかったんだ。  
son na i ya na kyou tsu u ten de  
そんな嫌(いや)な共通点(きょうつうてん)で  
boku ra wa kan tan ni shin ji a tte ki ta  
僕(ぼく)らは簡単(かんたん)に信(しん)じあってきた。  
kimi no te wo nigi tta toki kasu kana fu ru e mo sude ni naku na tte i te  
君(きみ)の手(て)を握(にぎ)った時(とき)、微(かす)かな震(ふる)えも既(すで)に無(な)くなっていて  
dare ni mo shi ba rare nai de fu tari sen ro no u e wo a ru i ta  
誰(だれ)にも縛(しば)られないで二人(ふたり)線路(せんろ)の上(うえ)を歩(ある)いた。

kane wo nu sun de fu tari de ni ge te  
金(かね)を盗(ぬす)んで、二人(ふたり)で逃(に)げて、  
doko ni mo i ke ru ki ga shi tan da  
どこにも行(い)ける気(き)がしたんだ。  
i ma sara ko wa i mono wa boku ra ni wa na ka ttan da  
今更(いまさら)怖(こわ)いものは僕(ぼく)らにはなかったんだ。  
hi tai no a se mo o chi ta me ga ne mo  
額(ひたい)の汗(あせ)も、落(お)ちたメガネも  
「i ma to na ccha dou demo ii sa  
「今(いま)となっちゃどうでもいいさ。  
a bu re mono no chii sa na to u hi ko u no tabi da」  
　あぶれ者(もの)の小(ちい)さな逃避行(とうひこう)の旅(たび)だ」

i tsu ka yume mi ta ya sa shi ku te  
いつか夢見(ゆめみ)た優(やさ)しくて、  
dare ni mo su ka re ru shu jin kou nara  
誰(だれ)にも好(す)かれる主人公(しゅじんこう)なら、  
ki ta naku na tta boku ta chi mo mi su te zu ni  
汚(きたな)くなった僕(ぼく)たちも見捨(みす)てずに  
chan to suku tte ku reru no kana  
ちゃんと救(すく)ってくれるのかな？  
「son na yume nara su te ta yo  
「そんな夢(ゆめ)なら捨(す)てたよ、  
da tte gen ji tsu wo mi ro yo  
だって現実(げんじつ)を見(み)ろよ。  
shi a wa se no yon moji nan te na ka tta  
シアワセの四文字(よんもじ)なんてなかった、  
i ma made no jin se i de o mo i shi tta jya nai ka  
今(いま)までの人生(じんせい)で思(おも)い知(し)ったじゃないか。  
ji bun wa nani mo waru ku nee to  
自分(じぶん)は何(なに)も悪(わる)くねえと  
dare mo ga ki tto o mo tte ru」  
誰(だれ)もがきっと思(おも)ってる」

a te mo naku sa ma you se mi no mure ni  
あてもなく彷徨(さまよ)う蝉(せみ)の群(む)れに、  
mizu mo naku nari yure dasu shi ka i ni  
水(みず)も無(な)くなり揺(ゆ)れ出(だ)す視界(しかい)に、  
se mari ku ru u o ni ta chi no do go u ni  
迫(せま)り狂(くる)う鬼(おに)たちの怒号(どごう)に、  
baka mi tai ni ha sha gi ai  
バカみたいにはしゃぎあい  
futo kimi wa na i fu wo to tta  
ふと君(きみ)はナイフを取(と)った。  
「kimi ga i ma made soba ni i ta kara koko made kore tan da  
「君(きみ)が今(いま)まで傍(そば)にいたからここまでこれたんだ。  
da kara mou ii yo mou ii yo」  
だからもういいよ。もういいよ」

「shi nu no wa wa ta shi hi to ri de ii yo」  
「死(し)ぬのは私(わたし)一人(ひとり)でいいよ」

so shi te kimi wa kubi wo ki tta  
そして君(きみ)は首(くび)を切(き)った。  
ma ru de nan ka no e i ga no wan shi-n da  
まるで何(なん)かの映画(えいが)のワンシーンだ。  
ha ku chuu mu wo mi te i ru ki ga shi ta  
白昼夢(はくちゅうむ)を見(み)ている気(き)がした。  
ki zu ke ba boku wa tsu ka ma tte  
気(き)づけば僕(ぼく)は捕(つか)まって。  
kimi ga doko ni mo mi tsu kara na ku tte  
君(きみ)がどこにも見(み)つからなくって。  
kimi dake ga doko ni mo i na ku tte  
君(きみ)だけがどこにもいなくって。

so shi te toki wa su gi te i tta  
そして時(とき)は過(す)ぎていった。  
tada a tsu i a tsu i hi ga su gi te tta  
ただ暑(あつ)い暑(あつ)い日(ひ)が過(す)ぎてった。  
ka zoku mo ku rasu no ya tsu ra mo i ru no ni  
家族(かぞく)もクラスの奴(やつ)らもいるのに  
naze ka kimi dake wa doko ni mo i nai  
なぜか君(きみ)だけはどこにもいない。

a no na tsu no hi wo o mo i da su  
あの夏(なつ)の日(ひ)を思(おも)い出(だ)す。  
boku wa i ma mo i ma demo u ta tte ru  
僕(ぼく)は今(いま)も今(いま)でも歌(うた)ってる。  
kimi wo zu tto sa ga shi te i run da  
君(きみ)をずっと探(さが)しているんだ。  
kimi ni ii tai koto ga a run da  
君(きみ)に言(い)いたいことがあるんだ。

ku ga tsu no o wa ri ni ku sha mi shi te  
九月(くがつ)の終(お)わりにくしゃみして  
ro ku ga tsu no ni o i wo ku ri ka e su  
六月(ろくがつ)の匂(にお)いを繰(く)り返(かえ)す。  
kimi no e ga o wa  
君(きみ)の笑顔(えがお)は  
kimi no mu jya ki sa wa  
君(きみ)の無邪気(むじゃき)さは  
a ta ma no naka wo hou wa shi te i ru  
頭(あたま)の中(なか)を飽和(ほうわ)している。

dare mo nani mo waru ku nai yo  
誰(だれ)も何(なに)も悪(わる)くないよ。  
kimi wa nani mo waru ku wa nai kara  
君(きみ)は何(なに)も悪(わる)くはないから  
mou ii yo  
もういいよ。  
na ge da shi te shi ma o u  
投(な)げ出(だ)してしまおう。

sou i tte ho shi ka tta no da rou ？naa？  
そう言(い)って欲(ほ)しかったのだろう？ なあ？