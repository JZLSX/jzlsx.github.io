---
title: 「だれかの心臓になれたなら」/まふまふ (歌ってみた)【罗马音+假名歌词】
tags:
  - だれかの心臓になれたなら
  - 罗马音
  - まふまふ
  - 假名歌词
id: '1457'
date: 2020-01-14 15:10:10
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/01/QQ%E6%88%AA%E5%9B%BE20200113170933.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/01/QQ%E6%88%AA%E5%9B%BE20200113170933.jpg
---

「だれかの心臓になれたなら」

作詞：ユリイ・カノン  
作曲：ユリイ・カノン  
Vocal/Mix：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

「kon na se ka i 」to na ge ku dare ka no  
「こんな世界(せかい)」と嘆(なげ)くだれかの  
i ki ru ri yuu ni na re ru de shou ka  
生(い)きる理由(りゆう)になれるでしょうか  
kore wa boku ga i ma kimi ni o ku ru  
これは僕(ぼく)が いま君(きみ)に贈(おく)る  
sai sho de sai go no a i no kotoba da  
最初(さいしょ)で最期(さいご)の愛(あい)の言葉(ことば)だ

ma chi mo hito mo yu ga mi da shi ta  
街(まち)も人(ひと)も歪(ゆが)み出(だ)した　  
ba ke mono da to ki zu i tan da  
化(ば)け物(もの)だと気付(きづ)いたんだ  
yoku dou ni su ku tta o ro ka sa mo  
欲動(よくどう)に巣食(すく)った愚(おろ)かさも　  
su be te ga kono me ni u tsu ru  
全(すべ)てがこの目(め)に映(うつ)る

shi a tori karu ni te no u e de  
シアトリカルに手(て)の上(うえ)で  
dare mo kare mo o do ra sa re ru  
誰(だれ)も彼(かれ)も踊(おど)らされる  
u ma re ta i mi da tte shi ra nu mama  
生(う)まれた意味(いみ)だって知(し)らぬまま  
kei gai ka shi ta yume wa sabi tsu i te shi ma tta  
形骸化(けいがいか)した夢(ゆめ)は錆(さ)びついてしまった

「ai wo ku da sai」  
「愛(あい)をください」  
ki tto dare mo ga sou nega tta  
きっとだれもがそう願(ねが)った  
「ai wo ku da sai」  
「愛(あい)をください」  
so tto fu ru e ta te wo to tte  
そっと震(ふる)えた手(て)を取(と)って  
「ai wo ku da sai」  
「愛(あい)をください」  
ko ko ro wo e gu ru  
心(こころ)を抉(えぐ)る　  
mi ni ku i ku rai ni u tsu ku shii a i wo  
醜(みにく)いくらいに美(うつく)しい愛(あい)を

「kon na se ka i」to na ge ku dare ka no  
「こんな世界(せかい)」と嘆(なげ)くだれかの  
i ki ru ri yuu ni na re ru de shou ka  
生(い)きる理由(りゆう)になれるでしょうか  
i tsu ka o wa ru to ki zu i ta hi kara  
いつか終(お)わると気付(きづ)いた日(ひ)から  
shi e to byou wo yo mu shin zou da  
死(し)へと秒(びょう)を読(よ)む心臓(しんぞう)だ

nee kono mama a me ni o bo re te  
ねえ　このまま雨(あめ)に溺(おぼ)れて  
a i ni to ke ta tte ka ma wa na i kara  
藍(あい)に融(と)けたって構(かま)わないから  
dou ka dou ka  
どうか　どうか　  
mata a no hi no you ni  
またあの日(ひ)のように  
kasa wo sa shi da shi wara tte mi se te yo  
傘(かさ)を差(さ)し出(だ)し笑(わら)ってみせてよ

mo shi mo yume ga sa me na ke re ba  
もしも夢(ゆめ)が覚(さ)めなければ  
su ga ta wo ka e zu ni i ra re ta ？  
姿(すがた)を変(か)えずにいられた？  
ho do ke ta yubi kara ki e ru on do  
解(ほど)けた指(ゆび)から消(き)える温度(おんど)  
chi wo me gu ra se ru no wa dare no o mo i de？  
血(ち)を廻(めぐ)らせるのはだれの思(おも)い出(で)？

a me ni nu re ta hai sen  
雨(あめ)に濡(ぬ)れた廃線(はいせん)  
susu ke ta byou tou  
煤(すす)けた病棟(びょうとう)　  
na ran da sou den tou  
並(なら)んだ送電塔(そうでんとう)  
yuu gure no basu tei  
夕暮(ゆうぐ)れのバス停(てい)  
toma tta mama no kan ran sha  
止(と)まったままの観覧車(かんらんしゃ)  
tsu ku e ni saku hana  
机(つくえ)に咲(さ)く花(はな)  
kimi no ko e mo  
君(きみ)の声(こえ)も  
nani mo kamo  
何(なに)もかも  
a- sai sho kara na ka tta mi ta i  
(ah)最初(さいしょ)から無(な)かったみたい

shi ni tai boku wa kyou mo i ki wo shi te  
死(し)にたい僕(ぼく)は今日(きょう)も息(いき)をして  
i ki tai kimi wa a su wo mi u shi na tte  
生(い)きたい君(きみ)は明日(あす)を見失(みうしな)って  
na no ni dou shi te ka na shii no da rou  
なのに　どうして悲(かな)しいのだろう  
i zu re shi suru no ga nin gen da  
いずれ死(し)するのが人間(にんげん)だ

a- e i en nan te na i ke do  
(ah)永遠(えいえん)なんてないけど  
o mo i too ri no hibi jya na i ke do  
思(お)い通(とお)りの日々(ひび)じゃないけど  
mo ro ku yo wa i i to ni tsu na ga re ta  
脆(もろ)く弱(よわ)い糸(いと)に繋(つな)がれた  
tsu gi no yo a ke ga ma ta o to zu re ru  
次(つぎ)の夜明(よあ)けがまた訪(おとず)れる

don na se ka i mo kimi ga i ru nara  
どんな世界(せかい)も君(きみ)がいるなら  
i ki te i ta i tte o mo e tan da yo  
生(い)きていたいって思(おも)えたんだよ  
boku no ji go ku de kimi wa i tsu demo  
僕(ぼく)の地獄(じごく)で君(きみ)はいつでも  
ta e zu ko do u suru shin zou da  
絶(た)えず鼓動(こどう)する心臓(しんぞう)だ

a- i tsu shi ka kimi ga kure ta you ni  
(ah)いつしか君(きみ)がくれたように  
boku mo  
僕(ぼく)も、  
dare ka no shin zou ni nare ta na ra  
だれかの心臓(しんぞう)になれたなら