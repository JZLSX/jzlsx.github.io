---
title: 「猫猫的宇宙論」/まふまふ 歌ってみた【罗马音+假名歌词】
tags:
  - 猫猫的宇宙論
  - 罗马音
  - まふまふ
  - 假名歌词
  - ナユタン星人
id: '2413'
date: 2020-02-26 20:49:00
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/3a2759495bbdcb1dc427769c5c1fbe2c14050ec4.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/02/3a2759495bbdcb1dc427769c5c1fbe2c14050ec4.jpg
---

「猫猫的宇宙論」

作詞作編曲：ナユタン星人  
Vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

nyan nyan teki u chuu ron  
猫猫的宇宙論(にゃんにゃんてきうちゅうろん)　  
nan mo shi ra na i man ma  
なんも知(し)らないまんま  
ai ra bu yu- wo tona e ru  
アイラブユー(I love you)を唱(とな)える　  
tou to i kan ga ma yaku teki  
尊(とうと)い感(かん)が麻薬的(まやくてき)  
chuu chuu ni mu chuu de  
宙宙(ちゅうちゅう)に夢中(むちゅう)で　  
zen to kou wa ki kai teki  
前(ぜん)と後(こう)は機械的(きかいてき)  
a- i ya i ya  
あー嫌嫌(いやいや)　  
son na ai wa i ra nai nyan~  
そんな愛(あい)は要(い)らないな(にゃん~)

kan kan teri no ho shi de  
乾乾照(かんかんて)りの惑星(ほし)で　  
pin ku ga ha ji ke  
ピンクが弾(はじ)け  
nou nai hou shuu ke u ru o tte  
脳内報酬系(のうないほうしゅうけ)潤(うるお)って　  
kyan di-mo ta ri na i hodo  
キャンディーも足(た)りない程(ほど)  
pa ppa ppa  
パッパッパ  
tsu gi ga ho shi kute tada ha i ta  
次(つぎ)が欲(ほ)しくてただ、吐(は)いた  
「su ki」nan ka jya i mi wo na sa nai  
「スキ」なんかじゃ 意味(いみ)をなさない

nyan nyan nyan na hi gen go no u chuu ron ri de  
にゃん にゃんにゃんな非言語(ひげんご)の宇宙論理(うちゅうろんり)で  
ha-to ga i chi ou shin ji tsu ni na tta tte  
ハートが一応(いちおう)、真実(しんじつ)になったって  
chan to ai shi au sube wa  
ちゃんと愛(あい)しあう術(すべ)は  
koko ni wa na i  
ここには無(な)い  
a na ta ni sawa ri tai  
あなたに触(さわ)りたい

nyan nyan nyan  
にゃん 猫猫(にゃんにゃん)  
nyan nyan teki ai no shuu en ni te  
猫猫的愛(にゃんにゃんてきあい)の終焉(しゅうえん)にて  
ya ppa zen bu ga u sou ni naru ma e ni  
やっぱ全部(ぜんぶ)がウソになる前(まえ)に  
nyan nyan i za  
にゃんにゃん　いざ！  
u chuu de a nata to nyan！  
宇宙(うちゅう)であなたとにゃんっ！  
「i ma wa wa ta shi wo mi te ne」  
「今(いま)は、わたしを見(み)てね」

kono u chuu wa dorama ti kku  
この宇宙(うちゅう)はドラマティック　  
ka tsu ro man su ti kku  
かつロマンスティック  
nano ni tsu gi a ru ho shou wa nai ra shi ku  
なのに次(つぎ)ある保証(ほしょう)は無(な)いらしく  
nyan nyan kara kuru  
にゃんにゃんから来(く)る　  
ai mai na hibi to  
曖昧(あいまい)な日々(ひび)と  
bai bai shi na i mama fu hai shi tai  
バイバイしないまま腐敗(ふはい)したい  
koto a ru to i ta i mou sou  
事有(ことあ)るとイタい妄想(もうそう)  
o pe ran to ni kai kou dou  
オペラント２回行動(にかいこうどう)  
sa wa tta tte suke na i ai ga ho shii na  
触(さわ)ったって透(す)けない愛(あい)が欲(ほ)しいな

nyan nyan teki u chuu ron  
猫猫的宇宙論(にゃんにゃんてきうちゅうろん)　  
ma hou wa toke na i man ma  
魔法(まほう)は解(と)けないまんま  
ai ra bu yu- wa ki jyou ron  
アイラブユー(I love you)は机上論(きじょうろん)  
tou ni sa sshi te i ta kedo  
とうに察(さっ)していたけど  
san zan moto me tai no  
散散(さんざん)求(もと)めたいの  
sei tou sei wa ni no tsu gi  
正当性(せいとうせい)は二(に)の次(つぎ)  
ma- ii ya i ya hon to wa yoku nai  
まーいいや　いや、ほんとは良(よ)くない

nyan nyan nyan na hi gen go no u chuu ron ri de  
にゃん にゃんにゃんな非言語(ひげんご)の宇宙論理(うちゅうろんり)で  
ha-to ga do kka chuu ni ma u sun zen da  
ハートがどっか宙(ちゅう)に舞(ま)う寸前(すんぜん)だ  
ta ta ta bun yame rare wa shi na i  
た た 多分(たぶん)やめられはしない　  
yame taku mo na i ga  
やめたくもないが

nyan nyan nyan  
にゃん 猫猫(にゃんにゃん)  
nyan nyan teki ai no shuu en ni te  
猫猫的愛(にゃんにゃんてきあい)の終焉(しゅうえん)にて  
ai toka ko i ga chin bu ni na tte mo  
愛(あい)とか恋(こい)が陳腐(ちんぶ)になっても  
a nata to de a e tta ri yuu wo  
あなたと出逢(であえ)った理由(りゆう)を  
saga shi te miru kara sa  
探(さが)してみるからさ  
me wo sora sa na i de  
目(め)を逸(そ)らさないで

nyan nyan nyan na hi gen ji tsu no u chuu ron ri de  
にゃん にゃんにゃんな非現実(ひげんじつ)の宇宙論理(うちゅうろんり)で  
ha-to ga ya tto shin ji tsu ni na tta ra  
ハートが やっと真実(しんじつ)になったら  
zu zu zu tto ai wo ta shi kame ta i  
ず ず ずっと愛(あい)を確(たし)かめたい  
fu tari no se ka i de  
ふたりの世界(せかい)で

nyan nyan nyan  
にゃん 猫猫(にゃんにゃん)  
nyan nyan teki ai no ei en ni te  
猫猫的愛(にゃんにゃんてきあい)の永遠(えいえん)にて  
gen go sa e kawa shi a e nu a nata to  
言語(げんご)さえ交(か)わしあえぬあなたと  
nyan nyan  
にゃんにゃん　  
wa ka tta you na ka o shi te nyan！  
解(わか)ったような顔(かお)してにゃんっ！  
「mo tto wa ta shi wo ai shi tene」  
「もっと、わたしを愛(あい)してね」

zu tto zu tto ai shi tene  
ずっとずっと愛(あい)してね