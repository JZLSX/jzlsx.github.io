---
title: 「紅蓮華」/まふまふ(歌ってみた)鬼滅の刃(鬼灭之刃)- OP【罗马音+假名歌词】
tags:
  - まふまふ
  - 罗马音
  - まふまふ
  - 假名歌词
id: '2478'
date: 2020-03-08 20:21:17
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/03/maxresdefault.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/03/maxresdefault.jpg
---

「紅蓮華」

作詞：LiSA  
作曲：草野華余子  
編曲：江口 亮  
Arrange：三矢禅晃  
Inst Mix：yasu(Tinkle-POP)  
絵：胡麻乃りお  
映像：MONO-Devoid  
Vocal：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

tsu yo ku na re ru ri yuu wo shi tta  
強(つよ)くなれる理由(りゆう)を知(し)った　  
boku wo tsu re te susu me  
僕(ぼく)を連(つ)れて進(すす)め

do ro da ra ke no sou ma to u ni yo u  
泥(どろ)だらけの走馬灯(そうまとう)に酔(よ)う　  
ko wa ba ru ko ko ro  
こわばる心(こころ)  
fu ru e ru te wa tsu ka mi ta i mono ga a ru  
震(ふる)える手(て)は掴(つか)みたいものがある　  
sore da ke sa  
それだけさ  
yoru no ni o i ni  
夜(よる)の匂(にお)いに  
( I'll spend all thirty nights)  
so ra ni ran demo  
空睨(そらにら)んでも  
( Staring into the sky)  
ka wa tte i ke ru no wa ji bun ji shin dake  
変(か)わっていけるのは自分自身(じぶんじしん)だけ　  
sore da ke sa  
それだけさ

tsu yo ku na re ru ri yuu wo shi tta  
強(つよ)くなれる理由(りゆう)を知(し)った　  
boku wo tsu re te susu me  
僕(ぼく)を連(つ)れて進(すす)め

dou shi ta tte！  
どうしたって！  
ke se na i yume mo  
消(け)せない夢(ゆめ)も　  
to ma re na i i ma mo  
止(と)まれない今(いま)も  
dare ka no ta me ni tsu yo ku na re ru nara  
誰(だれ)かのために強(つよ)くなれるなら  
a ri ga tou ka na shi mi yo  
ありがとう　悲(かな)しみよ  
sei kai ni u chi no me sare te  
世界(せかい)に打(う)ちのめされて  
ma ke ru i mi wo shi tta  
負(ま)ける意味(いみ)を知(し)った  
gu ren no hana yo sa ki ho ko re！  
紅蓮(ぐれん)の華(はな)よ咲(さ)き誇(ほこ)れ！　  
un me i wo te ra shi te  
運命(うんめい)を照(て)らして

i na bi ka ri no za tsu on ga mimi wo sa su  
イナビカリの雑音(ざつおん)が耳(みみ)を刺(さ)す  
to ma do u kokoro  
戸惑(とまど)う心(こころ)  
ya sa shii dake jya mamo re na i mono ga a ru？  
優(やさ)しいだけじゃ守(まも)れないものがある？  
wa ka tte ru ke do  
わかってるけど

sui men ka de kara maru zen a ku  
水面下(すいめんか)で絡(から)まる善悪(ぜんあく)  
su kete mi e ru gi zen ni ten ba tsu  
透(す)けて見(み)える偽善(ぎぜん)に天罰(てんばつ)  
(Tell me why Tell me why Tell me why Tell me …）  
I don't need you！  
i tsu zai no hana yo ri  
逸材(いつざい)の花(はな)より　  
i domi tsu zu ke sai ta i chi rin ga u tsu ku shii  
挑(いど)み続(つづ)け咲(さ)いた一輪(いちりん)が美(うつく)しい

ran bou ni shi ki tsu me rare ta  
乱暴(らんぼう)に敷(し)き詰(つ)められた　  
to ge dara ke no mi chi mo  
トゲだらけの道(みち)も  
hon ki no boku dake ni a ra wa re ru kara  
本気(ほんき)の僕(ぼく)だけに現(あらわ)れるから　  
no ri ko e te mi se ru yo  
乗(の)り越(こ)えてみせるよ  
kan tan ni kata zu ke rare ta  
簡単(かんたん)に片付(かたず)けられた　  
mamo re na ka tta yume mo  
守(まも)れなかった夢(ゆめ)も  
gu ren no shin zou ni ne wo ha ya shi  
紅蓮(ぐれん)の心臓(しんぞう)に根(ね)を生(は)やし  
kono chi ni ya do tte- ru  
この血(ち)に宿(やど)ってる

hi to shi rezu ha ka na i  
人知(ひとし)れず儚(はかな)い　  
chi ri yu ku ke tsu ma tsu  
散(ち)りゆく結末(けつまつ)  
mu jyo u ni ya bu re ta  
無情(むじょう)に破(やぶ)れた　  
hi me i no ka ze fu ku  
悲鳴(ひめい)の風吹(かぜふ)く  
dare ka no wara u ka ge  
誰(だれ)かの笑(わら)う影(かげ)　  
dare ka no naki go e  
誰(だれ)かの泣(な)き声(ごえ)  
dare mo ga shi a wa se wo ne ga tte ru  
誰(だれ)もが幸(しあわ)せを願(ねが)ってる

dou shi ta tte！  
どうしたって！  
ke se na i yume mo  
消(け)せない夢(ゆめ)も　  
to ma re na i i ma mo  
止(と)まれない今(いま)も  
dare kano ta me ni tsu yo ku na re ru nara  
誰(だれ)かのために強(つよ)くなれるなら  
a ri ga tou ka na shi mi yo  
ありがとう　悲(かな)しみよ  
sei kai ni u chi no me sa re te  
世界(せかい)に打(う)ちのめされて  
ma keru i mi wo shi tta  
負(ま)ける意味(いみ)を知(し)った  
gu ren no hana yo sa ki ho ko re！  
紅蓮(ぐれん)の華(はな)よ咲(さ)き誇(ほこ)れ！　  
un me i wo te ra shi te  
運命(うんめい)を照(て)らして

un me i wo te ra shi te  
運命(うんめい)を照(て)らし