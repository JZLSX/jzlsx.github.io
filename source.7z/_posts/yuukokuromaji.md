---
title: 「夕刻、夢ト見紛ウ」/After the Rain (そらる×まふまふ)【罗马音+假名歌词】
tags:
  - 夕刻、夢ト見紛ウ
  - まふまふ
  - そらる
  - After the Rain
  - 罗马音
  - 假名歌词
id: '2806'
date: 2020-04-29 21:57:16
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/mC7u8F5d.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2020/04/mC7u8F5d.jpg
---

「夕刻、夢ト見紛ウ」

<a href="https://www.nicovideo.jp/watch/sm36763184">【MV】最終宣告／まふまふ</a>

作詞作編曲：まふまふ  
Mix&Mastering：そらる  
絵：くっか  
映像：お菊  
歌：After the Rain(そらる×まふまふ)

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

歌词翻译：[https://mafuclub.com/translation/yuukoku/](https://mafuclub.com/translation/yuukoku/)

ho no me ku ka ge ga yu re ru  
ほのめく影(かげ)が揺(ゆ)れる  
i tsu kara mi ho re ta da rou  
いつから見惚(みほ)れただろう  
sayo nara shi you o wa kare shi yo u  
さよならしよう お別(わか)れしよう  
kimi ga fu ri muku sono ma e ni  
キミが振(ふ)り向(む)くその前(まえ)に

yo ho u do o ri no a me wa  
予報通(よほうどお)りの雨(あめ)は  
mo e gi wo nu ra shi te i ku  
萌木(もえぎ)を濡(ぬ)らしていく  
doko ka e yu kou shi ga tsu no ko bo su  
どこかへ行(ゆ)こう 四月(しがつ)の零(こぼ)す  
tame i ki ni no se te to o ku made  
ため息(いき)に乗(の)せて 遠(とお)くまで

hi to tsu ha ru wo  
ひとつ 春(はる)を  
ta ga e ta toki ni wa  
違(たが)えた時(とき)には  
ki tto sure chi ga u a shi ta da tta  
きっと すれ違(ちが)う明日(あした)だった  
a re mo ko re mo  
あれも これも  
o mo ha yu i hibi da tta  
面映(おもは)ゆい日々(ひび)だった  
kono yono i to shi ku byou dou na  
この世(よ)の愛(いと)しく平等(びょうどう)な  
ji kan ga ki ta mi tai da  
時間(じかん)が来(き)たみたいだ

sa ku ra sa ku ra  
桜(さくら) 桜(さくら)  
fu ta ri no yoru wo u me ta  
ふたりの夜(よる)を埋(う)めた  
ma do ro mi de shi ta  
微睡(まどろ)みでした  
me gu ri a u o mo i  
巡(めぐ)り合(あ)う想(おも)い  
ki shi kata yuku su e  
来(き)し方(かた)行(ゆ)く末(すえ)  
tsu do i hi to hi ra fu ta hi ra i ro do ru  
集(つど)い ひとひら ふたひら 彩(いろど)る

so re wa so re wa  
それは それは  
yume to mi ma ga u hodo no  
夢(ゆめ)と見紛(みまが)うほどの  
i ta zu ra de shi ta  
悪戯(いたずら)でした  
ya ga te yoru ga kuru ma e ni  
やがて夜(よる)が来(く)る前(まえ)に  
tsu ta e naku cha  
伝(つた)えなくちゃ

ta gu ri yu wa i ta i bu ki  
手繰(たぐ)り結(ゆ)わいた息吹(いぶき)  
noko sare ta to ki nan te  
残(のこ)された時(とき)なんて  
i ku ba ku mo nai sore demo ko wa i  
幾許(いくばく)もない それでも怖(こわ)い  
ne wo haru kokoro ga ha ga yu i naa  
根(ね)を張(は)る心(こころ)が歯(は)がゆいなあ

kyou bi a ri fure ta i to ma go i  
今日日(きょうび)ありふれた 暇乞(いとまご)い  
o shi na be te a ga na u you ni  
おしなべて購(あがな)う様(よう)に  
ku re ma do u hodo yo wa ku wa nai sa  
暗(く)れ惑(まど)うほど 弱(よわ)くはないさ  
kono yo wa hito shi ku tan jyun na  
この世(よ)は等(ひと)しく単純(たんじゅん)な  
sa ke ba chi ru hana no you ni  
咲(さ)けば散(ち)る花(はな)のように

so re wa so re wa  
それは それは  
i ma wa no ki wa wo ko e ta  
今際(いまわ)の際(きわ)を越(こ)えた  
yu bi ki ri de shi ta  
指切(ゆびき)りでした  
yu ku ri na ku mo yume no you na  
ゆくりなくも夢(ゆめ)のような  
to ki wo ta do ru  
時(とき)を辿(たど)る

kokoro noko ri da tte  
心残(こころのこ)りだって  
na i wa ke na i kedo  
ないわけないけど  
ta yu ta u yami yo ni chuu wo ma u  
揺蕩(たゆた)う闇夜(やみよ)に宙(ちゅう)を舞(ま)う  
a ri ga tou a ri ga tou  
ありがとう ありがとう  
a no koro yori mo ma e wo muke tayo  
あの頃(ころ)よりも 前(まえ)を向(む)けたよ

sa ku ra sa ku ra  
桜(さくら) 桜(さくら)  
kimi to de a e ta koto ga  
キミと出会(であ)えたことが  
shi a wa se de shi ta  
幸(しあわ)せでした  
me gu ri a u o mo i  
巡(めぐ)り合(あ)う想(おも)い  
ki shi ka ta yuku su e  
来(き)し方(かた)行(ゆ)く末(すえ)  
tsu do i hi to hi ra fu ta hi ra i ro do ru  
集(つど)い ひとひら ふたひら 彩(いろど)る

ki mi to ta do ru  
君(きみ)と 辿(たど)る  
tsu ki yo wo ko ba mu hodo no  
月夜(つきよ)を拒(こば)むほどの  
ya ra zu no a me  
遣(や)らずの雨(あめ)  
sore wa yu me to mi ma ga u you na  
それは夢(ゆめ)と見紛(みまが)うような  
sore wa ko i to mi ma ga u you na  
それは恋(こい)と見紛(みまが)うような  
to ki de shi ta  
時(とき)でした