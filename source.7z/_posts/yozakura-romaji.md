---
title: 「夜桜」/ (まふまふｘとなりの坂田)【罗马音+假名歌词】
tags:
  - となりの坂田
  - 罗马音
  - まふまふ
  - 假名歌词
  - 夜桜
id: '1124'
date: 2019-12-27 23:36:44
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/12/20191227170855.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/12/20191227170855.jpg
---

「夜桜」

作詞作編曲：まふまふ  
歌：まふまふ×となりの坂田  
絵：Aちき  
映像：みず希

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

「to mo da chi」jya su ko shi dake  
「友達(ともだち)」じゃ少(すこ)しだけ  
ta ri na i  
足(た)りない  
kyo ri kan ga koko chi yo i no wa naze？  
距離感(きょりかん)が心地(ここち)よいのはなぜ？  
「hi to ri demo ka ma wa na i」to  
「ひとりでも構(かま)わない」と  
tsu yo ga ri no  
強(つよ)がりの  
fu ta hi ra ga o chi a u  
ふたひらが落(お)ち合(あ)う  
ya yo i no tsu ku yo  
弥生(やよい)の月夜(つくよ)

mo shi mo o na ji tsu me e ri nara ba  
もしも 同(おな)じ詰襟(つめえり)ならば  
chi ga u mi ra i ga a tta ka na nan te  
違(ちが)う未来(みらい)があったかな なんて  
te re ku sa i ha na shi wa  
照(て)れくさい話(はなし)は  
ni a wa na i mama  
似合(にあ)わないまま  
sa ku ra ga sa i ta  
桜(さくら)が咲(さ)いた

hi to ri ki ri na i ta  
ひとりきり泣(な)いた  
ko e ga ka sa na tte  
声(こえ)が重(かさ)なって  
fu ta ri de wa ra e ta  
ふたりで笑(わら)えた  
a re kara nan nen da kke  
あれから何年(なんねん)だっけ  
a ka shi ro a wa se te  
赤白(あかしろ)合(あ)わせて  
i ro zu ku yo za ku ra  
色(いろ)づく夜桜(よざくら)  
yu bi ki ri wa  
指切(ゆびき)りは  
i chi do ki ri demo  
一度(いちど)きりでも  
zu tto to mo da chi de i you  
ずっと友達(ともだち)でいよう

mi zu ta ma ri tsu ma zu i te ko ron da  
水(みず)たまり つまずいて転(ころ)んだ  
sono sa ki ni hana a ka ri ga to mo ru  
その先(さき)に 花(はな)あかりが灯(とも)る  
a re ko re to bu ki you na kono mi gi te mo  
あれこれと 不器用(ぶきよう)なこの右手(みぎて)も  
kimi no koto ku ra i wa o ko se ru ka ra sa  
君(きみ)のことくらいは 起(お)こせるからさ

ta to e ba no ha na shi  
例(たと)えばの話(はなし)  
ku chi ni suru ke re do  
口(くち)にするけれど  
sono sa ki ni tsu zu ku  
その先(さき)に続(つづ)く  
ka wa ra na i kyou da tta  
変(か)わらない今日(きょう)だった  
a ka shi ro a wa se te  
赤白(あかしろ)合(あ)わせて  
i ro zu ku yo za ku ra  
色(いろ)づく夜桜(よざくら)  
sa yo na ra de  
さよならで  
u ma re ka wa tte mo  
生(う)まれ変(か)わっても  
ki tto to mo da chi de i you  
きっと友達(ともだち)でいよう

ma chi ga tta ka zu dake  
間違(まちが)った数(かず)だけ  
te ta ta i te  
手叩(てたた)いて  
wa ra i to ba se ru you na  
笑(わら)い飛(と)ばせるような  
boku ra de i you  
ボクらでいよう  
sore de ii n da to i ma sa ra shi tta  
それでいいんだと今更(いまさら)知(し)った  
kono te dake wa ha na sa na i you ni  
この手(て)だけは放(はな)さないように

hi to ri ki ri na i ta  
ひとりきり泣(な)いた  
ko e ga ka sa na tte  
声(こえ)が重(かさ)なって  
fu ta ri de wa ra e ta  
ふたりで笑(わら)えた  
a re ka ra nan nen da kke  
あれから何年(なんねん)だっけ  
a ka shi ro a wa se te  
赤白(あかしろ)合(あ)わせて  
i ro zu ku yo za ku ra  
色(いろ)づく夜桜(よざくら)  
yu bi ki ri wa  
指切(ゆびき)りは  
i chi do ki ri demo  
一度(いちど)きりでも  
zu tto to mo da chi de i you  
ずっと友達(ともだち)でいよう

hi to tsu da ke i wa se te yo  
ひとつだけ言(い)わせてよ  
kimi ni a e te yo ka tta  
君(きみ)に会(あ)えてよかった  
sa ku ra ma u  
桜舞(さくらま)う