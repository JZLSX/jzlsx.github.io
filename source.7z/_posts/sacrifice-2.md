---
title: 「サクリファイス」まふまふ 致曾为神之众兽/猎兽神兵 OP 日文歌词（罗马音+假名歌词）
tags:
  - サクリファイス
  - 罗马音
  - まふまふ
  - 假名歌词
  - 神楽色アーティファクト
id: '694'
date: 2019-07-02 19:10:12
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/66628f280b1870c968b73470a214cc2686f82d4d.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/10/66628f280b1870c968b73470a214cc2686f82d4d.jpg
---

《神楽色アーティファクト》收录曲  
作曲：まふまふ  
作詞：まふまふ  
唄：まふまふ

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

ha te shi nai hi ai no kan jyou sen  
果(は)てしない悲哀(ひあい)の環状線(かんじょうせん)  
u ba i ai no ren sa  
奪(うば)い合(あ)いの連鎖(れんさ)  
shuu maku wa doko de mi rare ru da rou  
終幕(しゅうまく)はどこで見(み)られるだろう  
i no chi wo a zu ke ta ten bin wa  
命(いのち)を預(あず)けた天秤(てんびん)は  
sui tei mu zai wo you shi te  
推定無罪(すいていむざい)を要(よう)して  
so no sei gi mo  
その正義(せいぎ)も　  
ta ke ru yuu shi mo  
猛(たけ)る勇姿(ゆうし)も  
fu you hin to na tte shi ma tta  
不用品(ふようひん)となってしまった

―dou shi te dou shi te dou shi te  
―どうしてどうしてどうして？

ko no te jya  
この手(て)じゃ  
son na chi sa na kokoro ni  
そんな小(ち)さな心(こころ)に  
u maku sa wa re nai  
うまく触(さわ)れない

yu gan da un mei wa  
歪(ゆが)んだ運命(うんめい)は　  
i ku tsu mono kin ki no tsu basa  
幾(いく)つもの禁忌(きんき)の翼(つばさ)  
nozo mare ka za shi ta ya i ba ga  
望(のぞ)まれかざした刃(やいば)が  
te no hi ra wo ka e shi te tsu mi to naru  
手(て)のひらを返(かえ)して罪(つみ)と成(な)る  
sore wa tsu ji tsu ma ga  
それは　辻褄(つじつま)が  
kami ni so mu ki dasu karuma  
神(かみ)に背(そむ)きだすカルマ  
tato e kuru i nai mi rai to shi temo  
たとえ狂(くる)いない未来(みらい)としても　  
se i koku ni i ka keru  
正鵠(せいこく)に射(い)かける  
dou shi te  
どうして　  
boku no na ma e wo yon de yo  
ボクの名前(なまえ)を呼(よ)んでよ  
mada nou ri ni yaki tsu ku  
まだ脳裏(のうり)に焼(や)きつく  
shou kei  
憧憬(しょうけい)

ku da ra nai yume no tsu dzu ki ya  
くだらない夢(ゆめ)の続(つづ)きや　  
a no o ka me za shi te  
あの丘目指(おかめざ)して  
boku ra wa wara e ta hazu da tta no ni  
ボクらは笑(わら)えたはずだったのに  
u ta ga i  
疑(うたが)い　  
u ta ga ware te wa kagi kakeru kyou da  
疑(うたが)われては鍵(かぎ)かける今日(きょう)だ  
baku dan de shi ka to wo tata ke zu ni  
爆弾(ばくだん)でしか戸(と)を叩(たた)けずに  
doko kade ma chi ga e te i tan da  
どこかで間違(まちが)えていたんだ

―dou shi te dou shi te dou shi te  
―どうしてどうしてどうして？

kono te wa u ba u koto bakari de  
この手(て)は　奪(うば)うことばかりで  
a ya se mo shi nai  
あやせもしない

sora wa a o yo ri  
空(そら)は青(あお)より  
hai i ro to ki o ku shi ta tsu basa  
灰色(はいいろ)と記憶(きおく)した翼(つばさ)  
tata ri me u ba tta dai shou ni  
祟(たた)り目(め)奪(うば)った代償(だいしょう)に

mou boku wa boku de i rare nai  
もうボクはボクでいられない  
sore wa katsu te na wo mo tta  
それはかつて名(な)を持(も)った　  
shou ku zai to rin ne  
贖罪(しょくざい)と輪廻(りんね)  
i go i kanaru shi a wa se demo  
以後(いご)いかなる幸(しあわ)せでも　  
kono te de wa sa wa re nai  
この手(て)では触(さわ)れない

dou shi te  
どうして　  
kimi to a tte shi ma tta no  
君(きみ)と会(あ)ってしまったの  
nodo moto ni yaki tsu ku  
喉元(のどもと)に焼(や)きつく  
shou en  
硝煙(しょうえん)

kore dake no ku tsuu wo kaka e kon de  
これだけの苦痛(くつう)を抱(かか)え込(こ)んで  
u ma re ta i mi nado wa nai to shi tta  
生(う)まれた意味(いみ)などはないと知(し)った  
chi nu rare ta kyou bi wo chi de a ra tte  
血塗(ちぬ)られた今日日(きょうび)を血(ち)で洗(あら)って  
u ma re ta i mi nado wa nai to shi tta  
生(う)まれた意味(いみ)などはないと知(し)った  
nani hitotsu mo suku e nai ku se shi te  
何(なに)ひとつも救(すく)えないくせして  
jyuu ji ka bakari wo se o tte i kou to  
十字架(じゅうじか)ばかりを背負(せお)っていこうと  
nani mono nimo nare nai to shi tta  
何者(なにもの)にもなれないと知(し)った  
sho kei dai ga wara i  
処刑台(しょけいだい)が嗤(わら)い　  
te ma ne i te iru  
手招(てまね)いている

yu gan da un me i ni  
歪(ゆが)んだ運命(うんめい)に  
hai shi ta ka ri some no tsu basa  
敗(はい)した仮初(かりそめ)の翼(つばさ)  
nozo mare ka za shi ta ya i ba ga  
望(のぞ)まれかざした刃(やいば)が  
te no hi ra wo ka e shi te tsu mi to naru  
手(て)のひらを返(かえ)して罪(つみ)と成(な)る  
sore wa tsu ji tsu ma ga  
それは　辻褄(つじつま)が  
kami ni so mu ki dasu karuma  
神(かみ)に背(そむ)きだすカルマ  
tato e kuru i nai mi rai to shi temo  
たとえ狂(くる)いない未来(みらい)としても　  
sei koku ni i ka ke ru  
正鵠(せいこく)に射(い)かける  
dou shi te  
どうして　  
boku no na ma e wo yon de yo  
ボクの名前(なまえ)を呼(よ)んでよ  
mada nou ri ni yaki tsu ku  
まだ脳裏(のうり)に焼(や)きつく  
shou kei  
憧憬(しょうけい)