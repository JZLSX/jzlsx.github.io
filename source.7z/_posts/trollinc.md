---
title: 「3」「Troll Inc. 」/神様、僕は気づいてしまった【罗马音+假名歌词】
tags:
  - Troll Inc.
  - 罗马音
  - 神様、僕は気づいてしまった
  - 假名歌词
id: '723'
date: 2019-10-12 19:46:36
category: 罗马音
banner_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
index_img: https://cdn.jsdelivr.net/gh/JZLSX/image/2019/11/43c6593463239611e3d1f61890ebb84f99905f22.jpg@1075w_602h.jpg
---

「Troll Inc. 」

神様、僕は気づいてしまった  
－「20XX」アルバム収録曲

作詞：東野へいと  
作曲：東野へいと  
vocal：どこのだれか

罗马音：[化野\_uni](https://space.bilibili.com/242402048/article)

ki kka ke wa a i tsu da tta  
きっかけはあいつだった　  
nani mo kamo ga mu cha ku cha ni na tta  
何(なに)もかもが無茶苦茶(むちゃくちゃ)になった  
kono ma chi mo mu ka shi wa shi zu ka da ttan da  
この街(まち)も昔(むかし)は静(しず)かだったんだ　  
sore ga fu tsuu da tta  
それが普通(ふつう)だった

soko ni a i tsu ga de te ki te  
そこにあいつが出(で)てきて　  
dare mo kare mo ga mu chuu ni na tta  
誰(だれ)も彼(かれ)もが夢中(むちゅう)になった  
i ma 、boku ra wa o na ji be ru to kon be a ni  
今(いま)、僕等(ぼくら)は同(おな)じベルトコンベアに  
no se rare teru you da  
乗(の)せられてるようだ

sore kara neko mo sha ku shi mo min na  
それから猫(ねこ)も杓子(しゃくし)も皆(み)んな  
ko ke o do shi de su kyan da ra su na  
虚仮威(こけおど)しでスキャンダラスな  
shi tai wo mu sa bo tte ru  
死体(したい)を貪(むさぼ)ってる

Can't you see we ain't nothing  
mada mada ta ri nai yo  
まだまだ足(た)りないよ　  
ta ri nai yo  
足(た)りないよ  
ya ri ta ri nai yo  
やり足(た)りないよ　  
mou u so demo ii jya n yo  
もう嘘(うそ)でもいいじゃんよ

How come we ain't nothing  
a re ko re tsu me kon de  
あれこれ詰(つ)め込(こ)んで　  
ka ki ka e te  
書(か)き換(か)えて  
ke shi sa tta tte  
消(け)し去(さ)ったって　  
son na tei do jya mu kizu da ro  
そんな程度(ていど)じゃ無傷(むきず)だろ

maru de shin pa mi tai ni  
まるでシンパみたいに　  
ma chi wa hi ni hi ni kyou ki de mi chi ta  
街(まち)は日(ひ)に日(ひ)に狂気(きょうき)で満(み)ちた  
o na ji ka o ni na tte a fu re ta ma chi nami wa  
同(おな)じ顔(かお)になって溢(あふ)れた街並(まちな)みは  
maru de kyou dan da tta  
まるで教団(きょうだん)だった

soko ni dare ka ga i tta  
そこで誰(だれ)かが言(い)った  
「deki so ko nai wa na ka ma jya nai ze」  
「出来損(できそこ)ないは仲間(なかま)じゃないぜ」  
o so ro i no bake mono tachi mo  
お揃(そろ)いの化(ば)け物(もの)達(たち)も  
ko e wo soro e te  
声(こえ)を揃(そろ)えて  
yo so mono wo ke ri da shi ta  
よそ者(もの)を蹴(け)り出(だ)した

sen dou te ki na ka me re o n ga no sa ba tte  
扇動的(せんどうてき)なカメレオンがのさばって　  
nani mono ni mo na re na i to  
何者(なにもの)にもなれないと  
i ro wo u shi na tte ru  
色(いろ)を失(うしな)ってる

Can't you see we ain't nothing  
mada mada ta ri nai yo  
まだまだ足(た)りないよ　  
ta ri nai yo  
足(た)りないよ  
ya ri ta ri nai yo  
やり足(た)りないよ　  
da tte a i tsu ga ma nu ke nan da mon  
だってあいつが間抜(まぬ)けなんだもん

How come we ain't nothing  
i ma ga su be te nan de  
今(いま)が全(すべ)てなんで　  
su be te nan de  
全(すべ)てなんで  
ka wa i sou nan te  
可哀想(かわいそう)なんて　  
a sso、oo ki na o se wa nan da yo  
あっそ、大(おお)きなお世話(せわ)なんだよ

－dou dai dou dai ko ron da  
―どうだい　どうだい転(ころ)んだ　  
ta nin wo rin chi suru go kko a so bi wa  
他人(たにん)をリンチするごっこ遊(あそ)びは  
－son na son na tsu mo ri jya  
―そんな　そんなつもりじゃ　  
na ka tta to demo o mo tte run da ro  
無(な)かったとでも思(おも)ってるんだろ  
－sou kai sou kai ke kkou  
―そうかい　そうかい結構(けっこう)　  
son na ka ta chi wo sei gi nan te yo bu to wa  
そんな形(かたち)を正義(せいぎ)なんて呼(よ)ぶとは  
ben kyou ni na tta yo  
勉強(べんきょう)になったよ

Can't you see we ain't nothing  
Dilly-dally no longer, no longer, we'll be madness  
Let's choke the life outta 'em all  
How come we ain't nothing  
Here comes the bullies now, screaming now, creepy crawling  
Let's choke the life outta 'em all

Now that we ain't nothing  
kono mi wo na ge da shi te  
この身(み)を投(な)げ出(だ)して　  
na ge da shi te  
投(な)げ出(だ)して  
a shi hi ppa tte  
足引(あしひ)っ張(ぱ)って　  
a i tsu wo don zoko ni o to sou  
あいつをどん底(ぞこ)に落(お)とそう

How come we ain't nothing  
sore demo ta ri nai yo  
それでも足(た)りないよ　  
ta ri nai yo  
足(た)りないよ  
yari ta ri nai yo  
やり足(た)りないよ　  
da tte min na mo tto ya tte run da mon  
だって皆(み)んなもっとやってるんだもん

tato e ko kke i de  
例(たと)え滑稽(こっけい)で　  
fu ga i naku te  
不甲斐(ふがい)なくて　  
u so ppa chi da tte  
嘘(うそ)っぱちだって　  
mou hi ki ka e se ya shi nai n da yo  
もう引(ひ)き返(かえ)せやしないんだよ

a su mo sou ya tte  
明日(あす)もそうやって　  
a sa tte da tte  
明後日(あさって)だって　  
yo mo su kara da tte  
夜(よ)もすがらだって　

o wa ri wa  
終(お)わりは  
boku ra da tte  
僕等(ぼくら)だって　  
shi ri ta ku mo na i  
知(し)りたくもない